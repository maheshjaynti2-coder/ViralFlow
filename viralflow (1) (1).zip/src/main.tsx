import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Handle transient cross-origin or network connection drops gracefully
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const msg = reason?.message || String(reason || '');
    if (
      msg.includes('unavailable') ||
      msg.includes('offline') ||
      msg.includes('network') ||
      msg.includes('permissions') ||
      msg.includes('Permission')
    ) {
      event.preventDefault();
      console.warn('Recovered from transient background network event:', msg);
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
