import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Users,
  Search,
  Check,
  UserPlus,
  Sparkles,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { FirestoreUserDoc, UserProfile, DEFAULT_AVATAR } from '../types';
import { subscribeFirestoreUsers, toggleFirestoreFollow } from '../lib/firebase';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';

interface DiscoverCreatorsScreenProps {
  currentUser: UserProfile;
  followedUserIds: Set<string>;
  onBack: () => void;
  onSelectCreator: (creatorId: string) => void;
  onFollowToggle: (creatorId: string) => void;
}

export const DiscoverCreatorsScreen: React.FC<DiscoverCreatorsScreenProps> = ({
  currentUser,
  followedUserIds,
  onBack,
  onSelectCreator,
  onFollowToggle,
}) => {
  const [creators, setCreators] = useState<FirestoreUserDoc[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [actionLoadingMap, setActionLoadingMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setIsLoading(true);
    const unsubscribe = subscribeFirestoreUsers((userDocs) => {
      setCreators(userDocs);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleToggleFollow = async (creatorId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser.uid || currentUser.uid === creatorId) return;

    setActionLoadingMap((prev) => ({ ...prev, [creatorId]: true }));
    const isCurrentlyFollowing = followedUserIds.has(creatorId);

    // Call optimistic / parent update
    onFollowToggle(creatorId);

    try {
      await toggleFirestoreFollow(currentUser.uid, creatorId, isCurrentlyFollowing);
    } catch (err) {
      console.error('Error toggling follow in Firestore:', err);
    } finally {
      setActionLoadingMap((prev) => ({ ...prev, [creatorId]: false }));
    }
  };

  // Filter creators by search query, optionally exclude the current logged-in user or list them distinctly
  const filteredCreators = creators.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      c.displayName?.toLowerCase().includes(q) ||
      c.username?.toLowerCase().includes(q) ||
      c.bio?.toLowerCase().includes(q)
    );
  });

  return (
    <LiquidGlassBackground>
      <div className="relative min-h-screen pb-24 px-4 pt-3 max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full liquid-glass-pill flex items-center justify-center text-slate-700 hover:bg-white transition-colors cursor-pointer"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-purple-500 to-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Users className="w-4 h-4" />
            </div>
            <h1 className="font-black text-base text-slate-900 tracking-tight">
              Meet Real People
            </h1>
          </div>

          <div className="w-9 h-9" /> {/* Spacer */}
        </div>

        {/* Subtitle Banner */}
        <div className="mb-4 liquid-glass-card rounded-2xl p-3.5 border border-purple-100 bg-white/70 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-black text-slate-800">
              Discover Real Creators
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Synced directly with Firestore community
            </p>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 font-extrabold text-[11px] border border-purple-200">
            {filteredCreators.length} {filteredCreators.length === 1 ? 'Creator' : 'Creators'}
          </span>
        </div>

        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name or @username..."
            className="w-full pl-10 pr-4 py-2.5 rounded-full liquid-glass-card bg-white/80 border border-slate-200 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400 hover:text-slate-700"
            >
              Clear
            </button>
          )}
        </div>

        {/* Creators List */}
        {isLoading ? (
          <div className="space-y-3 pt-4">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="liquid-glass-card rounded-2xl p-3.5 flex items-center justify-between animate-pulse"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-slate-200" />
                  <div className="space-y-1.5">
                    <div className="w-24 h-3.5 bg-slate-200 rounded-md" />
                    <div className="w-16 h-2.5 bg-slate-100 rounded-md" />
                  </div>
                </div>
                <div className="w-20 h-7 bg-slate-200 rounded-full" />
              </div>
            ))}
          </div>
        ) : filteredCreators.length === 0 ? (
          <div className="liquid-glass-card rounded-3xl p-8 text-center my-6 shadow-xs border border-white">
            <div className="w-14 h-14 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mx-auto mb-3">
              <Users className="w-7 h-7" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-800 mb-1">
              {searchQuery ? 'No creators found' : 'No creators in Firestore yet'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto mb-4">
              {searchQuery
                ? `No creators matching "${searchQuery}". Try another search term.`
                : 'Sign up with multiple accounts or invite friends to grow the ViralFlow creator network!'}
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredCreators.map((creator) => {
              const isSelf = creator.uid === currentUser.uid;
              const isFollowing = followedUserIds.has(creator.uid);
              const isActing = !!actionLoadingMap[creator.uid];

              return (
                <div
                  key={creator.uid}
                  onClick={() => onSelectCreator(creator.uid)}
                  className="liquid-glass-card rounded-2xl p-3.5 flex items-center justify-between hover:bg-white transition-all shadow-xs border border-white cursor-pointer group"
                >
                  {/* Avatar & User Details */}
                  <div className="flex items-center gap-3 min-w-0 pr-2">
                    <div className="relative shrink-0">
                      <img
                        src={creator.photoURL || DEFAULT_AVATAR}
                        alt={creator.displayName || 'Creator'}
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                        }}
                        className="w-12 h-12 rounded-full object-cover ring-2 ring-purple-200 group-hover:ring-purple-400 transition-all bg-slate-100"
                      />
                      <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-sky-500 text-white flex items-center justify-center text-[9px] font-black border border-white">
                        ✓
                      </span>
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-extrabold text-xs text-slate-900 truncate">
                          {creator.displayName || 'ViralFlow Creator'}
                        </span>
                        {isSelf && (
                          <span className="px-1.5 py-0.2 rounded-full bg-slate-100 text-slate-500 text-[9px] font-bold">
                            You
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-500 block truncate">
                        {creator.username || `@${creator.uid.slice(0, 6)}`}
                      </span>
                      <span className="text-[10px] font-semibold text-purple-600 mt-0.5 block">
                        {(creator.followersCount || 0).toLocaleString()} followers
                      </span>
                      {creator.bio && (
                        <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                          {creator.bio}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Follow / Following Button */}
                  {!isSelf ? (
                    <button
                      onClick={(e) => handleToggleFollow(creator.uid, e)}
                      disabled={isActing}
                      className={`shrink-0 px-3.5 py-1.5 rounded-full text-xs font-extrabold transition-all active:scale-95 cursor-pointer flex items-center gap-1 ${
                        isFollowing
                          ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                          : 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-xs hover:shadow-md'
                      }`}
                    >
                      {isActing ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : isFollowing ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Follow</span>
                        </>
                      )}
                    </button>
                  ) : (
                    <span className="shrink-0 px-2.5 py-1 rounded-full text-[10px] font-bold text-slate-400 bg-slate-50">
                      Profile
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </LiquidGlassBackground>
  );
};
