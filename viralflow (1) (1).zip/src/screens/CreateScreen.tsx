import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  Upload,
  Music,
  Type,
  Hash,
  Sparkles,
  Sliders,
  Send,
  X,
  RotateCcw,
  Check,
  Zap,
  Clock,
  Play,
  Pause,
  Scissors,
  Image as ImageIcon,
  Info,
  Volume2,
  VolumeX,
  ArrowLeft,
  Film,
  FileVideo,
  ChevronRight,
  Smile,
  CheckCircle2,
  RefreshCw,
  AlertCircle,
  LogIn,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { VideoItem, UserProfile, TabType, DEFAULT_AVATAR } from '../types';
import {
  auth,
  uploadVideoFileToStorage,
  uploadThumbnailToStorage,
  publishVideoToFirestore,
} from '../lib/firebase';

interface CreateScreenProps {
  currentUser: UserProfile;
  onPostVideo: (newVideo: VideoItem, targetTab?: TabType) => void;
  onClose: () => void;
  onRequireAuth?: () => void;
}

interface VideoMetadata {
  name: string;
  duration: number;
  sizeMB: string;
  resolution: string;
  format: string;
}

interface SoundTrack {
  id: string;
  title: string;
  artist: string;
  category: string;
  duration: string;
  albumArt: string;
}

interface TextOverlay {
  text: string;
  style: 'modern' | 'glow' | 'pill' | 'script';
  color: string;
  position: 'top' | 'center' | 'bottom';
}

const SAMPLE_SOUNDS: SoundTrack[] = [
  {
    id: 's-1',
    title: 'Golden Hour Waves',
    artist: 'Siya Verma',
    category: 'Trending',
    duration: '0:30',
    albumArt: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 's-2',
    title: 'Sunset Reverie - Lofi Wave',
    artist: 'Aura Studio',
    category: 'Chill Lofi',
    duration: '0:45',
    albumArt: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 's-3',
    title: 'Deep Blue Resonance',
    artist: 'Sofia Miller',
    category: 'Electronic',
    duration: '0:28',
    albumArt: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 's-4',
    title: 'Cyber Midnight Beats',
    artist: 'Neo Tokyo Sound',
    category: 'Trending',
    duration: '0:35',
    albumArt: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 's-5',
    title: 'Alpine Breeze Acoustic',
    artist: 'Liquid Soundworks',
    category: 'Acoustic',
    duration: '0:40',
    albumArt: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=150&auto=format&fit=crop&q=80',
  },
  {
    id: 's-6',
    title: 'Iridescent Flow State',
    artist: 'ViralFlow Studio',
    category: 'Upbeat',
    duration: '0:32',
    albumArt: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
  },
];

const STUDIO_SAMPLE_VIDEOS = [
  {
    id: 'sample-1',
    title: 'City Walk Story',
    category: 'Lifestyle',
    url: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/docs/walking_talking.mp4',
    poster: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    duration: 15,
  },
  {
    id: 'sample-2',
    title: 'Golden Sunset Waves',
    category: 'Nature',
    url: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/sunset_waves.mp4',
    poster: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    duration: 12,
  },
  {
    id: 'sample-3',
    title: 'Deep Ocean Turtle',
    category: 'Underwater',
    url: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/sea_turtle.mp4',
    poster: 'https://images.unsplash.com/photo-1518467166778-b88f373ffec7?w=800&auto=format&fit=crop&q=80',
    duration: 16,
  },
  {
    id: 'sample-4',
    title: 'Neon Tokyo Drift',
    category: 'Cinematic',
    url: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/walking.mp4',
    poster: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    duration: 14,
  },
  {
    id: 'sample-5',
    title: 'Winter Mountain Horses',
    category: 'Adventure',
    url: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/snow_horses.mp4',
    poster: 'https://images.unsplash.com/photo-1553284965-83fd3e82fa5a?w=800&auto=format&fit=crop&q=80',
    duration: 18,
  },
];

const TRENDING_HASHTAGS = [
  '#ViralFlow',
  '#BeYou',
  '#GoodVibes',
  '#CreatorStudio',
  '#DailyVlog',
  '#GoldenHour',
  '#Trending',
  '#FlowState',
  '#Aesthetic'
];

const EMOJI_TOOLBAR = ['✨', '💜', '🌊', '🔥', '🌸', '🚀', '🥰', '⚡', '💫'];

export const CreateScreen: React.FC<CreateScreenProps> = ({
  currentUser,
  onPostVideo,
  onClose,
  onRequireAuth,
}) => {
  // Main Studio Mode: 'record' | 'edit' | 'uploading' | 'posted'
  const [studioMode, setStudioMode] = useState<'record' | 'edit' | 'uploading' | 'posted'>('record');

  // Real File & Upload States
  const [selectedFile, setSelectedFile] = useState<File | Blob | null>(null);
  const [thumbnailBlob, setThumbnailBlob] = useState<Blob | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);

  // Camera & Recording States
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [durationLimit, setDurationLimit] = useState<15 | 60>(15);
  const [countdownTimer, setCountdownTimer] = useState<0 | 3 | 10>(0);
  const [isCountingDown, setIsCountingDown] = useState(false);
  const [countdownCount, setCountdownCount] = useState(0);
  const [recordingSpeed, setRecordingSpeed] = useState<'0.5x' | '1x' | '2x'>('1x');
  const [ringLightOn, setRingLightOn] = useState(false);

  // Active Video Media States
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [posterUrl, setPosterUrl] = useState<string>('');
  const [videoMetadata, setVideoMetadata] = useState<VideoMetadata>({
    name: 'Camera_Capture_01.mp4',
    duration: 15,
    sizeMB: '6.4 MB',
    resolution: '1080 × 1920 (9:16)',
    format: 'video/mp4',
  });

  // Edit / Polish States
  const [isPlaying, setIsPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(15);
  const [selectedSound, setSelectedSound] = useState<SoundTrack>(SAMPLE_SOUNDS[0]);
  const [originalAudioVolume, setOriginalAudioVolume] = useState(100);
  const [soundtrackVolume, setSoundtrackVolume] = useState(80);
  const [caption, setCaption] = useState('Creating my flow in the studio ✨');
  const [selectedTags, setSelectedTags] = useState<string[]>(['#ViralFlow', '#BeYou']);
  const [customTagInput, setCustomTagInput] = useState('');
  const [overlayText, setOverlayText] = useState<TextOverlay>({
    text: '',
    style: 'glow',
    color: '#ffffff',
    position: 'center',
  });

  // Thumbnail choices
  const [thumbnailPercent, setThumbnailPercent] = useState<number>(25);

  // Upload Progress Simulation
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatusText, setUploadStatusText] = useState('Preparing vertical stream...');
  const [postedVideoResult, setPostedVideoResult] = useState<VideoItem | null>(null);

  // Drawer Modals
  const [activeModal, setActiveModal] = useState<
    'none' | 'trim' | 'sound' | 'text' | 'hashtags' | 'thumbnail' | 'info' | 'discard'
  >('none');
  const [soundSearch, setSoundSearch] = useState('');
  const [selectedSoundCategory, setSelectedSoundCategory] = useState('All');

  // DOM Refs
  const cameraVideoRef = useRef<HTMLVideoElement>(null);
  const previewVideoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // 1. Initialize Real Camera Stream when in 'record' mode
  useEffect(() => {
    let currentStream: MediaStream | null = null;

    async function initCamera() {
      if (studioMode !== 'record') return;
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          setCameraError(true);
          return;
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode,
            width: { ideal: 720 },
            height: { ideal: 1280 },
          },
          audio: true,
        });

        currentStream = stream;
        streamRef.current = stream;

        if (cameraVideoRef.current) {
          cameraVideoRef.current.srcObject = stream;
          cameraVideoRef.current.play().catch(() => {});
        }
        setCameraActive(true);
        setCameraError(false);
      } catch (err) {
        setCameraError(true);
        setCameraActive(false);
      }
    }

    initCamera();

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [facingMode, studioMode]);

  // 2. Recording Timer Loop
  useEffect(() => {
    let interval: any;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordSeconds((s) => {
          if (s >= durationLimit) {
            stopRecording();
            return durationLimit;
          }
          return s + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording, durationLimit]);

  // Start countdown before recording if countdown is configured
  const handleShutterPress = () => {
    if (isRecording) {
      stopRecording();
      return;
    }

    if (countdownTimer > 0) {
      setIsCountingDown(true);
      setCountdownCount(countdownTimer);
      const countdownInterval = setInterval(() => {
        setCountdownCount((prev) => {
          if (prev <= 1) {
            clearInterval(countdownInterval);
            setIsCountingDown(false);
            startRecording();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      startRecording();
    }
  };

  // Start MediaRecorder capture
  const startRecording = () => {
    recordedChunksRef.current = [];
    setRecordSeconds(0);

    if (streamRef.current) {
      try {
        const mimeTypes = ['video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
        let supportedMime = mimeTypes.find((m) => MediaRecorder.isTypeSupported(m)) || '';

        const recorder = supportedMime
          ? new MediaRecorder(streamRef.current, { mimeType: supportedMime })
          : new MediaRecorder(streamRef.current);

        recorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            recordedChunksRef.current.push(event.data);
          }
        };

        recorder.onstop = () => {
          const blob = new Blob(recordedChunksRef.current, {
            type: recorder.mimeType || 'video/webm',
          });
          const localUrl = URL.createObjectURL(blob);
          setSelectedFile(blob);
          setVideoUrl(localUrl);
          setPosterUrl(currentUser.avatar);
          setVideoMetadata({
            name: `ViralFlow_Recording_${Date.now().toString().slice(-4)}.mp4`,
            duration: recordSeconds || 15,
            sizeMB: `${(blob.size / (1024 * 1024)).toFixed(1)} MB`,
            resolution: '1080 × 1920 (9:16)',
            format: blob.type || 'video/mp4',
          });
          setTrimStart(0);
          setTrimEnd(recordSeconds || 15);
          setStudioMode('edit');
          setUploadError(null);
        };

        recorder.start(250);
        mediaRecorderRef.current = recorder;
        setIsRecording(true);
      } catch (e) {
        // Fallback for mock/container simulation
        setIsRecording(true);
      }
    } else {
      setIsRecording(true);
    }
  };

  // Stop recording
  const stopRecording = () => {
    setIsRecording(false);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    } else {
      // Fallback: pick high-def sample video
      const sample = STUDIO_SAMPLE_VIDEOS[0];
      setSelectedFile(null);
      setVideoUrl(sample.url);
      setPosterUrl(sample.poster);
      setVideoMetadata({
        name: `${sample.title.replace(/\s+/g, '_')}.mp4`,
        duration: recordSeconds || 15,
        sizeMB: '7.8 MB',
        resolution: '1080 × 1920 (9:16)',
        format: 'video/mp4',
      });
      setTrimStart(0);
      setTrimEnd(sample.duration);
      setStudioMode('edit');
      setUploadError(null);
    }
  };

  // Handle local gallery video upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Only allow authenticated users to upload videos
    if (!auth.currentUser && !currentUser.uid) {
      setShowAuthPrompt(true);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const fileUrl = URL.createObjectURL(file);
    const sizeInMB = (file.size / (1024 * 1024)).toFixed(1);

    setSelectedFile(file);
    setVideoUrl(fileUrl);
    setPosterUrl(currentUser.avatar);
    setVideoMetadata({
      name: file.name,
      duration: 15,
      sizeMB: `${sizeInMB} MB`,
      resolution: '1080 × 1920 (9:16)',
      format: file.type || 'video/mp4',
    });
    setTrimStart(0);
    setTrimEnd(15);
    setStudioMode('edit');
    setUploadError(null);
  };

  // Handle selecting a pre-made studio sample video
  const handleSelectSampleClip = (sample: typeof STUDIO_SAMPLE_VIDEOS[0]) => {
    setSelectedFile(null);
    setVideoUrl(sample.url);
    setPosterUrl(sample.poster);
    setVideoMetadata({
      name: `${sample.title.replace(/\s+/g, '_')}.mp4`,
      duration: sample.duration,
      sizeMB: '8.2 MB',
      resolution: '1080 × 1920 (9:16)',
      format: 'video/mp4',
    });
    setTrimStart(0);
    setTrimEnd(sample.duration);
    setStudioMode('edit');
    setUploadError(null);
  };

  // Capture thumbnail frame from current preview video
  const captureThumbnailBlob = useCallback(async (): Promise<Blob | null> => {
    if (thumbnailBlob) return thumbnailBlob;
    const video = previewVideoRef.current;
    if (!video) return null;
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 720;
      canvas.height = video.videoHeight || 1280;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      return new Promise<Blob | null>((resolve) => {
        canvas.toBlob(
          (blob) => {
            if (blob) {
              setThumbnailBlob(blob);
              resolve(blob);
            } else {
              resolve(null);
            }
          },
          'image/jpeg',
          0.85
        );
      });
    } catch (err) {
      console.warn('Could not generate canvas thumbnail:', err);
      return null;
    }
  }, [thumbnailBlob]);

  // Preview video time tracking & loop within trim bounds
  const handlePreviewTimeUpdate = () => {
    const videoEl = previewVideoRef.current;
    if (!videoEl) return;

    const ct = videoEl.currentTime;
    setCurrentTime(ct);

    // Loop strictly inside trimmed window
    if (ct < trimStart) {
      videoEl.currentTime = trimStart;
    } else if (ct >= trimEnd) {
      videoEl.currentTime = trimStart;
    }
  };

  const togglePreviewPlay = () => {
    const videoEl = previewVideoRef.current;
    if (!videoEl) return;
    if (isPlaying) {
      videoEl.pause();
      setIsPlaying(false);
    } else {
      videoEl.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  // Add custom hashtag from input
  const handleAddCustomTag = () => {
    let clean = customTagInput.trim();
    if (!clean) return;
    if (!clean.startsWith('#')) clean = `#${clean}`;
    if (!selectedTags.includes(clean)) {
      setSelectedTags([...selectedTags, clean]);
    }
    setCustomTagInput('');
  };

  // Execute real upload to Firebase Storage and publish to Firestore videos collection
  const handlePost = async () => {
    // 1. Authenticated user validation
    const user = auth.currentUser;
    if (!user && !currentUser.uid) {
      setShowAuthPrompt(true);
      return;
    }

    const userId = user?.uid || currentUser.uid!;
    const userName = currentUser.name || user?.displayName || 'ViralFlow Creator';
    const userPhoto = currentUser.avatar || user?.photoURL || DEFAULT_AVATAR;

    setStudioMode('uploading');
    setIsUploading(true);
    setUploadError(null);
    setUploadProgress(5);
    setUploadStatusText('Preparing video stream for processing...');

    try {
      let finalVideoUrl = videoUrl;
      let finalThumbnailUrl = posterUrl || userPhoto;

      // 2. Storage upload if custom file was selected or recorded
      const fileToUpload: File | Blob | null = selectedFile;

      if (fileToUpload) {
        setUploadProgress(15);
        setUploadStatusText('Uploading video to cloud storage...');

        // Will throw clear user-friendly message since Cloud Storage is on Spark plan
        const uploadRes = await uploadVideoFileToStorage(
          fileToUpload,
          userId,
          (progressInfo) => {
            const scaled = Math.min(
              85,
              Math.max(15, Math.round(15 + progressInfo.progress * 0.7))
            );
            setUploadProgress(scaled);
          }
        );

        finalVideoUrl = uploadRes.downloadUrl;
        setUploadProgress(88);
        setUploadStatusText('Generating cover thumbnail...');

        try {
          const tBlob = await captureThumbnailBlob();
          if (tBlob) {
            const thumbDownloadUrl = await uploadThumbnailToStorage(tBlob, userId);
            finalThumbnailUrl = thumbDownloadUrl;
          }
        } catch (tErr) {
          console.warn('Cover upload note:', tErr);
        }
      } else if (!finalVideoUrl) {
        finalVideoUrl = STUDIO_SAMPLE_VIDEOS[0].url;
        finalThumbnailUrl = STUDIO_SAMPLE_VIDEOS[0].poster;
      }

      setUploadProgress(92);
      setUploadStatusText('Saving video metadata to Firestore...');

      // 4. Create document in Firestore "videos" collection with all required schema fields
      const fullCaption = caption.trim();
      const hashtagsStr = selectedTags.join(' ');
      const musicString = `${selectedSound.title} • ${selectedSound.artist}`;

      const videoDoc = await publishVideoToFirestore({
        ownerId: userId,
        ownerName: userName,
        ownerPhoto: userPhoto,
        videoUrl: finalVideoUrl,
        thumbnailUrl: finalThumbnailUrl,
        caption: fullCaption,
        hashtags: hashtagsStr,
        musicName: musicString,
      });

      setUploadProgress(100);
      setUploadStatusText('Video published successfully! 🎉');

      // 5. Build published VideoItem for immediate local feed & profile display
      const newVideo: VideoItem = {
        id: videoDoc.videoId,
        videoUrl: videoDoc.videoUrl,
        posterUrl: videoDoc.thumbnailUrl || finalThumbnailUrl,
        creator: {
          id: userId,
          name: userName,
          username: currentUser.username,
          avatar: userPhoto,
          isVerified: true,
          isFollowing: false,
          followers: currentUser.followersCount,
          bio: currentUser.bio,
        },
        caption: fullCaption,
        tags: selectedTags,
        music: {
          id: selectedSound.id,
          title: selectedSound.title,
          artist: selectedSound.artist,
          albumArt: selectedSound.albumArt,
          duration: selectedSound.duration,
        },
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        savesCount: 0,
        isLiked: false,
        isSaved: false,
        views: '1',
        category: 'Trending',
        createdAt: 'Just now',
      };

      setPostedVideoResult(newVideo);
      setIsUploading(false);
      setStudioMode('posted');

      // Trigger celebration confetti
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#38bdf8', '#a855f7', '#ec4899', '#fbbf24'],
        });
      } catch {
        // graceful
      }
    } catch (err: any) {
      console.error('Video upload and publish error:', err);
      setIsUploading(false);
      setUploadError(
        err?.message ||
          'Failed to process and publish video. Please verify your connection and try again.'
      );
    }
  };

  // Finalize navigation after successful post
  const handleFinishPost = (targetTab: TabType = 'home') => {
    if (postedVideoResult) {
      onPostVideo(postedVideoResult, targetTab);
    } else {
      onClose();
    }
  };

  // Filter sounds for drawer
  const filteredSounds = SAMPLE_SOUNDS.filter((s) => {
    const matchesSearch =
      s.title.toLowerCase().includes(soundSearch.toLowerCase()) ||
      s.artist.toLowerCase().includes(soundSearch.toLowerCase());
    const matchesCategory =
      selectedSoundCategory === 'All' || s.category === selectedSoundCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="relative w-full h-full bg-slate-950 text-white flex flex-col overflow-hidden select-none font-sans">
      {/* Soft Front Ring-Light Simulation overlay */}
      {ringLightOn && studioMode === 'record' && (
        <div className="absolute inset-0 z-40 pointer-events-none border-[24px] border-white/90 shadow-[inset_0_0_80px_rgba(255,255,255,0.8)]" />
      )}

      {/* 3-2-1 Countdown Overlay */}
      {isCountingDown && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md">
          <span className="text-8xl font-black text-white animate-ping drop-shadow-[0_0_30px_rgba(236,72,153,0.9)]">
            {countdownCount}
          </span>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODE 1: RECORD & SELECT MEDIA                        */}
      {/* ---------------------------------------------------- */}
      {studioMode === 'record' && (
        <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
          {/* Top Bar Navigation */}
          <div className="relative z-30 pt-3 px-3.5 pb-2 flex items-center justify-between pointer-events-auto">
            {/* Close / Discard button */}
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center text-white hover:bg-black/60 active:scale-95 transition-all shadow-md"
              aria-label="Close Studio"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Selected Sound pill */}
            <button
              onClick={() => setActiveModal('sound')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-xs hover:bg-black/60 active:scale-95 transition-all shadow-md max-w-[200px]"
            >
              <Music className="w-3.5 h-3.5 text-pink-400 shrink-0 animate-pulse" />
              <span className="truncate font-semibold text-white/95">{selectedSound.title}</span>
            </button>

            {/* Ring-light Flash Toggle */}
            <button
              onClick={() => setRingLightOn((prev) => !prev)}
              className={`w-10 h-10 rounded-full flex items-center justify-center backdrop-blur-xl border border-white/20 transition-all active:scale-95 shadow-md ${
                ringLightOn
                  ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-[0_0_15px_rgba(251,191,36,0.6)]'
                  : 'bg-black/40 text-white hover:bg-black/60'
              }`}
              aria-label="Ring light"
            >
              <Zap className="w-4 h-4" />
            </button>
          </div>

          {/* Camera Viewport Canvas */}
          <div className="absolute inset-0 z-0 bg-slate-900 flex items-center justify-center overflow-hidden">
            <video
              ref={cameraVideoRef}
              playsInline
              muted
              autoPlay
              className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />

            {/* Camera Permission / Preview Fallback Card */}
            {(!cameraActive || cameraError) && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-tr from-slate-950 via-purple-950/80 to-slate-900">
                <div className="w-16 h-16 rounded-3xl bg-white/10 backdrop-blur-2xl border border-white/20 flex items-center justify-center mb-3 shadow-xl">
                  <Camera className="w-8 h-8 text-sky-300 animate-pulse" />
                </div>
                <h3 className="font-extrabold text-base text-white">ViralFlow Camera Ready</h3>
                <p className="text-xs text-slate-300 mt-1.5 max-w-xs leading-relaxed">
                  Record with live camera or upload any video directly from your device gallery.
                </p>

                {/* Quick select template clip */}
                <div className="mt-5 w-full max-w-xs">
                  <span className="text-[11px] font-bold text-sky-300 uppercase tracking-wider block mb-2">
                    Or Pick Studio Clip to Edit
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {STUDIO_SAMPLE_VIDEOS.slice(0, 3).map((sample) => (
                      <button
                        key={sample.id}
                        onClick={() => handleSelectSampleClip(sample)}
                        className="group relative rounded-xl overflow-hidden aspect-[9/16] border border-white/20 hover:border-sky-400 active:scale-95 transition-all"
                      >
                        <img
                          src={sample.poster}
                          alt={sample.title}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-1">
                          <span className="text-[9px] font-bold text-white truncate w-full text-left">
                            {sample.title}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Floating Quick Tools */}
          <div className="absolute right-3.5 top-20 z-20 flex flex-col items-center gap-3">
            {/* Flip Camera */}
            <button
              onClick={() => setFacingMode((m) => (m === 'user' ? 'environment' : 'user'))}
              className="flex flex-col items-center gap-1 group"
              aria-label="Flip camera"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <RotateCcw className="w-4 h-4 text-white" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Flip</span>
            </button>

            {/* Speed Toggle */}
            <button
              onClick={() => {
                if (recordingSpeed === '0.5x') setRecordingSpeed('1x');
                else if (recordingSpeed === '1x') setRecordingSpeed('2x');
                else setRecordingSpeed('0.5x');
              }}
              className="flex flex-col items-center gap-1 group"
              aria-label="Recording speed"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <span className="text-[11px] font-black text-amber-300">{recordingSpeed}</span>
              </div>
              <span className="text-[10px] font-semibold text-white/90">Speed</span>
            </button>

            {/* Duration limit toggle (15s vs 60s) */}
            <button
              onClick={() => setDurationLimit((d) => (d === 15 ? 60 : 15))}
              className="flex flex-col items-center gap-1 group"
              aria-label="Duration limit"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <Clock className="w-4 h-4 text-sky-400" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">{durationLimit}s</span>
            </button>

            {/* Countdown timer toggle (0, 3s, 10s) */}
            <button
              onClick={() => {
                if (countdownTimer === 0) setCountdownTimer(3);
                else if (countdownTimer === 3) setCountdownTimer(10);
                else setCountdownTimer(0);
              }}
              className="flex flex-col items-center gap-1 group"
              aria-label="Timer countdown"
            >
              <div
                className={`w-10 h-10 rounded-full backdrop-blur-xl border flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md ${
                  countdownTimer > 0
                    ? 'bg-pink-600/30 border-pink-400 text-pink-300'
                    : 'bg-black/40 border-white/20 text-white'
                }`}
              >
                <span className="text-[11px] font-bold">
                  {countdownTimer > 0 ? `${countdownTimer}s` : 'Off'}
                </span>
              </div>
              <span className="text-[10px] font-semibold text-white/90">Timer</span>
            </button>
          </div>

          {/* Bottom Shutter & Gallery Upload Bar */}
          <div className="relative z-30 pb-7 pt-4 px-6 bg-gradient-to-t from-black via-black/80 to-transparent">
            {/* Live recording indicator */}
            {isRecording && (
              <div className="flex items-center justify-center mb-3">
                <span className="px-3 py-1 rounded-full bg-rose-600/90 text-white text-xs font-black animate-pulse flex items-center gap-1.5 shadow-lg">
                  <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                  00:{recordSeconds < 10 ? `0${recordSeconds}` : recordSeconds} / 00:{durationLimit}
                </span>
              </div>
            )}

            <div className="flex items-center justify-around">
              {/* Device Gallery Upload Button */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center gap-1 group active:scale-95 transition-all"
                aria-label="Upload from gallery"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/25 flex items-center justify-center group-hover:bg-white/20 transition-colors shadow-lg">
                  <Upload className="w-5 h-5 text-sky-400 group-hover:scale-110 transition-transform" />
                </div>
                <span className="text-[11px] font-bold text-slate-200">Gallery</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleFileChange}
              />

              {/* Shutter Button with Animated Progress Ring */}
              <div className="relative flex items-center justify-center">
                <button
                  onClick={handleShutterPress}
                  className="relative w-20 h-20 rounded-full p-1.5 flex items-center justify-center active:scale-95 transition-transform"
                  aria-label={isRecording ? 'Stop Recording' : 'Start Recording'}
                >
                  {/* Outer animated border ring */}
                  <div
                    className={`absolute inset-0 rounded-full border-[3.5px] transition-all duration-300 ${
                      isRecording ? 'border-rose-500 scale-105 animate-pulse' : 'border-white/80'
                    }`}
                  />
                  {/* Inner button */}
                  <div
                    className={`transition-all duration-300 ${
                      isRecording
                        ? 'w-8 h-8 rounded-lg bg-rose-500 shadow-[0_0_25px_rgba(244,63,94,0.9)]'
                        : 'w-full h-full rounded-full bg-gradient-to-tr from-sky-400 via-purple-600 to-pink-500 shadow-xl'
                    }`}
                  />
                </button>
              </div>

              {/* Studio Sample Clips Trigger */}
              <button
                onClick={() => handleSelectSampleClip(STUDIO_SAMPLE_VIDEOS[0])}
                className="flex flex-col items-center gap-1 group active:scale-95 transition-all"
                aria-label="Sample clip"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/25 flex items-center justify-center group-hover:bg-white/20 transition-colors shadow-lg">
                  <Film className="w-5 h-5 text-purple-400 group-hover:scale-110 transition-transform" />
                </div>
                <span className="text-[11px] font-bold text-slate-200">Samples</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODE 2: EDIT, TRIM, ADD AUDIO & POLISH STUDIO        */}
      {/* ---------------------------------------------------- */}
      {studioMode === 'edit' && (
        <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
          {/* Top Bar Controls */}
          <div className="relative z-30 pt-3 px-3.5 pb-2 flex items-center justify-between pointer-events-auto">
            {/* Back to capture */}
            <button
              onClick={() => setStudioMode('record')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-xs hover:bg-black/60 active:scale-95 transition-all shadow-md"
              aria-label="Back"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Retake</span>
            </button>

            {/* Audio Pill */}
            <button
              onClick={() => setActiveModal('sound')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-xs hover:bg-black/60 active:scale-95 transition-all shadow-md max-w-[180px]"
            >
              <Music className="w-3.5 h-3.5 text-pink-400 shrink-0" />
              <span className="truncate font-semibold text-white/95">{selectedSound.title}</span>
            </button>

            {/* File Info Toggle */}
            <button
              onClick={() => setActiveModal('info')}
              className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center hover:bg-black/60 active:scale-95 transition-all shadow-md"
              aria-label="Video File Info"
            >
              <Info className="w-4 h-4 text-sky-300" />
            </button>
          </div>

          {/* Full Screen 9:16 Video Preview Viewport */}
          <div
            className="absolute inset-0 z-0 bg-black flex items-center justify-center overflow-hidden cursor-pointer"
            onClick={togglePreviewPlay}
          >
            <video
              ref={previewVideoRef}
              src={videoUrl}
              poster={posterUrl}
              playsInline
              loop
              autoPlay
              onTimeUpdate={handlePreviewTimeUpdate}
              className="w-full h-full object-cover"
            />

            {/* Pause indicator */}
            {!isPlaying && (
              <div className="absolute z-20 pointer-events-none w-16 h-16 rounded-full bg-black/50 backdrop-blur-xl border border-white/20 flex items-center justify-center text-white shadow-2xl">
                <Play className="w-7 h-7 fill-white ml-1" />
              </div>
            )}

            {/* Real-time Rendered Text Overlay */}
            {overlayText.text && (
              <div
                className={`absolute z-20 px-4 py-2 rounded-2xl transition-all select-none pointer-events-none ${
                  overlayText.position === 'top'
                    ? 'top-24'
                    : overlayText.position === 'bottom'
                    ? 'bottom-40'
                    : 'top-1/2 -translate-y-1/2'
                } left-1/2 -translate-x-1/2 max-w-[85%] text-center ${
                  overlayText.style === 'pill'
                    ? 'bg-black/60 backdrop-blur-xl border border-white/20 shadow-2xl'
                    : overlayText.style === 'glow'
                    ? 'drop-shadow-[0_0_15px_rgba(236,72,153,0.9)] font-black'
                    : overlayText.style === 'script'
                    ? 'font-script text-2xl drop-shadow-md'
                    : 'font-bold'
                }`}
                style={{ color: overlayText.color }}
              >
                <span className="text-base tracking-wide">{overlayText.text}</span>
              </div>
            )}

            {/* Top gradient for readability */}
            <div className="absolute top-0 left-0 right-0 h-28 bg-gradient-to-b from-black/80 via-black/30 to-transparent pointer-events-none z-10" />

            {/* Bottom gradient for controls */}
            <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-black via-black/70 to-transparent pointer-events-none z-10" />
          </div>

          {/* Right Floating Studio Tools Column */}
          <div className="absolute right-3 top-20 z-20 flex flex-col items-center gap-3 pointer-events-auto">
            {/* Trim Video */}
            <button
              onClick={() => setActiveModal('trim')}
              className="flex flex-col items-center gap-1 group"
              aria-label="Trim Video"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <Scissors className="w-4 h-4 text-sky-400" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Trim</span>
            </button>

            {/* Add Music / Sound */}
            <button
              onClick={() => setActiveModal('sound')}
              className="flex flex-col items-center gap-1 group"
              aria-label="Music Audio"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <Music className="w-4 h-4 text-pink-400" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Sound</span>
            </button>

            {/* Add Text Sticker */}
            <button
              onClick={() => setActiveModal('text')}
              className="flex flex-col items-center gap-1 group"
              aria-label="Add Text"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <Type className="w-4 h-4 text-amber-300" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Text</span>
            </button>

            {/* Add Hashtags */}
            <button
              onClick={() => setActiveModal('hashtags')}
              className="flex flex-col items-center gap-1 group"
              aria-label="Hashtags"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <Hash className="w-4 h-4 text-purple-400" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Tags</span>
            </button>

            {/* Choose Thumbnail Cover */}
            <button
              onClick={() => setActiveModal('thumbnail')}
              className="flex flex-col items-center gap-1 group"
              aria-label="Choose Thumbnail"
            >
              <div className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 flex items-center justify-center group-hover:bg-black/60 group-active:scale-90 transition-all shadow-md">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-[10px] font-semibold text-white/90">Cover</span>
            </button>
          </div>

          {/* Bottom Edit & Post Tray */}
          <div className="relative z-30 pb-6 pt-3 px-4 bg-slate-950/90 backdrop-blur-2xl border-t border-white/10 space-y-3 pointer-events-auto">
            {/* Caption Input with Character Counter & Quick Emojis */}
            <div className="relative">
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value.slice(0, 220))}
                rows={2}
                placeholder="Write a caption for your viral flow... ✨"
                className="w-full bg-white/10 text-white text-xs px-3.5 py-2.5 rounded-2xl border border-white/15 focus:outline-none focus:ring-2 focus:ring-purple-400 resize-none leading-relaxed placeholder:text-slate-400"
              />
              <span className="absolute right-3 bottom-2.5 text-[10px] text-slate-400 font-mono">
                {caption.length}/220
              </span>
            </div>

            {/* Quick Emoji Strip & Active Hashtag Chips */}
            <div className="flex items-center justify-between gap-2 overflow-x-auto no-scrollbar py-0.5">
              {/* Emojis */}
              <div className="flex items-center gap-1 shrink-0">
                {EMOJI_TOOLBAR.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => setCaption((c) => (c + ' ' + emoji).slice(0, 220))}
                    className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/15 flex items-center justify-center text-sm transition-transform active:scale-125"
                  >
                    {emoji}
                  </button>
                ))}
              </div>

              {/* Tag Chips */}
              <div className="flex items-center gap-1 shrink-0">
                {selectedTags.map((tag) => (
                  <span
                    key={tag}
                    onClick={() => setSelectedTags(selectedTags.filter((t) => t !== tag))}
                    className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-sky-400 to-pink-500 text-white cursor-pointer hover:opacity-80 active:scale-95"
                  >
                    {tag} ×
                  </span>
                ))}
              </div>
            </div>

            {/* Duration & File Info Pill */}
            <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-[11px] text-slate-300">
              <div className="flex items-center gap-2">
                <FileVideo className="w-3.5 h-3.5 text-sky-400" />
                <span className="font-semibold">{videoMetadata.name}</span>
              </div>
              <div className="flex items-center gap-2 font-mono text-[10px] text-slate-400">
                <span>{(trimEnd - trimStart).toFixed(1)}s</span>
                <span>•</span>
                <span>{videoMetadata.sizeMB}</span>
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="flex items-center gap-3 pt-1">
              <button
                onClick={() => setStudioMode('record')}
                className="py-3 px-4 rounded-2xl bg-white/10 text-slate-300 text-xs font-bold hover:bg-white/20 active:scale-95 transition-all"
              >
                Discard
              </button>

              {/* Primary POST button with Liquid-Glass Styling */}
              <button
                onClick={handlePost}
                className="flex-1 liquid-gradient-btn py-3.5 px-6 rounded-2xl text-white font-black text-sm flex items-center justify-center gap-2 shadow-[0_10px_25px_-5px_rgba(168,85,247,0.5)] active:scale-98 transition-transform"
              >
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                <span>Post to ViralFlow</span>
                <Send className="w-4 h-4 ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODE 3: UPLOADING & TRANSCODING PROGRESS OVERLAY     */}
      {/* ---------------------------------------------------- */}
      {studioMode === 'uploading' && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl">
          <div className="w-full max-w-sm rounded-3xl p-6 bg-slate-900/90 border border-white/20 shadow-2xl flex flex-col items-center text-center">
            {uploadError ? (
              <div className="w-full flex flex-col items-center">
                <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-3 shadow-[0_0_20px_rgba(244,63,94,0.3)]">
                  <AlertCircle className="w-8 h-8" />
                </div>
                <h3 className="font-extrabold text-base text-white">Upload Error</h3>
                <p className="text-xs text-rose-300 mt-2 font-medium px-2 leading-relaxed">
                  {uploadError}
                </p>
                <div className="flex items-center gap-2.5 w-full mt-6">
                  <button
                    onClick={() => {
                      setUploadError(null);
                      setStudioMode('edit');
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-300 text-xs font-bold transition-all"
                  >
                    Back to Edit
                  </button>
                  <button
                    onClick={handlePost}
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-pink-500 hover:opacity-95 text-white text-xs font-black shadow-lg transition-all flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Retry Upload</span>
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Iridescent Spinning Ring */}
                <div className="relative w-24 h-24 mb-4 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border-4 border-white/10" />
                  <div
                    className="absolute inset-0 rounded-full border-4 border-t-pink-500 border-r-purple-500 border-b-sky-400 border-l-transparent animate-spin"
                    style={{ animationDuration: '1.2s' }}
                  />
                  <span className="font-mono font-black text-lg text-white">
                    {uploadProgress}%
                  </span>
                </div>

                <h3 className="font-extrabold text-base text-white">Publishing Video</h3>
                <p className="text-xs text-sky-300 mt-1 font-medium animate-pulse">
                  {uploadStatusText}
                </p>

                {/* Gradient progress bar */}
                <div className="w-full h-2 rounded-full bg-white/10 overflow-hidden mt-4 border border-white/10">
                  <div
                    className="h-full bg-gradient-to-r from-sky-400 via-purple-500 to-pink-500 transition-all duration-300 rounded-full"
                    style={{ width: `${uploadProgress}%` }}
                  />
                </div>

                <span className="text-[10px] text-slate-400 mt-3">
                  Video metadata and catalog synchronized to Firestore
                </span>
              </>
            )}
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* MODE 4: SUCCESS "POSTED!" CONFIRMATION SCREEN        */}
      {/* ---------------------------------------------------- */}
      {studioMode === 'posted' && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl p-6 bg-slate-900/95 border border-white/20 shadow-[0_20px_50px_rgba(168,85,247,0.3)] flex flex-col items-center text-center">
            {/* Celebratory Checkmark */}
            <div className="w-18 h-18 rounded-full bg-gradient-to-tr from-sky-400 via-purple-500 to-pink-500 p-[3px] shadow-[0_0_35px_rgba(236,72,153,0.7)] mb-4 animate-bounce">
              <div className="w-full h-full rounded-full bg-slate-950 flex items-center justify-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-400" />
              </div>
            </div>

            <h2 className="font-black text-xl text-white">Posted! 🎉</h2>
            <p className="text-xs text-slate-300 mt-1 max-w-xs leading-relaxed">
              Your video is now officially live on the ViralFlow feed and visible in your creator profile.
            </p>

            {/* Video Snapshot Mini Card */}
            <div className="w-full mt-4 p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3 text-left">
              <div className="w-12 h-16 rounded-xl overflow-hidden bg-slate-800 shrink-0 border border-white/20">
                <img
                  src={posterUrl || currentUser.avatar}
                  alt="Cover"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <span className="text-xs font-bold text-white truncate block">
                  {caption || 'ViralFlow Studio Video'}
                </span>
                <span className="text-[10px] text-sky-400 font-semibold block mt-0.5 truncate">
                  {selectedTags.join(' ')}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  ♫ {selectedSound.title}
                </span>
              </div>
            </div>

            {/* Navigation options */}
            <div className="w-full flex flex-col gap-2 mt-5">
              <button
                onClick={() => handleFinishPost('home')}
                className="liquid-gradient-btn w-full py-3 rounded-2xl text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Watch in For You Feed</span>
              </button>

              <button
                onClick={() => handleFinishPost('profile')}
                className="w-full py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-semibold text-xs transition-colors active:scale-95"
              >
                View in My Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------------------------- */}
      {/* DRAWER MODALS: TRIM, SOUND, TEXT, HASHTAGS, INFO     */}
      {/* ---------------------------------------------------- */}

      {/* 1. TRIM MODAL */}
      {activeModal === 'trim' && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-3">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Scissors className="w-4 h-4 text-sky-400" />
                <h4 className="font-bold text-sm">Trim Video Clip</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            {/* Selected duration summary */}
            <div className="flex items-center justify-between text-xs text-slate-300 mb-3 px-1">
              <span>Start: {trimStart.toFixed(1)}s</span>
              <span className="font-bold text-sky-300">
                Duration: {(trimEnd - trimStart).toFixed(1)}s
              </span>
              <span>End: {trimEnd.toFixed(1)}s</span>
            </div>

            {/* Visual Frame Strip Representation */}
            <div className="relative w-full h-14 rounded-xl overflow-hidden bg-slate-800 border border-white/20 mb-4 flex">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="flex-1 h-full border-r border-white/10 overflow-hidden">
                  <img
                    src={posterUrl || currentUser.avatar}
                    alt="Frame"
                    className="w-full h-full object-cover opacity-60"
                  />
                </div>
              ))}

              {/* Active Selection Window Highlight */}
              <div
                className="absolute top-0 bottom-0 border-2 border-amber-400 bg-amber-400/20 rounded-md"
                style={{
                  left: `${(trimStart / (videoMetadata.duration || 15)) * 100}%`,
                  right: `${100 - (trimEnd / (videoMetadata.duration || 15)) * 100}%`,
                }}
              />
            </div>

            {/* Start slider */}
            <div className="space-y-1 mb-3">
              <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                Start Point
              </label>
              <input
                type="range"
                min={0}
                max={Math.max(0, trimEnd - 1)}
                step={0.5}
                value={trimStart}
                onChange={(e) => setTrimStart(parseFloat(e.target.value))}
                className="w-full accent-sky-400"
              />
            </div>

            {/* End slider */}
            <div className="space-y-1 mb-4">
              <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                End Point
              </label>
              <input
                type="range"
                min={trimStart + 1}
                max={videoMetadata.duration || 15}
                step={0.5}
                value={trimEnd}
                onChange={(e) => setTrimEnd(parseFloat(e.target.value))}
                className="w-full accent-pink-500"
              />
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="liquid-gradient-btn w-full py-2.5 rounded-2xl text-white font-bold text-xs"
            >
              Apply Trim
            </button>
          </div>
        </div>
      )}

      {/* 2. SOUND PICKER MODAL */}
      {activeModal === 'sound' && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-3">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Music className="w-4 h-4 text-pink-400" />
                <h4 className="font-bold text-sm">ViralFlow Sounds Library</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            {/* Sound Search */}
            <input
              type="text"
              value={soundSearch}
              onChange={(e) => setSoundSearch(e.target.value)}
              placeholder="Search trending audio, artists..."
              className="w-full px-3.5 py-2 rounded-xl bg-white/10 text-xs border border-white/10 focus:outline-none focus:ring-1 focus:ring-purple-400 mb-3"
            />

            {/* Category pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar mb-3">
              {['All', 'Trending', 'Chill Lofi', 'Electronic', 'Acoustic'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedSoundCategory(cat)}
                  className={`px-2.5 py-1 rounded-full text-[10px] font-bold whitespace-nowrap transition-colors ${
                    selectedSoundCategory === cat
                      ? 'bg-purple-600 text-white'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Audio Tracks List */}
            <div className="space-y-2 max-h-52 overflow-y-auto no-scrollbar mb-4">
              {filteredSounds.map((s) => (
                <div
                  key={s.id}
                  onClick={() => setSelectedSound(s)}
                  className={`p-2.5 rounded-2xl flex items-center justify-between cursor-pointer transition-all ${
                    selectedSound.id === s.id
                      ? 'bg-gradient-to-r from-sky-500/20 to-purple-500/20 border border-purple-400/40'
                      : 'bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={s.albumArt}
                      alt={s.title}
                      className="w-9 h-9 rounded-lg object-cover"
                    />
                    <div className="min-w-0">
                      <span className="font-bold text-xs text-white truncate block">
                        {s.title}
                      </span>
                      <span className="text-[10px] text-slate-400 truncate block">
                        {s.artist} • {s.duration}
                      </span>
                    </div>
                  </div>
                  {selectedSound.id === s.id && (
                    <Check className="w-4 h-4 text-pink-400 shrink-0" />
                  )}
                </div>
              ))}
            </div>

            {/* Volume Mix Balancer */}
            <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 mb-3 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-300">Original Audio</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={originalAudioVolume}
                  onChange={(e) => setOriginalAudioVolume(parseInt(e.target.value))}
                  className="w-32 accent-sky-400"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-300">Soundtrack</span>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={soundtrackVolume}
                  onChange={(e) => setSoundtrackVolume(parseInt(e.target.value))}
                  className="w-32 accent-pink-500"
                />
              </div>
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="liquid-gradient-btn w-full py-2.5 rounded-2xl text-white font-bold text-xs"
            >
              Set Soundtrack
            </button>
          </div>
        </div>
      )}

      {/* 3. TEXT STICKER MODAL */}
      {activeModal === 'text' && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-3">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Type className="w-4 h-4 text-amber-300" />
                <h4 className="font-bold text-sm">Add Text Overlay</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            {/* Text input */}
            <input
              type="text"
              value={overlayText.text}
              onChange={(e) => setOverlayText({ ...overlayText, text: e.target.value })}
              placeholder="Type your message... e.g. Be You ♡"
              className="w-full px-3.5 py-2.5 rounded-xl bg-white/10 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-purple-400 mb-3"
            />

            {/* Typography Styles */}
            <div className="grid grid-cols-4 gap-1.5 mb-3">
              {(['modern', 'glow', 'pill', 'script'] as const).map((style) => (
                <button
                  key={style}
                  onClick={() => setOverlayText({ ...overlayText, style })}
                  className={`py-1.5 rounded-xl text-[10px] font-bold capitalize transition-colors ${
                    overlayText.style === style
                      ? 'bg-purple-600 text-white'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>

            {/* Position Picker */}
            <div className="flex items-center justify-around mb-4 bg-white/5 p-1 rounded-xl text-[10px] font-semibold text-slate-300">
              {(['top', 'center', 'bottom'] as const).map((pos) => (
                <button
                  key={pos}
                  onClick={() => setOverlayText({ ...overlayText, position: pos })}
                  className={`px-3 py-1 rounded-lg capitalize transition-colors ${
                    overlayText.position === pos ? 'bg-white/20 text-white font-bold' : ''
                  }`}
                >
                  {pos}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setOverlayText({ text: '', style: 'glow', color: '#ffffff', position: 'center' });
                  setActiveModal('none');
                }}
                className="py-2.5 px-3 rounded-2xl bg-white/10 text-xs font-semibold hover:bg-white/20"
              >
                Clear
              </button>
              <button
                onClick={() => setActiveModal('none')}
                className="liquid-gradient-btn flex-1 py-2.5 rounded-2xl text-white font-bold text-xs"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. HASHTAGS MODAL */}
      {activeModal === 'hashtags' && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-3">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-purple-400" />
                <h4 className="font-bold text-sm">Add Hashtags</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            {/* Custom tag input */}
            <div className="flex items-center gap-2 mb-3">
              <input
                type="text"
                value={customTagInput}
                onChange={(e) => setCustomTagInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddCustomTag()}
                placeholder="#AddCustomTag"
                className="flex-1 px-3.5 py-2 rounded-xl bg-white/10 text-xs border border-white/10 focus:outline-none focus:ring-1 focus:ring-purple-400"
              />
              <button
                onClick={handleAddCustomTag}
                className="px-3.5 py-2 rounded-xl bg-purple-600 text-xs font-bold hover:bg-purple-700"
              >
                Add
              </button>
            </div>

            {/* Suggested trending tags */}
            <div className="space-y-1 mb-4">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">
                Trending on ViralFlow
              </span>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {TRENDING_HASHTAGS.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => {
                      if (selectedTags.includes(tag)) {
                        setSelectedTags(selectedTags.filter((t) => t !== tag));
                      } else {
                        setSelectedTags([...selectedTags, tag]);
                      }
                    }}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-all ${
                      selectedTags.includes(tag)
                        ? 'bg-gradient-to-r from-sky-400 to-pink-500 text-white shadow-md'
                        : 'bg-white/10 text-slate-300 hover:bg-white/15'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="liquid-gradient-btn w-full py-2.5 rounded-2xl text-white font-bold text-xs"
            >
              Done ({selectedTags.length} tags)
            </button>
          </div>
        </div>
      )}

      {/* 5. THUMBNAIL / COVER PICKER MODAL */}
      {activeModal === 'thumbnail' && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm p-3">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-sm">Choose Video Cover</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              Scrub to pick the keyframe frame that will appear on creator profile grids and search cards.
            </p>

            {/* Frame Scrubber Selector */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {[15, 35, 60, 85].map((pct) => (
                <button
                  key={pct}
                  onClick={() => {
                    setThumbnailPercent(pct);
                    if (previewVideoRef.current) {
                      previewVideoRef.current.currentTime =
                        (pct / 100) * (videoMetadata.duration || 15);
                    }
                  }}
                  className={`relative rounded-xl overflow-hidden aspect-[9/16] border-2 transition-all ${
                    thumbnailPercent === pct
                      ? 'border-pink-500 shadow-[0_0_12px_rgba(236,72,153,0.7)] scale-105'
                      : 'border-white/10 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={posterUrl || currentUser.avatar}
                    alt={`Frame ${pct}%`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-1 right-1 px-1 rounded bg-black/70 text-[8px] font-mono">
                    {pct}%
                  </div>
                </button>
              ))}
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="liquid-gradient-btn w-full py-2.5 rounded-2xl text-white font-bold text-xs"
            >
              Set Selected Frame
            </button>
          </div>
        </div>
      )}

      {/* 6. FILE INFO MODAL */}
      {activeModal === 'info' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-slate-900/95 backdrop-blur-2xl rounded-3xl p-5 text-white border border-white/20 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-sky-400" />
                <h4 className="font-bold text-sm">Video Stream Metadata</h4>
              </div>
              <button onClick={() => setActiveModal('none')}>
                <X className="w-4 h-4 text-slate-400 hover:text-white" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300 mb-4 divide-y divide-white/10">
              <div className="flex justify-between pt-1">
                <span className="text-slate-400">File Name:</span>
                <span className="font-semibold text-white truncate max-w-[180px]">
                  {videoMetadata.name}
                </span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">Aspect Ratio:</span>
                <span className="font-semibold text-sky-300">9:16 Full Vertical</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">Resolution:</span>
                <span className="font-semibold text-white">{videoMetadata.resolution}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">Trimmed Duration:</span>
                <span className="font-semibold text-white font-mono">
                  {(trimEnd - trimStart).toFixed(1)} seconds
                </span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">File Size:</span>
                <span className="font-semibold text-white font-mono">
                  {videoMetadata.sizeMB}
                </span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">Codec / Format:</span>
                <span className="font-semibold text-white">{videoMetadata.format}</span>
              </div>
              <div className="flex justify-between pt-2">
                <span className="text-slate-400">Soundtrack:</span>
                <span className="font-semibold text-pink-400 truncate max-w-[180px]">
                  {selectedSound.title}
                </span>
              </div>
            </div>

            <button
              onClick={() => setActiveModal('none')}
              className="w-full py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* 8. AUTHENTICATION REQUIRED PROMPT */}
      {showAuthPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm rounded-3xl p-6 bg-slate-900/95 border border-white/20 shadow-[0_20px_50px_rgba(168,85,247,0.3)] flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500/30 to-pink-500/30 border border-purple-500/40 flex items-center justify-center text-purple-300 mb-4 shadow-[0_0_25px_rgba(168,85,247,0.4)]">
              <LogIn className="w-7 h-7 text-pink-400" />
            </div>

            <h3 className="font-black text-lg text-white">Sign In to Post Videos</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed max-w-xs">
              Only authenticated creators can publish short videos to the public For You feed and sync metadata to Firestore.
            </p>

            <div className="w-full flex flex-col gap-2.5 mt-6">
              <button
                onClick={() => {
                  setShowAuthPrompt(false);
                  if (onRequireAuth) {
                    onRequireAuth();
                  } else {
                    onClose();
                  }
                }}
                className="liquid-gradient-btn w-full py-3 rounded-2xl text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-transform"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In / Create Account</span>
              </button>

              <button
                onClick={() => setShowAuthPrompt(false)}
                className="w-full py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-400 hover:text-white font-semibold text-xs transition-colors active:scale-95"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
