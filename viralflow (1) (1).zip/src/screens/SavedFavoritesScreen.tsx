import React, { useState } from 'react';
import {
  ArrowLeft,
  Heart,
  Bookmark,
  Play,
  Share2,
  Sparkles,
  Compass,
} from 'lucide-react';
import { VideoItem, UserProfile } from '../types';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';
import { VideoDetailModal } from '../components/VideoDetailModal';

interface SavedFavoritesScreenProps {
  currentUser: UserProfile;
  videos: VideoItem[];
  savedVideoIds: Set<string>;
  onBack: () => void;
  onNavigateExplore: () => void;
  onLikeToggle: (videoId: string) => void;
  onSaveToggle: (videoId: string) => void;
  onFollowToggle: (creatorId: string) => void;
  onSelectCreator: (creatorId: string) => void;
}

export const SavedFavoritesScreen: React.FC<SavedFavoritesScreenProps> = ({
  currentUser,
  videos,
  savedVideoIds,
  onBack,
  onNavigateExplore,
  onLikeToggle,
  onSaveToggle,
  onFollowToggle,
  onSelectCreator,
}) => {
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);

  // Filter videos that are in savedVideoIds
  const savedVideos = videos.filter((v) => savedVideoIds.has(v.id) || v.isSaved);

  const handleOpenVideo = (video: VideoItem) => {
    setSelectedVideo(video);
  };

  return (
    <LiquidGlassBackground>
      <div className="relative min-h-screen pb-24 px-4 pt-3 max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full liquid-glass-pill flex items-center justify-center text-slate-700 hover:bg-white transition-colors cursor-pointer"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-pink-500 to-rose-500 text-white flex items-center justify-center shadow-sm">
              <Bookmark className="w-4 h-4 fill-white" />
            </div>
            <h1 className="font-black text-base text-slate-900 tracking-tight">
              Share Favorites
            </h1>
          </div>

          <div className="w-9 h-9" /> {/* Spacer */}
        </div>

        {/* Subtitle Banner */}
        <div className="mb-4 liquid-glass-card rounded-2xl p-3.5 border border-pink-100 bg-white/70 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-black text-slate-800">
              Saved in Firestore
            </p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Your personal library of bookmarked clips
            </p>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-pink-50 text-pink-700 font-extrabold text-[11px] border border-pink-200">
            {savedVideos.length} {savedVideos.length === 1 ? 'Saved Clip' : 'Saved Clips'}
          </span>
        </div>

        {/* Saved Videos Grid */}
        {savedVideos.length === 0 ? (
          <div className="liquid-glass-card rounded-3xl p-8 text-center my-6 shadow-xs border border-white">
            <div className="w-14 h-14 rounded-2xl bg-pink-50 text-pink-500 flex items-center justify-center mx-auto mb-3">
              <Bookmark className="w-7 h-7" />
            </div>
            <h3 className="font-extrabold text-sm text-slate-800 mb-1">
              No saved favorites yet
            </h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto mb-5 leading-relaxed">
              Tap the bookmark ribbon icon on any video in your feed or explore to save your favorite moments to this collection.
            </p>
            <button
              onClick={onNavigateExplore}
              className="px-5 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 text-white text-xs font-bold shadow-md hover:shadow-lg transition-all active:scale-95 inline-flex items-center gap-2 cursor-pointer"
            >
              <Compass className="w-4 h-4" />
              <span>Explore The World</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {savedVideos.map((video) => (
              <div
                key={video.id}
                onClick={() => handleOpenVideo(video)}
                className="group relative aspect-[9/16] rounded-2xl overflow-hidden shadow-md cursor-pointer bg-slate-900 border border-white/10"
              >
                <img
                  src={video.posterUrl}
                  alt={video.caption}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />

                {/* Dark gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-black/30" />

                {/* Top bookmark badge */}
                <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center shadow-md">
                  <Bookmark className="w-3.5 h-3.5 fill-current" />
                </div>

                {/* Top view count */}
                <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md text-white text-[10px] font-bold">
                  <Play className="w-2.5 h-2.5 fill-white" />
                  <span>{video.views || '1.2k'}</span>
                </div>

                {/* Creator and caption bottom info */}
                <div className="absolute bottom-2 left-2 right-2 text-white">
                  <div className="flex items-center gap-1.5 mb-1">
                    <img
                      src={video.creator.avatar}
                      alt={video.creator.name}
                      className="w-5 h-5 rounded-full object-cover ring-1 ring-white"
                    />
                    <span className="text-[11px] font-bold truncate">
                      @{video.creator.username}
                    </span>
                  </div>
                  <p className="text-[10px] text-white/90 line-clamp-2 leading-tight">
                    {video.caption}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Video Detail Modal with Like, Comment, Save interaction */}
      <VideoDetailModal
        video={selectedVideo}
        isOpen={!!selectedVideo}
        onClose={() => setSelectedVideo(null)}
        currentUser={currentUser}
        onLikeToggle={onLikeToggle}
        onSaveToggle={onSaveToggle}
        onFollowToggle={onFollowToggle}
        onSelectCreator={onSelectCreator}
      />
    </LiquidGlassBackground>
  );
};
