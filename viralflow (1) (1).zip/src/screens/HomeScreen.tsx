import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  ChevronUp,
  ChevronDown,
  Sparkles,
  Camera,
  Users,
  Compass,
  Heart,
  X,
} from 'lucide-react';
import { VideoItem, FeedTabType, UserProfile, TabType } from '../types';
import { TopBar } from '../components/TopBar';
import { VideoFeedItem } from '../components/VideoFeedItem';
import { CommentsDrawer } from '../components/CommentsDrawer';
import { ShareModal } from '../components/ShareModal';

interface HomeScreenProps {
  videos: VideoItem[];
  currentUser: UserProfile;
  activeFeedTab: FeedTabType;
  onFeedTabChange: (tab: FeedTabType) => void;
  onLikeToggle: (id: string) => void;
  onSaveToggle: (id: string) => void;
  onFollowToggle: (creatorId: string) => void;
  onNavigateTab: (tab: TabType) => void;
  onSelectHashtag: (tag: string) => void;
  onSelectCreator: (creatorId: string) => void;
  onMeetRealPeople?: () => void;
  onExploreTheWorld?: () => void;
  onShareFavorites?: () => void;
  onCreateClick?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  videos,
  currentUser,
  activeFeedTab,
  onFeedTabChange,
  onLikeToggle,
  onSaveToggle,
  onFollowToggle,
  onNavigateTab,
  onSelectHashtag,
  onSelectCreator,
  onMeetRealPeople,
  onExploreTheWorld,
  onShareFavorites,
  onCreateClick,
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [activeCommentsVideo, setActiveCommentsVideo] = useState<VideoItem | null>(null);
  const [activeShareVideo, setActiveShareVideo] = useState<VideoItem | null>(null);
  const [showFeaturesSheet, setShowFeaturesSheet] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Filter videos according to feed tab
  const filteredVideos = videos.filter((v) => {
    if (activeFeedTab === 'trending') {
      return (
        parseInt(v.views.replace(/[^0-9]/g, '')) >= 2 || v.likesCount > 300000
      );
    }
    if (activeFeedTab === 'following') {
      return v.creator.isFollowing;
    }
    return true; // forYou
  });

  const displayVideos = filteredVideos;

  // Scroll to a specific video index
  const scrollToIndex = useCallback((index: number) => {
    if (index < 0 || index >= displayVideos.length) return;
    const targetEl = itemRefs.current[index];
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      setActiveIndex(index);
    }
  }, [displayVideos.length]);

  // Reset scroll to top when changing feed tab
  useEffect(() => {
    setActiveIndex(0);
    if (containerRef.current) {
      containerRef.current.scrollTop = 0;
    }
  }, [activeFeedTab]);

  // IntersectionObserver to auto-detect the visible video and auto-play it
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.55) {
            const index = Number(entry.target.getAttribute('data-index'));
            if (!isNaN(index)) {
              setActiveIndex(index);
            }
          }
        });
      },
      {
        root: container,
        threshold: [0.55, 0.75],
      }
    );

    itemRefs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, [displayVideos]);

  // Handle keyboard navigation (Arrow Up / Down)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        scrollToIndex(Math.min(activeIndex + 1, displayVideos.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        scrollToIndex(Math.max(activeIndex - 1, 0));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, displayVideos.length, scrollToIndex]);

  const handleCreate = () => {
    setShowFeaturesSheet(false);
    if (onCreateClick) onCreateClick();
    else onNavigateTab('create');
  };

  const handleMeetPeople = () => {
    setShowFeaturesSheet(false);
    if (onMeetRealPeople) onMeetRealPeople();
    else onNavigateTab('creators');
  };

  const handleExploreWorld = () => {
    setShowFeaturesSheet(false);
    if (onExploreTheWorld) onExploreTheWorld();
    else onNavigateTab('explore');
  };

  const handleShareFavorites = () => {
    setShowFeaturesSheet(false);
    if (onShareFavorites) onShareFavorites();
    else onNavigateTab('saved');
  };

  return (
    <div className="relative w-full h-full bg-black overflow-hidden select-none flex flex-col">
      {/* Top Header Bar with ViralFlow Logo Branding (Facebook-style, NOT over video content) */}
      <TopBar
        activeFeedTab={activeFeedTab}
        onFeedTabChange={(tab) => {
          onFeedTabChange(tab);
          setActiveIndex(0);
        }}
        onSearchClick={() => onNavigateTab('explore')}
        onNotificationsClick={() => onNavigateTab('inbox')}
        unreadCount={2}
      />

      {/* Main Video Feed Area - Positioned cleanly below the header */}
      <div className="relative flex-1 w-full overflow-hidden bg-black">
        {/* Floating Features Pill */}
        <div className="absolute top-3 left-3 z-30 pointer-events-auto">
          <button
            onClick={() => setShowFeaturesSheet(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/25 text-white text-[11px] font-bold shadow-lg hover:bg-black/60 transition-all active:scale-95 cursor-pointer"
            aria-label="Open Features"
          >
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>Features</span>
          </button>
        </div>

        {/* 9:16 Full-Screen Vertical Snap Scroll Feed */}
        {displayVideos.length === 0 ? (
          <div className="w-full h-full flex flex-col items-center justify-center p-6 text-center bg-radial from-purple-950/40 via-slate-950 to-black select-none">
            <div className="w-16 h-16 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 flex items-center justify-center text-pink-400 mb-4 shadow-xl">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-white text-lg font-black tracking-tight mb-1">
              {activeFeedTab === 'following'
                ? 'No Followed Creators Yet'
                : 'No Videos Found'}
            </h3>
            <p className="text-white/70 text-xs max-w-xs mb-6 font-medium leading-relaxed">
              {activeFeedTab === 'following'
                ? 'Follow creators from your For You feed or the Discover Creators section to watch their content here.'
                : 'Be the first to share your story or switch to the For You feed.'}
            </p>
            <div className="flex flex-col gap-2.5 w-full max-w-xs">
              {activeFeedTab === 'following' && (
                <button
                  onClick={handleMeetPeople}
                  className="w-full py-3 px-5 rounded-2xl bg-gradient-to-r from-purple-600 to-pink-500 text-white text-xs font-extrabold shadow-lg hover:opacity-95 active:scale-95 transition-all cursor-pointer"
                >
                  Meet Real People
                </button>
              )}
              <button
                onClick={() => onFeedTabChange('forYou')}
                className="w-full py-3 px-5 rounded-2xl bg-white/15 backdrop-blur-xl border border-white/25 text-white text-xs font-bold hover:bg-white/25 active:scale-95 transition-all cursor-pointer"
              >
                Switch to For You
              </button>
            </div>
          </div>
        ) : (
          <div
            ref={containerRef}
            className="w-full h-full overflow-y-scroll snap-y snap-mandatory no-scrollbar scroll-smooth relative"
            style={{
              scrollSnapType: 'y mandatory',
              WebkitOverflowScrolling: 'touch',
            }}
          >
            {displayVideos.map((video, index) => (
              <div
                key={video.id}
                data-index={index}
                ref={(el) => {
                  itemRefs.current[index] = el;
                }}
                className="w-full h-full snap-start snap-always shrink-0 relative overflow-hidden bg-black"
                style={{ height: '100%' }}
              >
                <VideoFeedItem
                  video={video}
                  isActive={index === activeIndex}
                  isMuted={isMuted}
                  onToggleMute={() => setIsMuted((prev) => !prev)}
                  onLikeToggle={onLikeToggle}
                  onSaveToggle={onSaveToggle}
                  onFollowToggle={onFollowToggle}
                  onOpenComments={(v) => setActiveCommentsVideo(v)}
                  onOpenShare={(v) => setActiveShareVideo(v)}
                  onCreatorClick={(id) => onSelectCreator(id)}
                  onTagClick={(tag) => onSelectHashtag(tag)}
                />
              </div>
            ))}
          </div>
        )}

        {/* Quick Vertical Navigation Chevrons (Desktop / Pointer helper) */}
        <div className="absolute left-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2 pointer-events-auto opacity-60 hover:opacity-100 transition-opacity">
          <button
            onClick={() => scrollToIndex(activeIndex - 1)}
            disabled={activeIndex === 0}
            className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-white flex items-center justify-center disabled:opacity-20 hover:bg-black/70 active:scale-95 transition-all shadow-lg cursor-pointer"
            aria-label="Previous video"
          >
            <ChevronUp className="w-5 h-5" />
          </button>
          <button
            onClick={() => scrollToIndex(activeIndex + 1)}
            disabled={activeIndex === displayVideos.length - 1}
            className="w-8 h-8 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-white flex items-center justify-center disabled:opacity-20 hover:bg-black/70 active:scale-95 transition-all shadow-lg cursor-pointer"
            aria-label="Next video"
          >
            <ChevronDown className="w-5 h-5" />
          </button>
        </div>

        {/* Vertical Feed Position Indicator */}
        <div className="absolute right-1 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-1 pointer-events-none">
          {displayVideos.map((v, i) => (
            <span
              key={v.id}
              className={`w-1 rounded-full transition-all duration-300 ${
                i === activeIndex
                  ? 'h-4 bg-gradient-to-b from-sky-400 to-pink-500 shadow-sm'
                  : 'h-1 bg-white/30'
              }`}
            />
          ))}
        </div>
      </div>


      {/* Community Spotlight / Features Bottom Sheet on HomeScreen */}
      {showFeaturesSheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm animate-fadeIn">
          <div className="absolute inset-0" onClick={() => setShowFeaturesSheet(false)} />
          <div className="relative z-10 w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-t-[32px] border border-white/90 p-5 shadow-2xl pb-10 animate-slideUp">
            {/* Grab bar */}
            <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto mb-3" />

            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] font-black tracking-wider uppercase text-purple-600 block">
                  Community Spotlight
                </span>
                <h2 className="text-base font-black text-slate-900 tracking-tight">
                  Explore Amazing Features
                </h2>
              </div>
              <button
                onClick={() => setShowFeaturesSheet(false)}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* The Four Feature Buttons */}
            <div className="grid grid-cols-2 gap-2.5">
              {/* 1. Create Your Story */}
              <button
                onClick={handleCreate}
                className="group p-3 rounded-2xl bg-gradient-to-br from-sky-400/90 to-blue-600 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
              >
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Camera className="w-4 h-4 text-white" />
                </div>
                <span className="font-extrabold text-xs leading-tight">Create Your Story</span>
              </button>

              {/* 2. Meet Real People */}
              <button
                onClick={handleMeetPeople}
                className="group p-3 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
              >
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Users className="w-4 h-4 text-white" />
                </div>
                <span className="font-extrabold text-xs leading-tight">Meet Real People</span>
              </button>

              {/* 3. Explore the World */}
              <button
                onClick={handleExploreWorld}
                className="group p-3 rounded-2xl bg-gradient-to-br from-sky-500 to-teal-500 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
              >
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Compass className="w-4 h-4 text-white" />
                </div>
                <span className="font-extrabold text-xs leading-tight">Explore the World</span>
              </button>

              {/* 4. Share Favorites */}
              <button
                onClick={handleShareFavorites}
                className="group p-3 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-500 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
              >
                <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Heart className="w-4 h-4 text-white" />
                </div>
                <span className="font-extrabold text-xs leading-tight">Share Favorites</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comments Drawer */}
      {activeCommentsVideo && (
        <CommentsDrawer
          isOpen={true}
          onClose={() => setActiveCommentsVideo(null)}
          videoId={activeCommentsVideo.id}
          commentsCount={activeCommentsVideo.commentsCount}
          currentUser={currentUser}
          videoOwnerId={activeCommentsVideo.creator.id}
          videoThumbnail={activeCommentsVideo.posterUrl}
          onAddComment={() => {
            activeCommentsVideo.commentsCount += 1;
          }}
        />
      )}

      {/* Share Modal */}
      {activeShareVideo && (
        <ShareModal
          isOpen={true}
          onClose={() => setActiveShareVideo(null)}
          video={activeShareVideo}
          videoTitle={activeShareVideo.caption}
          videoId={activeShareVideo.id}
          currentUser={currentUser}
          isSaved={activeShareVideo.isSaved}
          onToggleSave={() => onSaveToggle(activeShareVideo.id)}
        />
      )}
    </div>
  );
};
