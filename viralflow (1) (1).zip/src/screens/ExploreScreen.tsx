import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Search,
  Sparkles,
  TrendingUp,
  Users,
  Compass,
  Heart,
  Camera,
  Play,
  Flame,
} from 'lucide-react';
import { VideoItem, Creator, UserProfile, FirestoreUserDoc, DEFAULT_AVATAR } from '../types';
import { POPULAR_CREATORS, TRENDING_HASHTAGS } from '../data/mockData';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';
import { VideoDetailModal } from '../components/VideoDetailModal';
import { subscribeFirestoreUsers } from '../lib/firebase';

interface ExploreScreenProps {
  videos: VideoItem[];
  selectedHashtag?: string;
  onSelectVideo: (video: VideoItem) => void;
  onSelectCreator: (creatorId: string) => void;
  onFollowToggle: (creatorId: string) => void;
  onCreateClick: () => void;
  onMeetRealPeople?: () => void;
  onExploreTheWorld?: () => void;
  onShareFavorites?: () => void;
  currentUser?: UserProfile;
  onLikeToggle?: (videoId: string) => void;
  onSaveToggle?: (videoId: string) => void;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  videos,
  selectedHashtag = '',
  onSelectVideo,
  onSelectCreator,
  onFollowToggle,
  onCreateClick,
  onMeetRealPeople,
  onExploreTheWorld,
  onShareFavorites,
  currentUser,
  onLikeToggle,
  onSaveToggle,
}) => {
  const [searchQuery, setSearchQuery] = useState(selectedHashtag);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [modalVideo, setModalVideo] = useState<VideoItem | null>(null);
  const [realUsers, setRealUsers] = useState<FirestoreUserDoc[]>([]);

  // Subscribe to real users in Firestore
  useEffect(() => {
    const unsubscribe = subscribeFirestoreUsers((users) => {
      setRealUsers(users);
    });
    return () => unsubscribe();
  }, []);

  const trendingSectionRef = useRef<HTMLDivElement>(null);

  const categories = ['All', 'Trending', 'Vibe', 'Dance', 'Travel', 'Art', 'Music', 'Comedy'];

  // Aggregate popular creators: Real Firestore users + fallback curated creators
  const displayedCreators: Creator[] = useMemo(() => {
    const fromFirestore: Creator[] = realUsers
      .filter((u) => u.uid !== currentUser?.uid)
      .map((u) => {
        const cleanUsername = u.username
          ? u.username.replace('@', '')
          : (u.displayName || 'creator').toLowerCase().replace(/[^a-z0-9]/g, '');
        return {
          id: u.uid,
          name: u.displayName || 'ViralFlow Creator',
          username: cleanUsername,
          avatar: u.photoURL || DEFAULT_AVATAR,
          isVerified: true,
          isFollowing: false,
          followers:
            typeof u.followersCount === 'number'
              ? `${u.followersCount}`
              : u.followersCount || '1.2K',
          bio: u.bio || 'Creating authentic stories on ViralFlow ✨',
        };
      });

    const combined = [...fromFirestore];
    const seen = new Set(combined.map((c) => c.id));
    for (const pop of POPULAR_CREATORS) {
      if (!seen.has(pop.id)) {
        seen.add(pop.id);
        combined.push(pop);
      }
    }
    return combined;
  }, [realUsers, currentUser?.uid]);

  // Aggregate trending hashtags: dynamically extracted from existing videos + fallback trends
  const displayedHashtags = useMemo(() => {
    const tagCountMap = new Map<string, number>();
    for (const v of videos) {
      if (Array.isArray(v.tags)) {
        for (const tag of v.tags) {
          const clean = tag.trim();
          if (clean) {
            tagCountMap.set(clean, (tagCountMap.get(clean) || 0) + 1);
          }
        }
      }
    }

    const dynamicTrends = Array.from(tagCountMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([tag, count]) => ({
        tag,
        posts: `${count * 12 + 25} posts`,
        category: 'Viral',
      }));

    const merged = [...dynamicTrends];
    const seen = new Set(merged.map((m) => m.tag.toLowerCase()));
    for (const item of TRENDING_HASHTAGS) {
      if (!seen.has(item.tag.toLowerCase()) && merged.length < 8) {
        seen.add(item.tag.toLowerCase());
        merged.push(item);
      }
    }

    return merged.length > 0 ? merged : TRENDING_HASHTAGS;
  }, [videos]);

  const filteredVideos = videos.filter((v) => {
    const matchesSearch =
      !searchQuery.trim() ||
      v.caption.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.creator.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory =
      activeCategory === 'All' || v.category.toLowerCase() === activeCategory.toLowerCase();

    return matchesSearch && matchesCategory;
  });

  const handleExploreWorldClick = () => {
    setActiveCategory('All');
    setSearchQuery('');
    if (trendingSectionRef.current) {
      trendingSectionRef.current.scrollIntoView({ behavior: 'smooth' });
    }
    if (onExploreTheWorld) {
      onExploreTheWorld();
    }
  };

  const handleVideoClick = (video: VideoItem) => {
    setModalVideo(video);
    onSelectVideo(video);
  };

  return (
    <LiquidGlassBackground intensity="subtle" className="h-full overflow-y-auto pb-24 select-none no-scrollbar">
      {/* Sticky Glass Search Header */}
      <div className="sticky top-0 z-20 px-4 pt-3 pb-2 bg-white/70 backdrop-blur-xl border-b border-white/80">
        <div className="relative flex items-center">
          <Search className="absolute left-3.5 w-4 h-4 text-purple-600" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search vibes, hashtags, creators..."
            className="w-full pl-10 pr-10 py-2.5 rounded-full bg-slate-100/90 text-slate-800 text-xs font-medium placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400/60 border border-slate-200/80 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 text-xs text-slate-400 hover:text-slate-700"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-2 mt-1">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-xs'
                  : 'bg-white/80 text-slate-600 hover:bg-white border border-slate-200/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Community Spotlight Section */}
        <div className="liquid-glass-card rounded-3xl p-4 border border-white shadow-xs bg-white/60">
          <div className="flex items-center justify-between mb-3">
            <div>
              <span className="text-[10px] font-black tracking-wider uppercase text-purple-600 block">
                Community Spotlight
              </span>
              <h2 className="text-base font-black text-slate-900 tracking-tight">
                Explore Amazing Features
              </h2>
            </div>
            <span className="font-script text-pink-600 text-sm rotate-[4deg]">
              More Than An App, A Community ♡
            </span>
          </div>

          {/* 4 Feature Action Cards matching Step 5 layout */}
          <div className="grid grid-cols-2 gap-2.5">
            {/* 1. Create Your Story */}
            <button
              onClick={onCreateClick}
              className="group p-3 rounded-2xl bg-gradient-to-br from-sky-400/90 to-blue-600 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                <Camera className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-xs leading-tight">Create Your Story</span>
            </button>

            {/* 2. Meet Real People */}
            <button
              onClick={onMeetRealPeople}
              className="group p-3 rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                <Users className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-xs leading-tight">Meet Real People</span>
            </button>

            {/* 3. Explore The World */}
            <button
              onClick={handleExploreWorldClick}
              className="group p-3 rounded-2xl bg-gradient-to-br from-sky-500 to-teal-500 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                <Compass className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-xs leading-tight">Explore the World</span>
            </button>

            {/* 4. Share Favorites */}
            <button
              onClick={onShareFavorites}
              className="group p-3 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-500 text-white text-left shadow-sm hover:shadow-md transition-all active:scale-98 flex flex-col justify-between h-20 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 transition-transform">
                <Heart className="w-4 h-4 text-white" />
              </div>
              <span className="font-extrabold text-xs leading-tight">Share Favorites</span>
            </button>
          </div>
        </div>

        {/* Popular Creators */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
                Popular Creators
              </h3>
            </div>
            <button
              onClick={onMeetRealPeople}
              className="text-[11px] font-bold text-purple-700 cursor-pointer hover:underline"
            >
              View All
            </button>
          </div>

          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-1">
            {displayedCreators.map((creator) => (
              <div
                key={creator.id}
                className="shrink-0 w-28 liquid-glass-card rounded-2xl p-2.5 flex flex-col items-center text-center shadow-xs border border-white"
              >
                <div
                  onClick={() => onSelectCreator(creator.id)}
                  className="relative cursor-pointer"
                >
                  <img
                    src={creator.avatar}
                    alt={creator.name}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-purple-300"
                  />
                  {creator.isVerified && (
                    <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-sky-500 text-white text-[9px] flex items-center justify-center font-bold">
                      ✓
                    </span>
                  )}
                </div>
                <span className="font-bold text-xs text-slate-900 mt-1.5 truncate max-w-full">
                  {creator.name}
                </span>
                <span className="text-[10px] text-slate-400 truncate max-w-full">
                  {creator.followers}
                </span>
                <button
                  onClick={() => onFollowToggle(creator.id)}
                  className={`mt-2 w-full py-1 rounded-full text-[10px] font-bold transition-all active:scale-95 cursor-pointer ${
                    creator.isFollowing
                      ? 'bg-slate-200 text-slate-700'
                      : 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-xs'
                  }`}
                >
                  {creator.isFollowing ? 'Following' : 'Follow'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Trending Hashtags */}
        <div>
          <div className="flex items-center gap-1.5 mb-2.5">
            <Flame className="w-4 h-4 text-pink-500" />
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
              Trending Hashtags
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {displayedHashtags.map((item) => (
              <button
                key={item.tag}
                onClick={() => setSearchQuery(item.tag)}
                className="liquid-glass-card rounded-2xl p-2.5 flex items-center justify-between text-left hover:bg-white transition-colors group shadow-xs cursor-pointer"
              >
                <div>
                  <span className="font-black text-xs text-slate-900 group-hover:text-purple-600 transition-colors">
                    {item.tag}
                  </span>
                  <span className="block text-[10px] text-slate-400 mt-0.5">
                    {item.posts}
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-100">
                  {item.category}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Trending Videos Grid (2-Column Short Video Discovery) */}
        <div ref={trendingSectionRef}>
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-sky-500" />
              <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
                Trending Videos
              </h3>
            </div>
            <span className="text-[11px] text-slate-400">{filteredVideos.length} videos</span>
          </div>

          {filteredVideos.length === 0 ? (
            <div className="liquid-glass-card rounded-2xl p-6 text-center my-4 border border-white/80 shadow-xs">
              <Sparkles className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <p className="text-xs font-black text-slate-800">No videos found</p>
              <p className="text-[11px] text-slate-500 mt-1 max-w-xs mx-auto">
                No clips matched "{searchQuery}". Try searching for another hashtag, vibe, or creator.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setActiveCategory('All');
                }}
                className="mt-3 px-4 py-1.5 rounded-full bg-purple-100 text-purple-700 text-xs font-bold hover:bg-purple-200 transition-colors"
              >
                Clear Search
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              {filteredVideos.map((video) => (
                <div
                  key={video.id}
                  onClick={() => handleVideoClick(video)}
                  className="group relative aspect-[9/16] rounded-2xl overflow-hidden shadow-md cursor-pointer bg-slate-900 border border-white/10"
                >
                  <img
                    src={video.posterUrl}
                    alt={video.caption}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />

                  {/* Video overlay badge */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />

                  {/* View count top badge */}
                  <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md text-white text-[10px] font-bold">
                    <Play className="w-2.5 h-2.5 fill-white" />
                    <span>{video.views}</span>
                  </div>

                  {/* Creator and caption bottom info */}
                  <div className="absolute bottom-2 left-2 right-2 text-white">
                    <div className="flex items-center gap-1.5 mb-1">
                      <img
                        src={video.creator.avatar}
                        alt={video.creator.name}
                        className="w-5 h-5 rounded-full object-cover ring-1 ring-white"
                      />
                      <span className="text-[11px] font-bold truncate">
                        @{video.creator.username}
                      </span>
                    </div>
                    <p className="text-[10px] text-white/90 line-clamp-2 leading-tight">
                      {video.caption}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Video Detail Modal with Like, Comment, Save functionality */}
      {currentUser && onLikeToggle && onSaveToggle && (
        <VideoDetailModal
          video={modalVideo}
          isOpen={!!modalVideo}
          onClose={() => setModalVideo(null)}
          currentUser={currentUser}
          onLikeToggle={onLikeToggle}
          onSaveToggle={onSaveToggle}
          onFollowToggle={onFollowToggle}
          onSelectCreator={onSelectCreator}
        />
      )}
    </LiquidGlassBackground>
  );
};
