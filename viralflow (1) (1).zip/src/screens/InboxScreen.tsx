import React, { useState, useEffect, useMemo } from 'react';
import {
  Heart,
  MessageSquare,
  UserPlus,
  AtSign,
  Sparkles,
  CheckCheck,
  Play,
  AlertCircle,
  SquarePen,
  RefreshCw,
  LogIn,
} from 'lucide-react';
import { NotificationItem, ChatThread, UserProfile, DEFAULT_AVATAR } from '../types';
import {
  subscribeUserNotifications,
  markFirestoreNotificationAsRead,
  markAllFirestoreNotificationsAsRead,
  subscribeUserConversations,
  getConversationId,
} from '../lib/firebase';
import { DirectChatView } from '../components/chat/DirectChatView';
import { NewChatModal } from '../components/chat/NewChatModal';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';

interface InboxScreenProps {
  currentUser: UserProfile;
  onOpenCreator: (creatorId: string) => void;
  onSelectVideo?: (videoId: string, commentId?: string) => void;
  onRequireAuth?: () => void;
  onFollowToggle?: (creatorId: string) => void;
  followedUserIds?: Set<string>;
}

export const InboxScreen: React.FC<InboxScreenProps> = ({
  currentUser,
  onOpenCreator,
  onSelectVideo,
  onRequireAuth,
  onFollowToggle,
  followedUserIds,
}) => {
  const [activeTab, setActiveTab] = useState<'activity' | 'messages'>('activity');
  const [filterType, setFilterType] = useState<string>('all');
  
  // Notifications State (Firestore)
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoadingNotifs, setIsLoadingNotifs] = useState<boolean>(true);
  const [notifsError, setNotifsError] = useState<string | null>(null);
  const [notifsRetryKey, setNotifsRetryKey] = useState<number>(0);

  // Direct Messages State (Firestore)
  const [chatThreads, setChatThreads] = useState<ChatThread[]>([]);
  const [isLoadingDMs, setIsLoadingDMs] = useState<boolean>(true);
  const [dmError, setDmError] = useState<string | null>(null);
  const [dmRetryKey, setDmRetryKey] = useState<number>(0);

  // Active chat thread & New chat modal states
  const [activeThread, setActiveThread] = useState<ChatThread | null>(null);
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState<boolean>(false);

  // 1. Subscribe in real-time to Firestore notifications for the currently authenticated user
  useEffect(() => {
    if (!currentUser.uid) {
      setNotifications([]);
      setIsLoadingNotifs(false);
      return;
    }

    setIsLoadingNotifs(true);
    setNotifsError(null);

    const unsubscribe = subscribeUserNotifications(
      currentUser.uid,
      (realtimeNotifs) => {
        setNotifications(realtimeNotifs);
        setIsLoadingNotifs(false);
        setNotifsError(null);
      },
      (err) => {
        console.warn('Notifications real-time subscription notice:', err);
        setNotifsError('Unable to sync live notifications. Please check your connection.');
        setIsLoadingNotifs(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [currentUser.uid, notifsRetryKey]);

  // 2. Subscribe in real-time to Firestore direct message conversations
  useEffect(() => {
    if (!currentUser.uid) {
      setChatThreads([]);
      setIsLoadingDMs(false);
      return;
    }

    setIsLoadingDMs(true);
    setDmError(null);

    const unsubscribe = subscribeUserConversations(
      currentUser.uid,
      (realtimeThreads) => {
        setChatThreads(realtimeThreads);
        setIsLoadingDMs(false);
        setDmError(null);

        // Keep activeThread in sync if conversation is open
        setActiveThread((prev) => {
          if (!prev) return null;
          const updated = realtimeThreads.find((t) => t.id === prev.id);
          return updated || prev;
        });
      },
      (err) => {
        console.warn('Conversations real-time subscription notice:', err);
        setDmError('Unable to sync live conversations. Please check your connection.');
        setIsLoadingDMs(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [currentUser.uid, dmRetryKey]);

  const filterOptions = [
    { id: 'all', label: 'All', icon: Sparkles },
    { id: 'like', label: 'Likes', icon: Heart },
    { id: 'comment', label: 'Comments', icon: MessageSquare },
    { id: 'follow', label: 'Followers', icon: UserPlus },
    { id: 'mention', label: 'Mentions', icon: AtSign },
  ];

  const filteredNotifications = notifications.filter((n) => {
    if (filterType === 'all') return true;
    if (filterType === 'comment') return n.type === 'comment' || n.type === 'reply';
    return n.type === filterType;
  });

  const unreadNotifsCount = notifications.filter((n) => !n.isRead).length;
  const unreadDMsCount = chatThreads.reduce((acc, t) => acc + (t.unreadCount || 0), 0);

  // Handle Mark All Notifications As Read
  const handleMarkAllRead = async () => {
    if (!currentUser.uid) return;
    const unreadIds = notifications.filter((n) => !n.isRead).map((n) => n.id);
    if (!unreadIds.length) return;

    // Optimistic local update
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));

    try {
      await markAllFirestoreNotificationsAsRead(currentUser.uid, unreadIds);
    } catch (err) {
      console.warn('Mark all read error:', err);
    }
  };

  // Handle clicking on a notification
  const handleNotificationClick = async (notif: NotificationItem) => {
    if (!notif.isRead) {
      setNotifications((prev) =>
        prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
      );
      markFirestoreNotificationAsRead(notif.id).catch(() => {});
    }

    if (notif.videoId && onSelectVideo) {
      onSelectVideo(notif.videoId, notif.commentId);
    } else if (notif.actor?.id) {
      onOpenCreator(notif.actor.id);
    }
  };

  // Handle starting a new chat with a user selected from NewChatModal
  const handleSelectNewChatUser = (targetUser: {
    id: string;
    name: string;
    username: string;
    avatar: string;
  }) => {
    if (!currentUser.uid) {
      onRequireAuth?.();
      return;
    }

    const convId = getConversationId(currentUser.uid, targetUser.id);
    const existing = chatThreads.find((t) => t.id === convId);

    if (existing) {
      setActiveThread(existing);
    } else {
      // Create initial local active thread state; first message sets doc in Firestore
      setActiveThread({
        id: convId,
        participantIds: [currentUser.uid, targetUser.id],
        user: {
          id: targetUser.id,
          name: targetUser.name,
          username: targetUser.username,
          avatar: targetUser.avatar,
          isOnline: true,
        },
        lastMessage: '',
        timestamp: 'Just now',
        unreadCount: 0,
        messages: [],
      });
    }
  };

  return (
    <LiquidGlassBackground intensity="subtle" className="h-full overflow-hidden flex flex-col select-none">
      {/* Active Direct Message Conversation View */}
      {activeThread ? (
        <DirectChatView
          conversationId={activeThread.id}
          recipientUser={activeThread.user}
          currentUser={currentUser}
          onBack={() => setActiveThread(null)}
          onOpenCreator={onOpenCreator}
          onSelectVideo={onSelectVideo}
        />
      ) : (
        /* Regular Inbox Screen (Segmented Tabs: Notifications vs Direct Messages) */
        <div className="h-full flex flex-col">
          {/* Header with Segmented Navigation */}
          <div className="px-4 pt-3 pb-2 bg-white/70 backdrop-blur-xl border-b border-white/80">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black text-slate-900 tracking-tight">Inbox</h1>
                {unreadNotifsCount + unreadDMsCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-pink-500 text-white text-[10px] font-extrabold shadow-xs">
                    {unreadNotifsCount + unreadDMsCount} new
                  </span>
                )}
              </div>

              {activeTab === 'activity' && unreadNotifsCount > 0 && (
                <button
                  onClick={handleMarkAllRead}
                  className="flex items-center gap-1 text-[11px] font-bold text-purple-600 hover:text-purple-700 active:scale-95 transition-all px-2.5 py-1 rounded-full bg-purple-50/80 border border-purple-200/60 shadow-2xs"
                  title="Mark all notifications as read"
                >
                  <CheckCheck className="w-3.5 h-3.5 text-purple-600" />
                  <span>Mark all read</span>
                </button>
              )}

              {activeTab === 'messages' && (
                <button
                  onClick={() => {
                    if (!currentUser.uid) {
                      onRequireAuth?.();
                    } else {
                      setIsNewChatModalOpen(true);
                    }
                  }}
                  className="flex items-center gap-1 text-[11px] font-bold text-purple-600 hover:text-purple-700 active:scale-95 transition-all px-2.5 py-1 rounded-full bg-purple-50/80 border border-purple-200/60 shadow-2xs"
                  title="Start a new message"
                >
                  <SquarePen className="w-3.5 h-3.5 text-purple-600" />
                  <span>New Chat</span>
                </button>
              )}
            </div>

            {/* Segmented control: Notifications vs Direct Messages */}
            <div className="grid grid-cols-2 p-1 rounded-full bg-slate-100/90 border border-slate-200/80">
              <button
                onClick={() => setActiveTab('activity')}
                className={`py-1.5 rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'activity'
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <span>Notifications</span>
                {unreadNotifsCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-[9px] font-bold flex items-center justify-center shadow-xs">
                    {unreadNotifsCount > 9 ? '9+' : unreadNotifsCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('messages')}
                className={`py-1.5 rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'messages'
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                <span>Direct Messages</span>
                {unreadDMsCount > 0 && (
                  <span className="px-1.5 min-w-4 h-4 rounded-full bg-pink-500 text-white text-[9px] font-bold flex items-center justify-center shadow-xs">
                    {unreadDMsCount > 9 ? '9+' : unreadDMsCount}
                  </span>
                )}
              </button>
            </div>

            {/* Filter tags (Only shown on Notifications tab) */}
            {activeTab === 'activity' && (
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-2.5 pb-1">
                {filterOptions.map((opt) => {
                  const Icon = opt.icon;
                  const isSelected = filterType === opt.id;
                  return (
                    <button
                      key={opt.id}
                      onClick={() => setFilterType(opt.id)}
                      className={`px-3 py-1 rounded-full text-[11px] font-bold shrink-0 flex items-center gap-1 transition-all ${
                        isSelected
                          ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-xs'
                          : 'bg-white/80 text-slate-600 hover:bg-white border border-slate-200/60'
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                      <span>{opt.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Tab Content Container */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
            {activeTab === 'activity' ? (
              /* TAB 1: NOTIFICATIONS LIST (REAL-TIME FIRESTORE) */
              !currentUser.uid ? (
                /* Unauthenticated state */
                <div className="py-14 text-center text-slate-500 flex flex-col items-center justify-center px-4">
                  <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mb-2">
                    <LogIn className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-800">Sign In to See Notifications</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-[220px]">
                    Receive real-time alerts when creators like your videos, post comments, and follow you.
                  </p>
                  {onRequireAuth && (
                    <button
                      onClick={onRequireAuth}
                      className="mt-3 px-4 py-1.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-xs font-bold shadow-xs hover:shadow-sm active:scale-95 transition-all"
                    >
                      Sign In to ViralFlow
                    </button>
                  )}
                </div>
              ) : isLoadingNotifs ? (
                /* Loading skeleton state */
                <div className="space-y-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="liquid-glass-card rounded-2xl p-3 flex items-center gap-3 animate-pulse border border-slate-200/50"
                    >
                      <div className="w-11 h-11 rounded-full bg-slate-200 shrink-0" />
                      <div className="flex-1 space-y-2">
                        <div className="h-3 bg-slate-200 rounded-full w-3/4" />
                        <div className="h-2 bg-slate-200 rounded-full w-1/3" />
                      </div>
                      <div className="w-10 h-12 bg-slate-200 rounded-xl shrink-0" />
                    </div>
                  ))}
                </div>
              ) : notifsError ? (
                /* Error state */
                <div className="py-14 text-center text-slate-500 flex flex-col items-center justify-center px-4">
                  <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-2">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-800">{notifsError}</p>
                  <button
                    onClick={() => setNotifsRetryKey((k) => k + 1)}
                    className="mt-3 px-4 py-1.5 rounded-full bg-purple-600 text-white text-xs font-bold shadow-xs hover:bg-purple-700 active:scale-95 transition-all flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Retry Connection</span>
                  </button>
                </div>
              ) : filteredNotifications.length === 0 ? (
                /* Empty state */
                <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center px-4">
                  <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center mb-2.5">
                    <Sparkles className="w-6 h-6 text-purple-400" />
                  </div>
                  <p className="text-xs font-bold text-slate-700">All caught up!</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-[220px]">
                    No notifications yet. When people like your videos, comment, or follow you, they will appear right here in real time.
                  </p>
                </div>
              ) : (
                /* Notifications list */
                filteredNotifications.map((notif) => {
                  const isFollowingActor = followedUserIds?.has(notif.actor.id);
                  return (
                    <div
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif)}
                      className={`liquid-glass-card rounded-2xl p-3 flex items-center gap-3 transition-all cursor-pointer border ${
                        notif.isRead
                          ? 'border-slate-200/60 bg-white/75 opacity-90 hover:bg-white hover:opacity-100 shadow-2xs'
                          : 'border-purple-300/80 bg-white/95 shadow-xs ring-1 ring-purple-100 hover:bg-white'
                      }`}
                    >
                      {/* Actor Avatar with event badge */}
                      <div
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!notif.isRead) {
                            markFirestoreNotificationAsRead(notif.id).catch(() => {});
                            setNotifications((prev) =>
                              prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
                            );
                          }
                          onOpenCreator(notif.actor.id);
                        }}
                        className="relative cursor-pointer shrink-0"
                      >
                        <img
                          src={notif.actor.avatar || DEFAULT_AVATAR}
                          alt={notif.actor.name}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                          }}
                          className="w-11 h-11 rounded-full object-cover ring-1 ring-purple-300 bg-slate-100"
                        />
                        <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-gradient-to-tr from-sky-400 to-pink-500 text-white flex items-center justify-center text-[10px] shadow-xs">
                          {notif.type === 'like' && '❤️'}
                          {(notif.type === 'comment' || notif.type === 'reply') && '💬'}
                          {notif.type === 'follow' && '👤'}
                          {notif.type === 'mention' && '@'}
                          {notif.type === 'system' && '🎉'}
                        </div>
                      </div>

                      {/* Content Message */}
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-slate-800 leading-snug">
                          <span className="font-bold text-slate-900 mr-1">
                            {notif.actor.name}
                          </span>
                          {notif.text}
                        </p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-slate-400">
                            {notif.timestamp}
                          </span>
                          {!notif.isRead && (
                            <span className="w-1.5 h-1.5 rounded-full bg-pink-500 inline-block" />
                          )}
                        </div>
                      </div>

                      {/* Video Thumbnail if linked */}
                      {notif.videoThumbnail && (
                        <div className="relative shrink-0 group">
                          <img
                            src={notif.videoThumbnail}
                            alt="Video Thumbnail"
                            className="w-10 h-12 rounded-xl object-cover ring-1 ring-slate-200 shadow-xs"
                          />
                          <div className="absolute inset-0 bg-black/20 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="w-3.5 h-3.5 text-white fill-white" />
                          </div>
                        </div>
                      )}

                      {/* Follow back action button for follow notifications */}
                      {notif.type === 'follow' && onFollowToggle && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (!notif.isRead) {
                              markFirestoreNotificationAsRead(notif.id).catch(() => {});
                              setNotifications((prev) =>
                                prev.map((n) => (n.id === notif.id ? { ...n, isRead: true } : n))
                              );
                            }
                            onFollowToggle(notif.actor.id);
                          }}
                          className={`px-3 py-1 rounded-full text-[10px] font-bold shrink-0 active:scale-95 transition-all ${
                            isFollowingActor
                              ? 'bg-slate-200 text-slate-700'
                              : 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-xs hover:shadow-sm'
                          }`}
                        >
                          {isFollowingActor ? 'Following' : 'Follow Back'}
                        </button>
                      )}
                    </div>
                  );
                })
              )
            ) : (
              /* TAB 2: DIRECT MESSAGES LIST (REAL-TIME FIRESTORE) */
              !currentUser.uid ? (
                /* Unauthenticated state */
                <div className="py-14 text-center text-slate-500 flex flex-col items-center justify-center px-4">
                  <div className="w-12 h-12 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mb-2">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-800">Sign In to Chat</p>
                  <p className="text-[11px] text-slate-400 mt-1 max-w-[220px]">
                    Direct message with creators, share video Shorts, and chat in real-time across devices.
                  </p>
                  {onRequireAuth && (
                    <button
                      onClick={onRequireAuth}
                      className="mt-3 px-4 py-1.5 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-xs font-bold shadow-xs hover:shadow-sm active:scale-95 transition-all"
                    >
                      Sign In to ViralFlow
                    </button>
                  )}
                </div>
              ) : isLoadingDMs ? (
                /* Loading skeleton state */
                <div className="space-y-2.5">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="liquid-glass-card rounded-2xl p-3 flex items-center gap-3 animate-pulse border border-slate-200/50"
                    >
                      <div className="w-12 h-12 rounded-full bg-slate-200 shrink-0" />
                      <div className="flex-1 space-y-2">
                        <div className="h-3 bg-slate-200 rounded-full w-2/5" />
                        <div className="h-2.5 bg-slate-200 rounded-full w-4/5" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : dmError ? (
                /* Error state */
                <div className="py-14 text-center text-slate-500 flex flex-col items-center justify-center px-4">
                  <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-2">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-bold text-slate-800">{dmError}</p>
                  <button
                    onClick={() => setDmRetryKey((k) => k + 1)}
                    className="mt-3 px-4 py-1.5 rounded-full bg-purple-600 text-white text-xs font-bold shadow-xs hover:bg-purple-700 active:scale-95 transition-all flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Retry Connection</span>
                  </button>
                </div>
              ) : chatThreads.length === 0 ? (
                /* Empty state */
                <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center px-4">
                  <div className="w-14 h-14 rounded-full bg-purple-50 text-purple-500 flex items-center justify-center mb-3 shadow-xs">
                    <MessageSquare className="w-7 h-7" />
                  </div>
                  <p className="text-sm font-extrabold text-slate-800">No messages yet</p>
                  <p className="text-xs text-slate-500 mt-1 max-w-[240px] leading-relaxed">
                    Direct message other creators, reply to shared Shorts, and connect in real time.
                  </p>
                  <button
                    onClick={() => setIsNewChatModalOpen(true)}
                    className="mt-4 px-5 py-2 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-xs font-bold shadow-sm hover:shadow-md active:scale-95 transition-all flex items-center gap-1.5"
                  >
                    <SquarePen className="w-3.5 h-3.5" />
                    <span>Start a Chat</span>
                  </button>
                </div>
              ) : (
                /* Real-time Conversations List */
                <div className="space-y-2">
                  {chatThreads.map((thread) => (
                    <button
                      key={thread.id}
                      onClick={() => setActiveThread(thread)}
                      className={`w-full liquid-glass-card rounded-2xl p-3 flex items-center gap-3 transition-all text-left border ${
                        thread.unreadCount > 0
                          ? 'border-purple-300 bg-white shadow-xs ring-1 ring-purple-100'
                          : 'border-slate-200/60 bg-white/80 hover:bg-white hover:border-slate-300/80 shadow-2xs'
                      }`}
                    >
                      {/* User Avatar with Online Indicator */}
                      <div className="relative shrink-0">
                        <img
                          src={thread.user.avatar || DEFAULT_AVATAR}
                          alt={thread.user.name}
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                          }}
                          className="w-12 h-12 rounded-full object-cover ring-2 ring-purple-200/80 bg-slate-100"
                        />
                        {thread.user.isOnline && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-white" />
                        )}
                      </div>

                      {/* Conversation Preview */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span
                            className={`text-xs truncate ${
                              thread.unreadCount > 0
                                ? 'font-black text-slate-950'
                                : 'font-extrabold text-slate-850'
                            }`}
                          >
                            {thread.user.name}
                          </span>
                          <span
                            className={`text-[10px] shrink-0 ml-1.5 ${
                              thread.unreadCount > 0
                                ? 'text-purple-600 font-bold'
                                : 'text-slate-400 font-medium'
                            }`}
                          >
                            {thread.timestamp}
                          </span>
                        </div>
                        <p
                          className={`text-xs truncate mt-0.5 ${
                            thread.unreadCount > 0
                              ? 'text-slate-900 font-semibold'
                              : 'text-slate-500 font-normal'
                          }`}
                        >
                          {thread.lastMessage || 'No messages yet'}
                        </p>
                      </div>

                      {/* Unread Count Badge */}
                      {thread.unreadCount > 0 && (
                        <span className="w-5 h-5 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white text-[10px] font-extrabold flex items-center justify-center shrink-0 shadow-xs">
                          {thread.unreadCount > 9 ? '9+' : thread.unreadCount}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )
            )}
          </div>
        </div>
      )}

      {/* New Chat Selection Modal */}
      <NewChatModal
        currentUser={currentUser}
        isOpen={isNewChatModalOpen}
        onClose={() => setIsNewChatModalOpen(false)}
        onSelectUser={handleSelectNewChatUser}
      />
    </LiquidGlassBackground>
  );
};
