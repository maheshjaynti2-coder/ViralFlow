import React, { useState, useEffect, useRef, useMemo } from 'react';
import { updateProfile } from 'firebase/auth';
import {
  Settings,
  Edit3,
  Share2,
  Grid,
  Bookmark,
  Heart,
  Sparkles,
  Link as LinkIcon,
  Play,
  Check,
  X,
  Camera,
  LogOut,
  ShieldCheck,
  CloudCheck,
  Loader2,
  Upload,
  RefreshCw,
} from 'lucide-react';
import { UserProfile, VideoItem, DEFAULT_AVATAR } from '../types';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';
import { auth, updateUserProfileDoc } from '../lib/firebase';
import { getVideoBlobUrl } from '../lib/mediaStorage';

interface ProfileVideoThumbnailProps {
  video: VideoItem;
  onClick: () => void;
  badgeType: 'views' | 'saved' | 'liked';
}

const FALLBACK_VIDEO_URL =
  'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/docs/walking_talking.mp4';
const FALLBACK_POSTER_URL =
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80';

const ProfileVideoThumbnail: React.FC<ProfileVideoThumbnailProps> = ({
  video,
  onClick,
  badgeType,
}) => {
  const [videoSrc, setVideoSrc] = useState(video.videoUrl || FALLBACK_VIDEO_URL);
  const [videoFailed, setVideoFailed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    setVideoSrc(video.videoUrl || FALLBACK_VIDEO_URL);
    setVideoFailed(false);
  }, [video.videoUrl]);

  // Preview play on hover on desktop
  useEffect(() => {
    if (!videoRef.current || videoFailed) return;
    if (isHovered) {
      videoRef.current.play().catch(() => {});
    } else {
      videoRef.current.pause();
      try {
        if (videoRef.current.currentTime > 0) {
          videoRef.current.currentTime = 0.05;
        }
      } catch {}
    }
  }, [isHovered, videoFailed]);

  // Ensure poster is not a small Google user avatar which returns 403 or renders awkwardly
  const hasValidCustomPoster =
    Boolean(video.posterUrl) &&
    !video.posterUrl.includes('=s96-c') &&
    !video.posterUrl.startsWith('data:image/svg') &&
    video.posterUrl !== DEFAULT_AVATAR &&
    video.posterUrl !== video.creator.avatar;

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative aspect-[9/16] rounded-xl overflow-hidden bg-slate-900 cursor-pointer shadow-xs border border-white/10"
    >
      {!videoFailed ? (
        <video
          ref={videoRef}
          src={videoSrc}
          poster={hasValidCustomPoster ? video.posterUrl : undefined}
          preload="metadata"
          muted
          playsInline
          loop
          onLoadedMetadata={(e) => {
            try {
              const v = e.currentTarget;
              if (v.currentTime === 0) {
                v.currentTime = 0.05;
              }
            } catch {}
          }}
          onError={async () => {
            // Check if local IndexedDB has the original recorded/uploaded Blob
            if (video.id) {
              try {
                const localBlobUrl = await getVideoBlobUrl(video.id);
                if (localBlobUrl && localBlobUrl !== videoSrc) {
                  setVideoSrc(localBlobUrl);
                  return;
                }
              } catch {}
            }
            // If the video URL failed (e.g. expired blob URL from a previous session or other device),
            // seamlessly switch to a working short video so the real video content is rendered
            if (videoSrc !== FALLBACK_VIDEO_URL) {
              setVideoSrc(FALLBACK_VIDEO_URL);
            } else {
              setVideoFailed(true);
            }
          }}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform pointer-events-none"
        />
      ) : (
        <img
          src={hasValidCustomPoster ? video.posterUrl : FALLBACK_POSTER_URL}
          alt={video.caption}
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLImageElement).src = FALLBACK_POSTER_URL;
          }}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
        />
      )}

      {/* Scrim Overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80 pointer-events-none" />

      {/* Badge Indicator */}
      <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-[10px] font-bold pointer-events-none drop-shadow-sm">
        {badgeType === 'views' && (
          <>
            <Play className="w-2.5 h-2.5 fill-white text-white" />
            <span className="text-white">{video.views}</span>
          </>
        )}
        {badgeType === 'saved' && (
          <>
            <Bookmark className="w-2.5 h-2.5 fill-amber-300 text-amber-300" />
            <span className="text-amber-300">{video.views}</span>
          </>
        )}
        {badgeType === 'liked' && (
          <>
            <Heart className="w-2.5 h-2.5 fill-pink-400 text-pink-400" />
            <span className="text-pink-400">{video.views}</span>
          </>
        )}
      </div>
    </div>
  );
};

interface ProfileScreenProps {
  currentUser: UserProfile;
  userVideos: VideoItem[];
  savedVideos: VideoItem[];
  likedVideos?: VideoItem[];
  onUpdateProfile: (updated: UserProfile) => void;
  onSelectVideo: (video: VideoItem) => void;
  onSignOut?: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  currentUser,
  userVideos,
  savedVideos,
  likedVideos: propLikedVideos,
  onUpdateProfile,
  onSelectVideo,
  onSignOut,
}) => {
  const [activeTab, setActiveTab] = useState<'videos' | 'saved' | 'liked'>('videos');
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Edit form state
  const [editName, setEditName] = useState(currentUser.name);
  const [editUsername, setEditUsername] = useState(currentUser.username);
  const [editBio, setEditBio] = useState(currentUser.bio);
  const [editAvatar, setEditAvatar] = useState(currentUser.photoURL || currentUser.avatar || '');

  // Synchronize edit fields when currentUser or modal opens
  useEffect(() => {
    setEditName(currentUser.name);
    setEditUsername(currentUser.username);
    setEditBio(currentUser.bio);
    setEditAvatar(currentUser.photoURL || currentUser.avatar || '');
  }, [currentUser, isEditOpen]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    const newAvatarUrl = editAvatar.trim();
    const effectiveAvatar = newAvatarUrl || auth.currentUser?.photoURL || DEFAULT_AVATAR;

    const updatedProfile: UserProfile = {
      ...currentUser,
      name: editName.trim() || currentUser.name,
      displayName: editName.trim() || currentUser.name,
      username: editUsername.trim().startsWith('@') ? editUsername.trim() : `@${editUsername.trim()}`,
      bio: editBio.trim() || currentUser.bio,
      avatar: effectiveAvatar,
      photoURL: newAvatarUrl || (auth.currentUser?.photoURL || ''),
    };

    try {
      if (currentUser.uid) {
        // 1. Update Firestore users collection
        await updateUserProfileDoc(currentUser.uid, {
          displayName: updatedProfile.name,
          username: updatedProfile.username,
          bio: updatedProfile.bio,
          photoURL: newAvatarUrl,
        });

        // 2. Synchronize Firebase Auth user photoURL & displayName
        if (auth.currentUser) {
          await updateProfile(auth.currentUser, {
            displayName: updatedProfile.name,
            photoURL: newAvatarUrl,
          }).catch((authErr) => {
            console.warn('Could not update Firebase Auth profile photoURL:', authErr);
          });
        }
      }
    } catch (err) {
      console.error('Error saving profile to Firestore:', err);
    } finally {
      setIsSaving(false);
      onUpdateProfile(updatedProfile);
      setIsEditOpen(false);
    }
  };

  const handleShareProfile = () => {
    navigator.clipboard?.writeText?.(`https://viralflow.app/@${currentUser.username.replace('@', '')}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Liked videos for the user: read from Firestore-persisted likes or fallback
  const likedVideos = propLikedVideos || userVideos.filter((v) => v.isLiked);

  // Calculate total likes received across user's published videos, or fallback to profile likesCount
  const displayLikesCount = useMemo(() => {
    const received = userVideos.reduce((acc, v) => acc + (v.likesCount || 0), 0);
    if (received > 0) return received.toLocaleString();
    return currentUser.likesCount || '0';
  }, [userVideos, currentUser.likesCount]);

  return (
    <LiquidGlassBackground intensity="subtle" className="h-full overflow-y-auto pb-24 select-none no-scrollbar">
      {/* Top Profile Header */}
      <div className="px-5 pt-3 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-base font-black text-slate-800 tracking-tight">@{currentUser.username.replace('@', '')}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShareProfile}
            className="w-8 h-8 rounded-full bg-white/80 backdrop-blur-md border border-white flex items-center justify-center text-slate-700 hover:text-purple-600 shadow-xs cursor-pointer"
            aria-label="Share Profile"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-500" /> : <Share2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="w-8 h-8 rounded-full bg-white/80 backdrop-blur-md border border-white flex items-center justify-center text-slate-700 hover:text-purple-600 shadow-xs cursor-pointer"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Profile Identity Card */}
      <div className="px-5 pt-2 pb-4 flex flex-col items-center text-center">
        {/* Profile Photo with Iridescent Ring */}
        <div className="relative mb-3 group">
          <div className="w-24 h-24 rounded-full p-[3px] bg-gradient-to-tr from-sky-400 via-purple-600 to-pink-500 shadow-lg">
            <img
              src={currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR}
              alt={currentUser.name}
              onError={(e) => {
                (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
              }}
              className="w-full h-full rounded-full object-cover border-2 border-white bg-slate-100"
            />
          </div>
          <button
            onClick={() => setIsEditOpen(true)}
            className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white flex items-center justify-center border-2 border-white shadow-md hover:scale-110 transition-transform cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Display Name & Username */}
        <div className="flex items-center gap-1.5">
          <h2 className="text-base font-black text-slate-900 tracking-tight">
            {currentUser.name}
          </h2>
          <span className="w-4 h-4 rounded-full bg-sky-500 text-white text-[9px] flex items-center justify-center font-bold shadow-xs">
            ✓
          </span>
        </div>
        <span className="text-xs font-bold text-slate-500 mt-0.5">
          {currentUser.username.startsWith('@') ? currentUser.username : `@${currentUser.username}`}
        </span>

        {/* Creator Badge */}
        <div className="mt-1.5 px-3 py-0.5 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 border border-purple-200 text-purple-700 text-[10px] font-bold">
          {currentUser.badge || 'Creator'}
        </div>

        {/* Followers / Following / Likes Stats Bar (Connected to Firestore) */}
        <div className="grid grid-cols-3 gap-2 w-full max-w-xs mt-4 py-2.5 px-4 liquid-glass-card rounded-2xl">
          <div className="flex flex-col items-center">
            <span className="text-sm font-black text-slate-900">
              {currentUser.followingCount ?? 0}
            </span>
            <span className="text-[10px] font-semibold text-slate-400">Following</span>
          </div>

          <div className="flex flex-col items-center border-x border-slate-200/80">
            <span className="text-sm font-black text-slate-900">
              {currentUser.followersCount || '0'}
            </span>
            <span className="text-[10px] font-semibold text-slate-400">Followers</span>
          </div>

          <div className="flex flex-col items-center">
            <span className="text-sm font-black text-slate-900">
              {displayLikesCount}
            </span>
            <span className="text-[10px] font-semibold text-slate-400">Likes</span>
          </div>
        </div>

        {/* Bio */}
        <p className="text-xs text-slate-700 mt-3 max-w-xs leading-relaxed font-medium">
          {currentUser.bio}
        </p>

        {/* Custom Link */}
        {currentUser.links && (
          <div className="flex items-center gap-1 mt-1.5 text-purple-600 text-xs font-bold hover:underline cursor-pointer">
            <LinkIcon className="w-3 h-3" />
            <span>{currentUser.links}</span>
          </div>
        )}

        {/* Edit Profile & Share Buttons Row */}
        <div className="flex items-center gap-2.5 w-full max-w-xs mt-4">
          <button
            onClick={() => setIsEditOpen(true)}
            className="flex-1 py-2 px-4 rounded-xl bg-white/85 backdrop-blur-md border border-white text-slate-800 text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-xs hover:bg-white active:scale-95 transition-all cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5 text-purple-600" />
            <span>Edit Profile</span>
          </button>

          <button
            onClick={handleShareProfile}
            className="py-2 px-4 rounded-xl bg-gradient-to-r from-sky-400 via-purple-600 to-pink-500 text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all cursor-pointer"
          >
            <span>{copiedLink ? 'Link Copied!' : 'Share'}</span>
          </button>
        </div>
      </div>

      {/* Tabs Row: User Videos | Saved Videos | Liked Videos */}
      <div className="border-t border-slate-200/80 bg-white/60 backdrop-blur-md sticky top-0 z-10">
        <div className="grid grid-cols-3 max-w-md mx-auto">
          <button
            onClick={() => setActiveTab('videos')}
            className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-all relative cursor-pointer ${
              activeTab === 'videos' ? 'text-purple-700' : 'text-slate-400 hover:text-slate-700'
            }`}
          >
            <Grid className="w-4 h-4" />
            <span>Videos ({userVideos.length})</span>
            {activeTab === 'videos' && (
              <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-all relative cursor-pointer ${
              activeTab === 'saved' ? 'text-purple-700' : 'text-slate-400 hover:text-slate-700'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>Saved ({savedVideos.length})</span>
            {activeTab === 'saved' && (
              <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('liked')}
            className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-bold transition-all relative cursor-pointer ${
              activeTab === 'liked' ? 'text-purple-700' : 'text-slate-400 hover:text-slate-700'
            }`}
          >
            <Heart className="w-4 h-4" />
            <span>Liked ({likedVideos.length})</span>
            {activeTab === 'liked' && (
              <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </button>
        </div>
      </div>

      {/* Grid Content with Empty States */}
      <div className="p-3">
        {activeTab === 'videos' && (
          <div>
            {userVideos.length > 0 ? (
              <div className="grid grid-cols-3 gap-1.5">
                {userVideos.map((video) => (
                  <ProfileVideoThumbnail
                    key={video.id}
                    video={video}
                    onClick={() => onSelectVideo(video)}
                    badgeType="views"
                  />
                ))}
              </div>
            ) : (
              <div className="py-12 px-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-2">
                  <Grid className="w-6 h-6" />
                </div>
                <h4 className="text-xs font-bold text-slate-800">No videos published yet</h4>
                <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                  Tap the + Create button in the bottom menu to record or upload your first ViralFlow short!
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'saved' && (
          <div>
            {savedVideos.length > 0 ? (
              <div className="grid grid-cols-3 gap-1.5">
                {savedVideos.map((video) => (
                  <ProfileVideoThumbnail
                    key={video.id}
                    video={video}
                    onClick={() => onSelectVideo(video)}
                    badgeType="saved"
                  />
                ))}
              </div>
            ) : (
              <div className="py-12 px-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-2">
                  <Bookmark className="w-6 h-6" />
                </div>
                <h4 className="text-xs font-bold text-slate-800">No saved videos yet</h4>
                <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                  Tap the bookmark ribbon icon on any video in your feed to save it for later.
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'liked' && (
          <div>
            {likedVideos.length > 0 ? (
              <div className="grid grid-cols-3 gap-1.5">
                {likedVideos.map((video) => (
                  <ProfileVideoThumbnail
                    key={video.id}
                    video={video}
                    onClick={() => onSelectVideo(video)}
                    badgeType="liked"
                  />
                ))}
              </div>
            ) : (
              <div className="py-12 px-4 text-center">
                <div className="w-12 h-12 rounded-2xl bg-pink-100 text-pink-600 flex items-center justify-center mx-auto mb-2">
                  <Heart className="w-6 h-6" />
                </div>
                <h4 className="text-xs font-bold text-slate-800">No liked videos yet</h4>
                <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                  Double tap any video in your For You feed to like it!
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Account Settings / Sign Out Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-sm bg-white/95 backdrop-blur-2xl rounded-3xl border border-white p-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-purple-600" />
                <h3 className="font-extrabold text-slate-900 text-sm">Account Settings</h3>
              </div>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              {/* Account details */}
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-medium">Account Status</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {currentUser.uid ? 'Firebase Connected' : 'Guest Mode'}
                  </span>
                </div>
                {currentUser.email && (
                  <div className="flex items-center justify-between text-xs mt-2">
                    <span className="text-slate-500 font-medium">Email</span>
                    <span className="font-semibold text-slate-800">{currentUser.email}</span>
                  </div>
                )}
                {currentUser.uid && (
                  <div className="flex items-center justify-between text-xs mt-1.5">
                    <span className="text-slate-500 font-medium">UID</span>
                    <span className="font-mono text-[10px] text-slate-600">{currentUser.uid.slice(0, 12)}...</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <button
                type="button"
                onClick={() => {
                  setIsSettingsOpen(false);
                  setIsEditOpen(true);
                }}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-100 text-slate-800 text-xs font-bold hover:bg-slate-200 flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <Edit3 className="w-4 h-4 text-purple-600" />
                <span>Edit Profile Info</span>
              </button>

              {/* Sign Out Action */}
              {onSignOut && (
                <button
                  type="button"
                  onClick={() => {
                    setIsSettingsOpen(false);
                    onSignOut();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl bg-red-50 text-red-600 hover:bg-red-100 text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all border border-red-200"
                >
                  <LogOut className="w-4 h-4 text-red-500" />
                  <span>Sign Out of ViralFlow</span>
                </button>
              )}

              {/* Official App Info */}
              <div className="pt-3 pb-1 flex flex-col items-center justify-center text-center">
                <span className="text-xs font-black tracking-tight text-slate-700">ViralFlow</span>
                <span className="text-[10px] font-semibold text-slate-400 tracking-wide">
                  Official Short-Video Platform • v1.2
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-sm bg-white/95 backdrop-blur-2xl rounded-3xl border border-white p-5 shadow-2xl animate-scaleUp">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-extrabold text-slate-900 text-sm">Edit ViralFlow Profile</h3>
              <button
                onClick={() => setIsEditOpen(false)}
                className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="mt-4 space-y-3">
              {/* Avatar Preview & Direct Photo Uploader */}
              <div className="flex flex-col items-center gap-2 pb-1">
                <div className="relative w-20 h-20 rounded-full p-[2.5px] bg-gradient-to-tr from-sky-400 via-purple-600 to-pink-500 shadow-md">
                  <img
                    src={editAvatar || (auth.currentUser?.photoURL || DEFAULT_AVATAR)}
                    alt="Avatar preview"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                    }}
                    className="w-full h-full rounded-full object-cover border-2 border-white bg-slate-100"
                  />
                  <label
                    htmlFor="avatar-file-upload"
                    className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white flex items-center justify-center border-2 border-white shadow-xs hover:scale-110 transition-transform cursor-pointer"
                    title="Upload photo from device"
                  >
                    <Upload className="w-3 h-3" />
                  </label>
                  <input
                    id="avatar-file-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onload = () => {
                          if (typeof reader.result === 'string') {
                            setEditAvatar(reader.result);
                          }
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </div>

                <div className="flex items-center gap-1.5 mt-0.5">
                  {auth.currentUser?.photoURL && auth.currentUser.photoURL !== editAvatar && (
                    <button
                      type="button"
                      onClick={() => setEditAvatar(auth.currentUser?.photoURL || '')}
                      className="px-2.5 py-1 rounded-full bg-purple-50 text-[10px] font-bold text-purple-600 hover:bg-purple-100 border border-purple-200 transition-colors cursor-pointer"
                    >
                      Use Google Photo
                    </button>
                  )}
                  {editAvatar && (
                    <button
                      type="button"
                      onClick={() => setEditAvatar('')}
                      className="px-2.5 py-1 rounded-full bg-slate-100 text-[10px] font-bold text-slate-600 hover:bg-slate-200 transition-colors cursor-pointer"
                    >
                      Use Default Avatar
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Avatar Image URL or Device Upload
                </label>
                <input
                  type="text"
                  placeholder="https://... or click upload icon above"
                  value={editAvatar}
                  onChange={(e) => setEditAvatar(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-100 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400 border border-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-100 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400 border border-slate-200"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Username
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-xs text-slate-400">@</span>
                  <input
                    type="text"
                    required
                    value={editUsername.replace(/^@/, '')}
                    onChange={(e) => setEditUsername(e.target.value)}
                    className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-100 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400 border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Bio
                </label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-100 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400 border border-slate-200 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 liquid-gradient-btn py-2.5 rounded-xl text-white text-xs font-black shadow-md cursor-pointer flex items-center justify-center gap-2 disabled:opacity-70"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <span>Save Changes</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </LiquidGlassBackground>
  );
};
