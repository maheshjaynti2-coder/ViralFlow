import React, { useState } from 'react';
import {
  ArrowRight,
  Mail,
  Sparkles,
  Lock,
  User,
  AlertCircle,
  Loader2,
  CheckCircle2,
  Eye,
  EyeOff
} from 'lucide-react';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';
import {
  signInWithGoogle,
  signInWithEmail,
  signUpWithEmail,
} from '../lib/firebase';

interface WelcomeScreenProps {
  onGetStarted: () => void;
  onSignInSuccess?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onGetStarted,
  onSignInSuccess,
}) => {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');

  // Form State
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status State
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [googleLoading, setGoogleLoading] = useState(false);

  const featurePills = [
    { label: 'Trending Now', icon: '⚡', color: 'text-amber-500' },
    { label: 'Real People', icon: '👥', color: 'text-sky-500' },
    { label: 'Amazing Content', icon: '🎵', color: 'text-purple-500' },
    { label: 'Positive Vibes', icon: '💜', color: 'text-pink-500' },
  ];

  // Map Firebase auth errors to readable messages
  const parseAuthError = (err: unknown): string => {
    if (!err || typeof err !== 'object') return 'Authentication failed. Please try again.';
    const code = (err as { code?: string }).code || '';
    switch (code) {
      case 'auth/email-already-in-use':
        return 'This email is already registered. Please sign in instead.';
      case 'auth/invalid-email':
        return 'Please enter a valid email address.';
      case 'auth/weak-password':
        return 'Password should be at least 6 characters.';
      case 'auth/user-not-found':
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return 'Incorrect email or password. Please check your credentials.';
      case 'auth/popup-closed-by-user':
        return 'Google Sign-In was cancelled.';
      case 'auth/network-request-failed':
        return 'Network connection issue. Please check your internet connection.';
      default:
        return (err as Error).message || 'Authentication error. Please try again.';
    }
  };

  // Handle Google Sign In
  const handleGoogleSignIn = async () => {
    setErrorMessage(null);
    setGoogleLoading(true);
    try {
      await signInWithGoogle();
      if (onSignInSuccess) onSignInSuccess();
    } catch (err) {
      console.error('Google sign in error:', err);
      setErrorMessage(parseAuthError(err));
    } finally {
      setGoogleLoading(false);
    }
  };

  // Handle Email Sign In or Sign Up
  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim() || !password.trim()) {
      setErrorMessage('Please enter both email and password.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setIsLoading(true);
    try {
      if (authMode === 'signup') {
        const finalDisplayName = displayName.trim() || 'ViralFlow Creator';
        const rawUser = username.trim().replace(/^@/, '') || email.split('@')[0];
        await signUpWithEmail(email.trim(), password, finalDisplayName, `@${rawUser}`);
      } else {
        await signInWithEmail(email.trim(), password);
      }
      setAuthModalOpen(false);
      if (onSignInSuccess) onSignInSuccess();
    } catch (err) {
      console.error('Email auth error:', err);
      setErrorMessage(parseAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <LiquidGlassBackground intensity="onboarding" className="min-h-full flex flex-col justify-between p-6 select-none">
      {/* Top Bar with Cursive Mood Note */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/60 backdrop-blur-md border border-white/80 shadow-xs">
          <Sparkles className="w-3.5 h-3.5 text-purple-600 animate-spin-slow" />
          <span className="text-[11px] font-bold text-slate-700">Official Release</span>
        </div>

        {/* Cursive text: "Good Vibes Better People ♡" */}
        <span className="font-script text-lg sm:text-xl text-purple-700 tracking-wide rotate-[-3deg] drop-shadow-xs">
          Good Vibes. Better People ♡
        </span>
      </div>

      {/* Main Center Hero Section */}
      <div className="my-auto flex flex-col items-center text-center py-6">
        <div className="relative mb-3 flex flex-col items-center">
          <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white shadow-xl mb-3">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900">
            Welcome to <span className="bg-gradient-to-r from-purple-600 via-pink-500 to-amber-500 bg-clip-text text-transparent">ViralFlow</span>
          </h1>

          {/* Cursive float annotation */}
          <div className="font-script text-base sm:text-lg text-pink-600 rotate-[-2deg] mt-1 drop-shadow-xs">
            Let Your Vibes Flow ♡
          </div>
        </div>

        {/* Catchphrase */}
        <div className="mt-4 max-w-xs">
          <p className="text-xs font-semibold text-slate-500 tracking-wider uppercase">
            More People <span className="text-purple-500">•</span> More Stories <span className="text-pink-500">•</span> A Brighter You
          </p>
        </div>

        {/* 4 Feature Badge Pills */}
        <div className="grid grid-cols-2 gap-2 mt-6 w-full max-w-xs">
          {featurePills.map((pill, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-white/70 backdrop-blur-md border border-white/90 shadow-sm text-left transition-all hover:bg-white"
            >
              <span className="text-base">{pill.icon}</span>
              <span className="text-xs font-bold text-slate-800">{pill.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons Section */}
      <div className="flex flex-col gap-2.5 w-full max-w-sm mx-auto pb-4">
        {/* Continue with Google */}
        <button
          onClick={handleGoogleSignIn}
          disabled={googleLoading}
          className="w-full py-3.5 px-6 rounded-2xl bg-white/90 backdrop-blur-xl border border-white/95 text-slate-800 font-bold text-xs flex items-center justify-center gap-2.5 shadow-md hover:bg-white active:scale-98 transition-all disabled:opacity-70 cursor-pointer"
        >
          {googleLoading ? (
            <>
              <Loader2 className="w-4 h-4 text-purple-600 animate-spin" />
              <span>Connecting with Google...</span>
            </>
          ) : (
            <>
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Continue with Google</span>
            </>
          )}
        </button>

        {/* Continue with Email */}
        <button
          onClick={() => {
            setAuthMode('signup');
            setErrorMessage(null);
            setAuthModalOpen(true);
          }}
          className="w-full py-3.5 px-6 rounded-2xl bg-white/75 backdrop-blur-xl border border-white/90 text-slate-800 font-bold text-xs flex items-center justify-center gap-2.5 shadow-sm hover:bg-white active:scale-98 transition-all cursor-pointer"
        >
          <Mail className="w-4 h-4 text-purple-600" />
          <span>Continue with Email</span>
        </button>

        {/* Explore as Guest / Get Started */}
        <button
          onClick={onGetStarted}
          className="liquid-gradient-btn w-full py-3 px-6 rounded-2xl text-white font-bold text-xs tracking-wide flex items-center justify-center gap-2 active:scale-98 transition-all group shadow-[0_10px_25px_-5px_rgba(124,58,237,0.4)] cursor-pointer"
        >
          <span>Explore Feed as Guest</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>

        {/* Already have an account? Sign In */}
        <div className="text-center pt-2">
          <p className="text-xs text-slate-600 font-medium">
            Already have an account?{' '}
            <button
              onClick={() => {
                setAuthMode('signin');
                setErrorMessage(null);
                setAuthModalOpen(true);
              }}
              className="font-extrabold text-purple-700 hover:text-purple-900 underline underline-offset-2 ml-1 cursor-pointer"
            >
              Sign In
            </button>
          </p>
        </div>
      </div>

      {/* Email Sign In / Sign Up Modal */}
      {authModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-sm bg-white/95 backdrop-blur-2xl rounded-3xl border border-white p-6 shadow-2xl animate-scaleUp">
            {/* Header Tabs */}
            <div className="flex items-center justify-center gap-2 p-1 bg-slate-100 rounded-2xl mb-4">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('signup');
                  setErrorMessage(null);
                }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  authMode === 'signup'
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Sign Up
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('signin');
                  setErrorMessage(null);
                }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
                  authMode === 'signin'
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Sign In
              </button>
            </div>

            <div className="text-center mb-4">
              <h3 className="font-extrabold text-slate-900 text-base">
                {authMode === 'signup' ? 'Create your ViralFlow Account' : 'Welcome back to ViralFlow'}
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                {authMode === 'signup'
                  ? 'Join creators worldwide and start sharing your flow'
                  : 'Enter your credentials to access your profile and saved videos'}
              </p>
            </div>

            {/* Error Banner */}
            {errorMessage && (
              <div className="mb-3.5 p-2.5 rounded-xl bg-red-50/90 border border-red-200 text-red-700 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span className="leading-snug">{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handleEmailAuth} className="space-y-3">
              {authMode === 'signup' && (
                <>
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Display Name
                    </label>
                    <div className="relative">
                      <User className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="e.g. Alex Rivera"
                        className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-100 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 border border-slate-200"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Username
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-2.5 text-xs text-slate-400 font-bold">@</span>
                      <input
                        type="text"
                        required
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="alexflow"
                        className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-slate-100 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 border border-slate-200"
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-100 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 border border-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-9 py-2.5 rounded-xl bg-slate-100 text-slate-900 text-xs focus:outline-none focus:ring-2 focus:ring-purple-500 border border-slate-200"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="liquid-gradient-btn w-full py-3 rounded-2xl text-white font-bold text-xs flex items-center justify-center gap-2 mt-2 shadow-md cursor-pointer disabled:opacity-60"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>{authMode === 'signup' ? 'Creating Account...' : 'Signing In...'}</span>
                  </>
                ) : (
                  <span>{authMode === 'signup' ? 'Create ViralFlow Account' : 'Sign In to ViralFlow'}</span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setAuthModalOpen(false)}
                className="w-full py-2 text-xs text-slate-500 hover:text-slate-800 font-medium cursor-pointer"
              >
                Cancel
              </button>
            </form>
          </div>
        </div>
      )}
    </LiquidGlassBackground>
  );
};
