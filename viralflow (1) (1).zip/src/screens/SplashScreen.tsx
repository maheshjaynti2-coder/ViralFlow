import React, { useEffect, useState } from 'react';
import { LiquidGlassBackground } from '../components/LiquidGlassBackground';
import { Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onFinish?: () => void;
  durationMs?: number;
}


export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  durationMs = 2000,
}) => {
  const [progress, setProgress] = useState(15);
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    // Smooth progress simulation
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval);
          return 100;
        }
        return prev + Math.floor(Math.random() * 20) + 12;
      });
    }, 180);

    // Fade out and finish
    const timer = setTimeout(() => {
      setIsFadingOut(true);
      setTimeout(() => {
        if (onFinish) onFinish();
      }, 350);
    }, durationMs);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, [durationMs, onFinish]);

  const handleSkip = () => {
    setIsFadingOut(true);
    setTimeout(() => {
      if (onFinish) onFinish();
    }, 150);
  };

  return (
    <div
      onClick={handleSkip}
      className={`fixed inset-0 z-50 w-full h-full cursor-pointer select-none transition-opacity duration-300 ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      <LiquidGlassBackground
        intensity="onboarding"
        className="w-full h-full flex flex-col items-center justify-between p-6"
      >
        {/* Top subtle badge */}
        <div className="pt-8 flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-white/70 backdrop-blur-md border border-white/80 shadow-xs animate-fade-in">
          <Sparkles className="w-3.5 h-3.5 text-purple-600 animate-spin-slow" />
          <span className="text-[11px] font-bold tracking-wider text-slate-700 uppercase">
            Official Short-Video Platform
          </span>
        </div>

        {/* Center: The exact ViralFlow Logo centered professionally */}
        <div className="flex-1 flex flex-col items-center justify-center -mt-6">
          <div className="relative flex flex-col items-center justify-center p-4">
            {/* Iridescent radial ambient glow directly behind logo */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-sky-400/20 via-purple-500/25 to-pink-400/20 blur-2xl scale-125 pointer-events-none animate-pulse" />

            {/* Brand typography */}
            <div className="relative z-10 flex flex-col items-center">
              <span className="text-4xl sm:text-5xl font-black tracking-tight text-slate-900">
                Viral<span className="bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">Flow</span>
              </span>
            </div>

            {/* Handwritten aesthetic subtitle */}
            <p className="font-script text-xl sm:text-2xl text-purple-700 rotate-[-2.5deg] mt-3 drop-shadow-xs">
              Good Vibes. Better People ♡
            </p>
          </div>
        </div>

        {/* Bottom loading progress & tagline */}
        <div className="pb-8 w-full max-w-xs flex flex-col items-center gap-2.5">
          {/* Shimmering liquid progress bar */}
          <div className="w-44 h-1.5 rounded-full bg-slate-200/80 overflow-hidden backdrop-blur-sm border border-white/60">
            <div
              className="h-full rounded-full bg-gradient-to-r from-sky-400 via-purple-600 to-pink-500 transition-all duration-300 shadow-[0_0_8px_rgba(168,85,247,0.8)]"
              style={{ width: `${Math.min(100, progress)}%` }}
            />
          </div>

          <div className="flex items-center gap-2 text-slate-500 text-[11px] font-semibold tracking-wider">
            <span>STARTING VIRALFLOW</span>
            <span className="text-purple-600 font-bold">•</span>
            <span className="text-purple-700 font-bold">100% AUTHENTIC</span>
          </div>

          <p className="text-[10px] text-slate-400 mt-1">Tap anywhere to continue</p>
        </div>
      </LiquidGlassBackground>
    </div>
  );
};
