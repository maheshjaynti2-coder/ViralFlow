import { UserProfile } from '../types';
import {
  sendFirestoreDirectMessage,
  subscribeUserConversations,
  subscribeConversationMessages,
  markConversationAsRead,
  getConversationId,
} from './firebase';

/**
 * Send a direct message or shared short video to a friend via Firestore
 */
export async function sendDirectMessageToFriend(params: {
  sender: UserProfile;
  recipient: {
    id: string;
    name: string;
    username: string;
    avatar: string;
  };
  text?: string;
  sharedVideo?: {
    id: string;
    caption: string;
    posterUrl: string;
    videoUrl?: string;
  };
}): Promise<{ conversationId: string; messageId: string }> {
  return sendFirestoreDirectMessage(params);
}

export {
  subscribeUserConversations,
  subscribeConversationMessages,
  markConversationAsRead,
  getConversationId,
};

