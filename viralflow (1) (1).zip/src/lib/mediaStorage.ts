/**
 * ViralFlow Client Media Storage
 * 
 * Provides durable local IndexedDB storage for video recording blobs and uploaded media,
 * ensuring high-speed local playback, offline persistence, and seamless Firestore publishing
 * without external storage bucket dependency.
 */

const DB_NAME = 'viralflow_media_db';
const STORE_NAME = 'video_blobs';
const DB_VERSION = 1;

function openMediaDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported in this environment.'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Save a video Blob in IndexedDB keyed by videoId
 */
export async function saveVideoBlobLocally(videoId: string, blob: Blob): Promise<string> {
  try {
    const db = await openMediaDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(blob, videoId);
      req.onsuccess = () => {
        const blobUrl = URL.createObjectURL(blob);
        resolve(blobUrl);
      };
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('Could not store blob in IndexedDB, using temporary ObjectURL:', err);
    return URL.createObjectURL(blob);
  }
}

/**
 * Retrieve a stored video Blob from IndexedDB and return an Object URL
 */
export async function getVideoBlobUrl(videoId: string): Promise<string | null> {
  try {
    const db = await openMediaDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(videoId);
      req.onsuccess = () => {
        if (req.result instanceof Blob) {
          resolve(URL.createObjectURL(req.result));
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export interface StorageUploadProgress {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
}

/**
 * Convert an image Blob to a base64 Data URL for compact thumbnail persistence
 */
export function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to convert blob to data URL'));
      }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

export const STORAGE_UNAVAILABLE_MESSAGE =
  'Video upload is temporarily unavailable. Firebase Storage needs to be enabled for this feature.';

/**
 * Process and persist video file or recording blob.
 * Emits progress callbacks to give real-time upload feedback to the user.
 * 
 * Note: Cloud Storage is currently unavailable on Firebase Spark tier.
 * Returns clear user-facing error message without faking persistence.
 */
export async function uploadVideoFileToStorage(
  _fileOrBlob: File | Blob,
  _userId: string,
  _onProgress?: (progress: StorageUploadProgress) => void
): Promise<{ downloadUrl: string; storagePath: string; videoId: string }> {
  throw new Error(STORAGE_UNAVAILABLE_MESSAGE);
}

/**
 * Persist thumbnail cover frame as optimized data URL
 */
export async function uploadThumbnailToStorage(
  thumbnailBlob: Blob,
  _userId: string
): Promise<string> {
  try {
    return await blobToDataURL(thumbnailBlob);
  } catch (err) {
    console.warn('Thumbnail conversion warning:', err);
    return URL.createObjectURL(thumbnailBlob);
  }
}
