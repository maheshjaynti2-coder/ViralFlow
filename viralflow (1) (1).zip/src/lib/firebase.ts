import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  increment,
  getDocs,
  getDocFromServer,
  Timestamp,
  runTransaction,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { MOCK_VIDEOS } from '../data/mockData';
import {
  FirestoreUserDoc,
  FirestoreVideoDoc,
  FirestoreLikeDoc,
  FirestoreCommentDoc,
  FirestoreCommentLikeDoc,
  FirestoreFollowDoc,
  FirestoreSavedVideoDoc,
  FirestoreNotificationDoc,
  FirestoreConversationDoc,
  FirestoreMessageDoc,
  UserProfile,
  VideoItem,
  CommentItem,
  NotificationItem,
  ChatMessage,
  ChatThread,
  DEFAULT_AVATAR,
} from '../types';

// 1. Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// 2. Export Auth and Provider
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// 3. Export Firestore with specific database ID if configured
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// ==========================================
// FIRESTORE ERROR HANDLING & TYPES
// ==========================================

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified ?? null,
      isAnonymous: auth.currentUser?.isAnonymous ?? null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ==========================================
// AUTHENTICATION SERVICES
// ==========================================

/**
 * Sign in with Google Popup
 */
export async function signInWithGoogle(): Promise<FirebaseUser> {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;

  // Ensure user profile document exists in Firestore
  const userDocRef = doc(db, 'users', user.uid);
  const userDocSnap = await getDoc(userDocRef);

  if (!userDocSnap.exists()) {
    const rawUsername =
      user.displayName?.toLowerCase().replace(/[^a-z0-9]/g, '') ||
      user.email?.split('@')[0] ||
      `user_${user.uid.slice(0, 5)}`;

    const newUserData: FirestoreUserDoc = {
      uid: user.uid,
      displayName: user.displayName || 'ViralFlow Creator',
      username: `@${rawUsername}`,
      email: user.email || '',
      photoURL: user.photoURL || '',
      bio: 'Creating my flow on ViralFlow ✨',
      followersCount: 0,
      followingCount: 0,
      createdAt: new Date().toISOString(),
    };
    await setDoc(userDocRef, newUserData);
  } else {
    // If doc exists without photoURL but Google provided one, sync it
    const data = userDocSnap.data() as FirestoreUserDoc;
    if (!data.photoURL && user.photoURL) {
      await updateDoc(userDocRef, { photoURL: user.photoURL }).catch(() => {});
    }
  }

  return user;
}

/**
 * Sign up with Email and Password
 */
export async function signUpWithEmail(
  email: string,
  pass: string,
  displayName: string,
  customUsername?: string
): Promise<FirebaseUser> {
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  const user = cred.user;

  // Update Auth Profile
  await updateProfile(user, {
    displayName: displayName.trim(),
    photoURL: '',
  });

  const formattedUsername = customUsername
    ? (customUsername.startsWith('@') ? customUsername : `@${customUsername}`)
    : `@${email.split('@')[0]}`;

  const newUserData: FirestoreUserDoc = {
    uid: user.uid,
    displayName: displayName.trim() || 'ViralFlow Creator',
    username: formattedUsername,
    email: user.email || email,
    photoURL: '',
    bio: 'Creating authentic stories on ViralFlow ✨',
    followersCount: 0,
    followingCount: 0,
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'users', user.uid), newUserData);
  return user;
}

/**
 * Sign in with Email and Password
 */
export async function signInWithEmail(email: string, pass: string): Promise<FirebaseUser> {
  const cred = await signInWithEmailAndPassword(auth, email, pass);
  return cred.user;
}

/**
 * Sign out of ViralFlow
 */
export async function signOutUser(): Promise<void> {
  await signOut(auth);
}

/**
 * Fetch a User profile by UID from Firestore
 */
export async function fetchUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userSnap = await getDoc(doc(db, 'users', uid));
    if (!userSnap.exists()) return null;
    const data = userSnap.data() as FirestoreUserDoc;
    const rawPhoto = (data.photoURL?.trim() || auth.currentUser?.photoURL?.trim() || '');
    const effectivePhoto =
      rawPhoto && !rawPhoto.includes('viralflow_logo') && !rawPhoto.includes('logo_transparent')
        ? rawPhoto
        : DEFAULT_AVATAR;

    return {
      uid: data.uid,
      name: data.displayName,
      displayName: data.displayName,
      username: data.username,
      email: data.email,
      avatar: effectivePhoto,
      photoURL: effectivePhoto !== DEFAULT_AVATAR ? effectivePhoto : '',
      bio: data.bio || '',
      followersCount: data.followersCount?.toLocaleString() || '0',
      followingCount: data.followingCount || 0,
      likesCount: '0',
      badge: 'Creator',
      links: 'viralflow.app/' + data.username.replace('@', ''),
      createdAt: data.createdAt,
    };
  } catch (err) {
    console.error('Error fetching user profile:', err);
    return null;
  }
}

/**
 * Real-time listener for current user's profile document in Firestore
 */
export function subscribeUserProfile(
  uid: string,
  callback: (profile: UserProfile | null) => void,
  onError?: (err: Error) => void
) {
  const userRef = doc(db, 'users', uid);
  return onSnapshot(
    userRef,
    (userSnap) => {
      if (!userSnap.exists()) {
        callback(null);
        return;
      }
      const data = userSnap.data() as FirestoreUserDoc;
      const rawPhoto = (data.photoURL?.trim() || auth.currentUser?.photoURL?.trim() || '');
      const effectivePhoto =
        rawPhoto && !rawPhoto.includes('viralflow_logo') && !rawPhoto.includes('logo_transparent')
          ? rawPhoto
          : DEFAULT_AVATAR;

      callback({
        uid: data.uid,
        name: data.displayName,
        displayName: data.displayName,
        username: data.username,
        email: data.email,
        avatar: effectivePhoto,
        photoURL: effectivePhoto !== DEFAULT_AVATAR ? effectivePhoto : '',
        bio: data.bio || '',
        followersCount: data.followersCount?.toLocaleString() || '0',
        followingCount: data.followingCount || 0,
        likesCount: '0',
        badge: 'Creator',
        links: 'viralflow.app/' + data.username.replace('@', ''),
        createdAt: data.createdAt,
      });
    },
    (err) => {
      console.warn('Error subscribing to user profile doc:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Real-time listener for real friends for the Share modal.
 * Loads real users from the Firestore `users` collection,
 * preferring connected users (following/followers),
 * excluding the current user.
 */
export function subscribeShareableFriends(
  currentUserId: string,
  callback: (friends: FirestoreUserDoc[]) => void,
  onError?: (err: Error) => void
) {
  const connectedIds = new Set<string>();

  const unsubFollowing = onSnapshot(
    query(collection(db, 'follows'), where('followerId', '==', currentUserId)),
    (snap) => {
      snap.forEach((d) => {
        const data = d.data();
        if (data.followingId) connectedIds.add(data.followingId);
      });
    },
    () => {}
  );

  const unsubFollowers = onSnapshot(
    query(collection(db, 'follows'), where('followingId', '==', currentUserId)),
    (snap) => {
      snap.forEach((d) => {
        const data = d.data();
        if (data.followerId) connectedIds.add(data.followerId);
      });
    },
    () => {}
  );

  const unsubUsers = onSnapshot(
    collection(db, 'users'),
    (snapshot) => {
      const allUsers: FirestoreUserDoc[] = [];
      snapshot.forEach((d) => {
        const u = d.data() as FirestoreUserDoc;
        if (u.uid && u.uid !== currentUserId) {
          allUsers.push(u);
        }
      });

      // Sort: connected friends first, then others
      allUsers.sort((a, b) => {
        const aConnected = connectedIds.has(a.uid) ? 1 : 0;
        const bConnected = connectedIds.has(b.uid) ? 1 : 0;
        if (aConnected !== bConnected) {
          return bConnected - aConnected;
        }
        return (b.followersCount || 0) - (a.followersCount || 0);
      });

      callback(allUsers);
    },
    (err) => {
      console.warn('Error in subscribeShareableFriends:', err);
      if (onError) onError(err);
    }
  );

  return () => {
    unsubFollowing();
    unsubFollowers();
    unsubUsers();
  };
}

/**
 * Update user profile in Firestore
 */
export async function updateUserProfileDoc(
  uid: string,
  updates: Partial<FirestoreUserDoc>
): Promise<void> {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, updates);
}

// ==========================================
// CLIENT MEDIA STORAGE & VIDEO FEED SERVICES
// ==========================================

export type { StorageUploadProgress } from './mediaStorage';
export {
  uploadVideoFileToStorage,
  uploadThumbnailToStorage,
  saveVideoBlobLocally,
  getVideoBlobUrl,
} from './mediaStorage';

/**
 * Publish video to Firestore `videos` collection
 */
export async function publishVideoToFirestore(video: {
  videoId?: string;
  ownerId: string;
  ownerName: string;
  ownerPhoto: string;
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  hashtags: string;
  musicName: string;
}): Promise<FirestoreVideoDoc> {
  const videoId = video.videoId || `vf_vid_${Date.now()}`;
  const videoDoc: FirestoreVideoDoc = {
    videoId,
    ownerId: video.ownerId,
    ownerName: video.ownerName,
    ownerPhoto: video.ownerPhoto,
    videoUrl: video.videoUrl,
    thumbnailUrl: video.thumbnailUrl,
    caption: video.caption,
    hashtags: video.hashtags,
    musicName: video.musicName,
    likesCount: 0,
    commentsCount: 0,
    sharesCount: 0,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'videos', videoId), videoDoc);
    return videoDoc;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `videos/${videoId}`);
  }
}

/**
 * Subscribe to real-time `videos` collection
 */
export function subscribeVideosCollection(
  callback: (videos: FirestoreVideoDoc[]) => void,
  onError?: (err: Error) => void
) {
  const q = query(collection(db, 'videos'), orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: FirestoreVideoDoc[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as FirestoreVideoDoc);
      });
      callback(items);
    },
    (error) => {
      console.warn('Snapshot listener error on videos:', error);
      if (onError) onError(error);
    }
  );
}

// ==========================================
// LIKES, SAVES, FOLLOWS & COMMENTS SERVICES
// ==========================================

/**
 * Read the authenticated user's actual like state directly from Firestore.
 * Queries the deterministic `likes` collection for all documents where `userId == userId`.
 */
export async function fetchUserLikedVideoIds(userId: string): Promise<Set<string>> {
  if (!userId) return new Set();
  try {
    const qLikes = query(collection(db, 'likes'), where('userId', '==', userId));
    const snapshot = await getDocs(qLikes);
    const set = new Set<string>();
    snapshot.forEach((d) => {
      const data = d.data();
      const vid = data.videoId || d.id.replace(`${userId}_`, '');
      if (vid) set.add(vid);
    });
    return set;
  } catch (err) {
    console.warn('Error fetching user likes from Firestore:', err);
    return new Set();
  }
}

/**
 * Ensures all initial catalog videos exist in Firestore `videos` collection.
 * This guarantees atomic like operations and real-time like counters across all devices.
 */
export async function ensureCatalogVideosInFirestore(): Promise<void> {
  if (!auth.currentUser) return;

  try {
    for (const demo of MOCK_VIDEOS) {
      const vRef = doc(db, 'videos', demo.id);
      const vSnap = await getDoc(vRef);
      if (!vSnap.exists()) {
        let count = demo.likesCount || 0;
        try {
          const qExisting = query(collection(db, 'likes'), where('videoId', '==', demo.id));
          const sExisting = await getDocs(qExisting);
          count += sExisting.size;
        } catch {}

        await setDoc(vRef, {
          videoId: demo.id,
          ownerId: demo.creator.id,
          ownerName: demo.creator.name,
          ownerPhoto: demo.creator.avatar,
          videoUrl: demo.videoUrl,
          thumbnailUrl: demo.posterUrl,
          caption: demo.caption,
          hashtags: demo.tags.join(' '),
          musicName: `${demo.music.title} • ${demo.music.artist}`,
          likesCount: count,
          commentsCount: demo.commentsCount || 0,
          sharesCount: demo.sharesCount || 0,
          createdAt: new Date().toISOString(),
        });
      }
    }
  } catch (err) {
    console.warn('Notice: Catalog video initialization:', err);
  }
}

/**
 * Toggle Like on video in Firestore using an atomic transaction.
 * - Uses deterministic document path: `likes/${userId}_${videoId}`
 * - Atomic read-modify-write prevents duplicate likes and ensures unlike removes only that user's like
 * - Keeps `videos/{videoId}.likesCount` strictly synchronized and consistent
 * - Initializes catalog video document in Firestore if needed
 */
export async function toggleFirestoreLike(
  userId: string,
  videoId: string,
  targetState?: boolean
): Promise<{ isLiked: boolean; likesCount: number }> {
  // If user is not authenticated, local optimistic state handles it
  if (!auth.currentUser || auth.currentUser.uid !== userId) {
    return { isLiked: targetState ?? false, likesCount: 0 };
  }

  const likeDocId = `${userId}_${videoId}`;
  const likeRef = doc(db, 'likes', likeDocId);
  const videoRef = doc(db, 'videos', videoId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const likeSnap = await transaction.get(likeRef);
      const videoSnap = await transaction.get(videoRef);

      const alreadyLiked = likeSnap.exists();
      const shouldLike = targetState !== undefined ? targetState : !alreadyLiked;

      // Determine current like count from Firestore or catalog baseline
      let currentLikesCount = 0;
      if (videoSnap.exists()) {
        const data = videoSnap.data();
        currentLikesCount = typeof data?.likesCount === 'number' ? data.likesCount : 0;
      } else {
        const demo = MOCK_VIDEOS.find((v) => v.id === videoId);
        currentLikesCount = demo?.likesCount ?? 0;
      }

      if (shouldLike) {
        // Prevent duplicate likes: if already liked, do not increment count again
        if (alreadyLiked) {
          return { isLiked: true, likesCount: currentLikesCount };
        }

        // Create deterministic like document
        const newLike: FirestoreLikeDoc = {
          userId,
          videoId,
          createdAt: new Date().toISOString(),
        };
        transaction.set(likeRef, newLike);

        const newCount = currentLikesCount + 1;
        if (videoSnap.exists()) {
          transaction.update(videoRef, { likesCount: newCount });
        } else {
          // Initialize video document in Firestore
          const demo = MOCK_VIDEOS.find((v) => v.id === videoId);
          if (demo) {
            transaction.set(videoRef, {
              videoId: demo.id,
              ownerId: demo.creator.id,
              ownerName: demo.creator.name,
              ownerPhoto: demo.creator.avatar,
              videoUrl: demo.videoUrl,
              thumbnailUrl: demo.posterUrl,
              caption: demo.caption,
              hashtags: demo.tags.join(' '),
              musicName: `${demo.music.title} • ${demo.music.artist}`,
              likesCount: newCount,
              commentsCount: demo.commentsCount || 0,
              sharesCount: demo.sharesCount || 0,
              createdAt: new Date().toISOString(),
            });
          }
        }

        return { isLiked: true, likesCount: newCount };
      } else {
        // Unliking: ensure unlike removes only that user's like
        if (!alreadyLiked) {
          return { isLiked: false, likesCount: currentLikesCount };
        }

        transaction.delete(likeRef);
        const newCount = Math.max(0, currentLikesCount - 1);

        if (videoSnap.exists()) {
          transaction.update(videoRef, { likesCount: newCount });
        } else {
          const demo = MOCK_VIDEOS.find((v) => v.id === videoId);
          if (demo) {
            transaction.set(videoRef, {
              videoId: demo.id,
              ownerId: demo.creator.id,
              ownerName: demo.creator.name,
              ownerPhoto: demo.creator.avatar,
              videoUrl: demo.videoUrl,
              thumbnailUrl: demo.posterUrl,
              caption: demo.caption,
              hashtags: demo.tags.join(' '),
              musicName: `${demo.music.title} • ${demo.music.artist}`,
              likesCount: newCount,
              commentsCount: demo.commentsCount || 0,
              sharesCount: demo.sharesCount || 0,
              createdAt: new Date().toISOString(),
            });
          }
        }

        return { isLiked: false, likesCount: newCount };
      }
    });

    return result;
  } catch (err) {
    console.warn('Atomic Firestore like transaction notice:', err instanceof Error ? err.message : err);
    throw err;
  }
}

/**
 * Toggle Save / Bookmark on video in Firestore
 */
export async function toggleFirestoreSave(
  userId: string,
  videoId: string,
  isCurrentlySaved: boolean
): Promise<void> {
  // If user is in guest mode or not logged into Firebase Auth, local optimistic state handles it
  if (!auth.currentUser || auth.currentUser.uid !== userId) {
    return;
  }

  const saveDocId = `${userId}_${videoId}`;
  const saveRef = doc(db, 'savedVideos', saveDocId);

  try {
    if (isCurrentlySaved) {
      await deleteDoc(saveRef);
    } else {
      const newSave: FirestoreSavedVideoDoc = {
        userId,
        videoId,
        createdAt: new Date().toISOString(),
      };
      await setDoc(saveRef, newSave);
    }
  } catch (err) {
    console.warn('Firestore save sync notice (handled):', err instanceof Error ? err.message : err);
  }
}

/**
 * Toggle Follow creator in Firestore
 */
export async function toggleFirestoreFollow(
  followerId: string,
  followingId: string,
  isCurrentlyFollowing: boolean
): Promise<void> {
  if (followerId === followingId) return;
  // If user is in guest mode or not logged into Firebase Auth, local optimistic state handles it
  if (!auth.currentUser || auth.currentUser.uid !== followerId) {
    return;
  }

  const followDocId = `${followerId}_${followingId}`;
  const followRef = doc(db, 'follows', followDocId);

  const followerUserRef = doc(db, 'users', followerId);
  const followingUserRef = doc(db, 'users', followingId);

  try {
    if (isCurrentlyFollowing) {
      await deleteDoc(followRef);
      await updateDoc(followerUserRef, { followingCount: increment(-1) }).catch(() => {});
      await updateDoc(followingUserRef, { followersCount: increment(-1) }).catch(() => {});
    } else {
      const newFollow: FirestoreFollowDoc = {
        followerId,
        followingId,
        createdAt: new Date().toISOString(),
      };
      await setDoc(followRef, newFollow);
      await updateDoc(followerUserRef, { followingCount: increment(1) }).catch(() => {});
      await updateDoc(followingUserRef, { followersCount: increment(1) }).catch(() => {});
    }
  } catch (err) {
    console.warn('Firestore follow sync notice (handled):', err instanceof Error ? err.message : err);
  }
}

/**
 * Helper to format readable relative time for comments
 */
export function formatCommentTime(dateStr: string): string {
  try {
    const time = new Date(dateStr).getTime();
    if (isNaN(time)) return 'Just now';
    const diffMs = Date.now() - time;
    if (diffMs < 60000) return 'Just now';
    const diffMin = Math.floor(diffMs / 60000);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    if (diffDays < 7) return `${diffDays}d ago`;
    return new Date(dateStr).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch {
    return 'Just now';
  }
}

/**
 * Post a comment or threaded reply to a video in Firestore
 */
export async function addFirestoreComment(
  videoId: string,
  userId: string,
  text: string,
  userProfile: { name: string; username: string; avatar: string },
  parentId?: string | null,
  replyToUser?: string | null
): Promise<FirestoreCommentDoc> {
  const commentId = `cmt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const commentRef = doc(db, 'comments', commentId);
  const videoRef = doc(db, 'videos', videoId);

  const commentData: FirestoreCommentDoc = {
    commentId,
    videoId,
    userId,
    text: text.trim(),
    userName: userProfile.name,
    userAvatar: userProfile.avatar,
    likesCount: 0,
    createdAt: new Date().toISOString(),
    parentId: parentId || null,
    replyToUser: replyToUser || null,
  };

  await setDoc(commentRef, commentData);
  await updateDoc(videoRef, {
    commentsCount: increment(1),
  }).catch(() => {});

  return commentData;
}

/**
 * Atomically toggle a comment like in Firestore and update the comment's likesCount
 */
export async function toggleFirestoreCommentLike(
  userId: string,
  commentId: string,
  videoId: string,
  targetState?: boolean
): Promise<{ isLiked: boolean; likesCount: number }> {
  if (!auth.currentUser || auth.currentUser.uid !== userId) {
    throw new Error('You must be signed in to like a comment.');
  }

  const likeDocId = `${userId}_${commentId}`;
  const likeRef = doc(db, 'commentLikes', likeDocId);
  const commentRef = doc(db, 'comments', commentId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const likeSnap = await transaction.get(likeRef);
      const commentSnap = await transaction.get(commentRef);

      const alreadyLiked = likeSnap.exists();
      const shouldLike = targetState !== undefined ? targetState : !alreadyLiked;

      let currentLikesCount = 0;
      if (commentSnap.exists()) {
        const data = commentSnap.data();
        currentLikesCount = typeof data?.likesCount === 'number' ? data.likesCount : 0;
      }

      if (shouldLike) {
        if (alreadyLiked) {
          return { isLiked: true, likesCount: currentLikesCount };
        }
        transaction.set(likeRef, {
          userId,
          commentId,
          videoId,
          createdAt: new Date().toISOString(),
        } as FirestoreCommentLikeDoc);

        const newCount = currentLikesCount + 1;
        if (commentSnap.exists()) {
          transaction.update(commentRef, { likesCount: newCount });
        }
        return { isLiked: true, likesCount: newCount };
      } else {
        if (!alreadyLiked) {
          return { isLiked: false, likesCount: currentLikesCount };
        }
        transaction.delete(likeRef);
        const newCount = Math.max(0, currentLikesCount - 1);
        if (commentSnap.exists()) {
          transaction.update(commentRef, { likesCount: newCount });
        }
        return { isLiked: false, likesCount: newCount };
      }
    });

    return result;
  } catch (err) {
    console.warn('Comment like transaction notice:', err);
    throw err;
  }
}

/**
 * Subscribe to comments and threaded replies for a specific video in real-time
 */
export function subscribeVideoComments(
  videoId: string,
  userIdOrCallback: string | null | undefined | ((comments: CommentItem[]) => void),
  callbackOrError?: ((comments: CommentItem[]) => void) | ((err: Error) => void),
  onError?: (err: Error) => void
) {
  let currentUserId: string | null = null;
  let callback: (comments: CommentItem[]) => void;
  let errorHandler: ((err: Error) => void) | undefined = onError;

  if (typeof userIdOrCallback === 'function') {
    callback = userIdOrCallback;
    if (typeof callbackOrError === 'function') {
      errorHandler = callbackOrError as (err: Error) => void;
    }
  } else {
    currentUserId = userIdOrCallback || null;
    callback = callbackOrError as (comments: CommentItem[]) => void;
  }

  let userLikedCommentIds = new Set<string>();
  let cachedCommentsDocs: FirestoreCommentDoc[] = [];

  const updateItems = () => {
    const allItems: CommentItem[] = cachedCommentsDocs.map((data) => {
      const isLiked = userLikedCommentIds.has(data.commentId);
      const likesCount = typeof data.likesCount === 'number' ? Math.max(0, data.likesCount) : 0;
      return {
        id: data.commentId,
        videoId: data.videoId,
        userId: data.userId,
        user: {
          name: data.userName || 'ViralFlow User',
          username: data.userId ? data.userId.slice(0, 8) : 'creator',
          avatar: data.userAvatar || DEFAULT_AVATAR,
        },
        text: data.text,
        likesCount,
        isLiked,
        createdAt: formatCommentTime(data.createdAt),
        createdAtTimestamp: data.createdAt,
        parentId: data.parentId || null,
        replyToUser: data.replyToUser || null,
      };
    });

    // Build threaded structure:
    const rootComments: CommentItem[] = [];
    const repliesMap: Record<string, CommentItem[]> = {};

    for (const item of allItems) {
      if (item.parentId) {
        if (!repliesMap[item.parentId]) {
          repliesMap[item.parentId] = [];
        }
        repliesMap[item.parentId].push(item);
      } else {
        rootComments.push(item);
      }
    }

    // Link replies to parent roots
    for (const root of rootComments) {
      const directReplies = repliesMap[root.id] || [];
      directReplies.sort(
        (a, b) =>
          new Date(a.createdAtTimestamp || 0).getTime() -
          new Date(b.createdAtTimestamp || 0).getTime()
      );
      root.replies = directReplies;
    }

    // Handle nested / chained replies
    for (const [parentId, orphans] of Object.entries(repliesMap)) {
      const root = rootComments.find((r) => r.id === parentId);
      if (!root) {
        const parentRoot = rootComments.find((r) =>
          r.replies?.some((rep) => rep.id === parentId)
        );
        if (parentRoot) {
          parentRoot.replies = [...(parentRoot.replies || []), ...orphans].sort(
            (a, b) =>
              new Date(a.createdAtTimestamp || 0).getTime() -
              new Date(b.createdAtTimestamp || 0).getTime()
          );
        } else {
          rootComments.push(...orphans);
        }
      }
    }

    // Sort root comments newest first
    rootComments.sort(
      (a, b) =>
        new Date(b.createdAtTimestamp || 0).getTime() -
        new Date(a.createdAtTimestamp || 0).getTime()
    );

    callback(rootComments);
  };

  const q = query(
    collection(db, 'comments'),
    where('videoId', '==', videoId)
  );

  const unsubComments = onSnapshot(
    q,
    (snapshot) => {
      cachedCommentsDocs = [];
      snapshot.forEach((snap) => {
        cachedCommentsDocs.push(snap.data() as FirestoreCommentDoc);
      });
      updateItems();
    },
    (err) => {
      console.warn('Error subscribing to video comments:', err);
      if (errorHandler) errorHandler(err);
    }
  );

  let unsubLikes: (() => void) | null = null;
  const effectiveUid = currentUserId || auth.currentUser?.uid;
  if (effectiveUid) {
    const qLikes = query(
      collection(db, 'commentLikes'),
      where('videoId', '==', videoId),
      where('userId', '==', effectiveUid)
    );
    unsubLikes = onSnapshot(
      qLikes,
      (snapshot) => {
        const nextSet = new Set<string>();
        snapshot.forEach((snap) => {
          const d = snap.data();
          if (d.commentId) nextSet.add(d.commentId);
        });
        userLikedCommentIds = nextSet;
        updateItems();
      },
      (err) => {
        console.warn('Error subscribing to user comment likes:', err);
      }
    );
  }

  return () => {
    unsubComments();
    if (unsubLikes) unsubLikes();
  };
}

/**
 * Subscribe to User's Likes, Saves, and Follows sets
 */
export function subscribeUserData(
  userId: string,
  callbacks: {
    onLikesChange?: (likedVideoIds: Set<string>) => void;
    onSavesChange?: (savedVideoIds: Set<string>) => void;
    onFollowsChange?: (followedUserIds: Set<string>) => void;
  }
) {
  const unsubs: (() => void)[] = [];

  if (callbacks.onLikesChange) {
    const qLikes = query(collection(db, 'likes'), where('userId', '==', userId));
    const unsubLikes = onSnapshot(
      qLikes,
      (snapshot) => {
        const set = new Set<string>();
        snapshot.forEach((d) => {
          const data = d.data();
          const vid = data.videoId || d.id.replace(`${userId}_`, '');
          if (vid) set.add(vid);
        });
        callbacks.onLikesChange?.(set);
      },
      (err) => console.warn('Likes sub error:', err)
    );
    unsubs.push(unsubLikes);
  }

  if (callbacks.onSavesChange) {
    const qSaves = query(collection(db, 'savedVideos'), where('userId', '==', userId));
    const unsubSaves = onSnapshot(
      qSaves,
      (snapshot) => {
        const set = new Set<string>();
        snapshot.forEach((d) => set.add(d.data().videoId));
        callbacks.onSavesChange?.(set);
      },
      (err) => console.warn('Saves sub error:', err)
    );
    unsubs.push(unsubSaves);
  }

  if (callbacks.onFollowsChange) {
    const qFollows = query(collection(db, 'follows'), where('followerId', '==', userId));
    const unsubFollows = onSnapshot(
      qFollows,
      (snapshot) => {
        const set = new Set<string>();
        snapshot.forEach((d) => set.add(d.data().followingId));
        callbacks.onFollowsChange?.(set);
      },
      (err) => console.warn('Follows sub error:', err)
    );
    unsubs.push(unsubFollows);
  }

  return () => {
    unsubs.forEach((u) => u());
  };
}

/**
 * Subscribe to all users from Firestore users collection
 */
export function subscribeFirestoreUsers(
  callback: (users: FirestoreUserDoc[]) => void,
  onError?: (err: Error) => void
) {
  const usersRef = collection(db, 'users');
  return onSnapshot(
    usersRef,
    (snapshot) => {
      const users: FirestoreUserDoc[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as FirestoreUserDoc;
        users.push(data);
      });
      // Sort by followersCount or createdAt descending
      users.sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
      });
      callback(users);
    },
    (err) => {
      console.warn('Error subscribing to Firestore users:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Create a new notification in Firestore for a recipient user
 */
export async function createFirestoreNotification(params: {
  recipientId: string;
  senderId: string;
  senderName: string;
  senderUsername?: string;
  senderAvatar?: string;
  type: 'like' | 'comment' | 'reply' | 'follow' | 'mention' | 'system';
  message: string;
  videoId?: string;
  videoThumbnail?: string;
  commentId?: string;
}): Promise<void> {
  // Prevent notifying yourself
  if (!params.recipientId || !params.senderId || params.recipientId === params.senderId) {
    return;
  }
  // Must be authenticated as sender
  if (!auth.currentUser || auth.currentUser.uid !== params.senderId) {
    return;
  }

  // Prevent duplicate notifications with deterministic IDs for likes, follows, and comments
  let notificationId = `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  if (params.type === 'like' && params.videoId) {
    notificationId = `notif_like_${params.senderId}_${params.videoId}`;
  } else if (params.type === 'follow') {
    notificationId = `notif_follow_${params.senderId}_${params.recipientId}`;
  } else if (params.type === 'comment' && params.commentId) {
    notificationId = `notif_cmt_${params.commentId}`;
  } else if (params.type === 'reply' && params.commentId) {
    notificationId = `notif_rep_${params.commentId}`;
  }

  const notifRef = doc(db, 'notifications', notificationId);
  const notifDoc: FirestoreNotificationDoc = {
    notificationId,
    recipientId: params.recipientId,
    senderId: params.senderId,
    senderName: params.senderName,
    senderUsername: params.senderUsername || params.senderId.slice(0, 8),
    senderAvatar: params.senderAvatar || DEFAULT_AVATAR,
    type: params.type,
    message: params.message,
    videoId: params.videoId || '',
    videoThumbnail: params.videoThumbnail || '',
    commentId: params.commentId || '',
    isRead: false,
    createdAt: new Date().toISOString(),
  };

  try {
    await setDoc(notifRef, notifDoc);
  } catch (err) {
    console.warn('Notice saving Firestore notification (handled):', err instanceof Error ? err.message : err);
  }
}

/**
 * Subscribe in real time to the current user's notifications
 */
export function subscribeUserNotifications(
  userId: string,
  callback: (notifications: NotificationItem[]) => void,
  onError?: (err: Error) => void
) {
  if (!userId) {
    callback([]);
    return () => {};
  }

  const q = query(
    collection(db, 'notifications'),
    where('recipientId', '==', userId)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const items: NotificationItem[] = [];
      snapshot.forEach((snapDoc) => {
        const data = snapDoc.data() as FirestoreNotificationDoc;
        items.push({
          id: data.notificationId,
          type: data.type,
          actor: {
            id: data.senderId,
            name: data.senderName,
            username: data.senderUsername || data.senderId.slice(0, 8),
            avatar: data.senderAvatar || DEFAULT_AVATAR,
          },
          text: data.message,
          timestamp: formatCommentTime(data.createdAt),
          createdAtTimestamp: data.createdAt,
          videoThumbnail: data.videoThumbnail || undefined,
          videoId: data.videoId || undefined,
          commentId: data.commentId || undefined,
          isRead: !!data.isRead,
          recipientId: data.recipientId,
        });
      });

      // Sort newest first
      items.sort(
        (a, b) =>
          new Date(b.createdAtTimestamp || 0).getTime() -
          new Date(a.createdAtTimestamp || 0).getTime()
      );

      callback(items);
    },
    (err) => {
      console.warn('Error subscribing to notifications:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Mark an individual notification as read
 */
export async function markFirestoreNotificationAsRead(notificationId: string): Promise<void> {
  if (!auth.currentUser || !notificationId) return;
  try {
    const notifRef = doc(db, 'notifications', notificationId);
    await updateDoc(notifRef, { isRead: true });
  } catch (err) {
    console.warn('Error marking notification as read:', err);
  }
}

/**
 * Mark multiple or all notifications as read for current user
 */
export async function markAllFirestoreNotificationsAsRead(
  userId: string,
  notificationIds: string[]
): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== userId || !notificationIds.length) return;
  try {
    const batchPromises = notificationIds.map((id) =>
      updateDoc(doc(db, 'notifications', id), { isRead: true }).catch(() => {})
    );
    await Promise.all(batchPromises);
  } catch (err) {
    console.warn('Error marking all notifications as read:', err);
  }
}

// ==========================================
// DIRECT MESSAGES & CONVERSATIONS (FIRESTORE)
// ==========================================

/**
 * Generates a deterministic conversation ID for two users (e.g. uidA_uidB)
 */
export function getConversationId(uid1: string, uid2: string): string {
  return [uid1, uid2].sort().join('_');
}

/**
 * Format timestamps for chat threads and bubbles
 */
export function formatChatMessageTime(isoString: string): string {
  if (!isoString) return 'Just now';
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return 'Just now';
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);

    if (diffSec < 45) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) {
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    if (diffDay < 7) {
      const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      return `${days[d.getDay()]} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  } catch {
    return 'Just now';
  }
}

/**
 * Subscribe in real time to the authenticated user's conversations
 */
export function subscribeUserConversations(
  userId: string,
  callback: (threads: ChatThread[]) => void,
  onError?: (err: unknown) => void
) {
  if (!userId) {
    callback([]);
    return () => {};
  }

  const q = query(
    collection(db, 'conversations'),
    where('participantIds', 'array-contains', userId)
  );

  return onSnapshot(
    q,
    (snapshot) => {
      const threads: ChatThread[] = [];
      snapshot.forEach((snapDoc) => {
        const data = snapDoc.data() as FirestoreConversationDoc;
        const otherParticipantId = data.participantIds.find((id) => id !== userId) || userId;
        const otherUser = data.participants?.[otherParticipantId] || {
          id: otherParticipantId,
          name: 'ViralFlow Creator',
          username: `@creator_${otherParticipantId.slice(0, 5)}`,
          avatar: DEFAULT_AVATAR,
        };

        const unreadCount = data.unreadCounts?.[userId] || 0;
        const lastMsgText = data.lastMessage?.text || 'Started a conversation';
        const updatedAtStr = data.lastMessage?.createdAt || data.updatedAt || new Date().toISOString();

        threads.push({
          id: snapDoc.id,
          participantIds: data.participantIds,
          user: {
            id: otherUser.id,
            name: otherUser.name || 'ViralFlow Creator',
            username: otherUser.username.startsWith('@') ? otherUser.username : `@${otherUser.username}`,
            avatar: otherUser.avatar || DEFAULT_AVATAR,
            isOnline: true,
          },
          lastMessage: lastMsgText,
          lastMessageSenderId: data.lastMessage?.senderId,
          timestamp: formatChatMessageTime(updatedAtStr),
          updatedAtTimestamp: updatedAtStr,
          unreadCount,
          messages: [],
        });
      });

      // Sort newest conversations first
      threads.sort(
        (a, b) =>
          new Date(b.updatedAtTimestamp || 0).getTime() -
          new Date(a.updatedAtTimestamp || 0).getTime()
      );

      callback(threads);
    },
    (err) => {
      console.warn('Error subscribing to conversations:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Subscribe in real time to messages within an active conversation
 */
export function subscribeConversationMessages(
  conversationId: string,
  currentUserId: string,
  callback: (messages: ChatMessage[]) => void,
  onError?: (err: unknown) => void
) {
  if (!conversationId) {
    callback([]);
    return () => {};
  }

  const messagesRef = collection(db, 'conversations', conversationId, 'messages');
  const q = query(messagesRef);

  return onSnapshot(
    q,
    (snapshot) => {
      const messages: ChatMessage[] = [];
      snapshot.forEach((snapDoc) => {
        const data = snapDoc.data() as FirestoreMessageDoc;
        messages.push({
          id: data.messageId || snapDoc.id,
          conversationId: data.conversationId,
          senderId: data.senderId,
          recipientId: data.recipientId,
          text: data.text,
          timestamp: formatChatMessageTime(data.createdAt),
          createdAtTimestamp: data.createdAt,
          isMe: data.senderId === currentUserId,
          isRead: !!data.isRead,
          sharedVideo: data.sharedVideo,
        });
      });

      // Sort messages chronologically (oldest to newest)
      messages.sort(
        (a, b) =>
          new Date(a.createdAtTimestamp || 0).getTime() -
          new Date(b.createdAtTimestamp || 0).getTime()
      );

      callback(messages);
    },
    (err) => {
      console.warn('Error subscribing to conversation messages:', err);
      if (onError) onError(err);
    }
  );
}

/**
 * Send a direct message to a user or friend in Firestore
 */
export async function sendFirestoreDirectMessage(params: {
  sender: UserProfile;
  recipient: {
    id: string;
    name: string;
    username: string;
    avatar: string;
  };
  text?: string;
  sharedVideo?: {
    id: string;
    caption: string;
    posterUrl: string;
    videoUrl?: string;
  };
}): Promise<{ conversationId: string; messageId: string }> {
  const currentAuthUser = auth.currentUser;
  if (!currentAuthUser) {
    throw new Error('You must be signed in to send a direct message.');
  }

  const senderId = currentAuthUser.uid;
  const recipientId = params.recipient.id;

  if (!recipientId || recipientId === senderId) {
    throw new Error('Invalid message recipient.');
  }

  const messageText = (params.text || (params.sharedVideo ? `Shared a Short: "${params.sharedVideo.caption}"` : '')).trim();
  if (!messageText && !params.sharedVideo) {
    throw new Error('Cannot send an empty message.');
  }

  const conversationId = getConversationId(senderId, recipientId);
  const messageId = `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = new Date().toISOString();

  // 1. Write message document to subcollection
  const messageRef = doc(db, 'conversations', conversationId, 'messages', messageId);
  const messageData: FirestoreMessageDoc = {
    messageId,
    conversationId,
    senderId,
    recipientId,
    text: messageText,
    sharedVideo: params.sharedVideo
      ? {
          id: params.sharedVideo.id,
          caption: params.sharedVideo.caption,
          posterUrl: params.sharedVideo.posterUrl,
          videoUrl: params.sharedVideo.videoUrl,
        }
      : undefined,
    isRead: false,
    createdAt: now,
  };

  await setDoc(messageRef, messageData);

  // 2. Set/Update conversation document with participants, preview, and unread counts
  const convRef = doc(db, 'conversations', conversationId);
  const senderName = params.sender.displayName || params.sender.name || currentAuthUser.displayName || 'ViralFlow Creator';
  const senderUsername = params.sender.username || (currentAuthUser.email ? `@${currentAuthUser.email.split('@')[0]}` : `@user_${senderId.slice(0, 5)}`);
  const senderAvatar = params.sender.avatar || params.sender.photoURL || currentAuthUser.photoURL || DEFAULT_AVATAR;

  await setDoc(
    convRef,
    {
      id: conversationId,
      participantIds: [senderId, recipientId],
      participants: {
        [senderId]: {
          id: senderId,
          name: senderName,
          username: senderUsername,
          avatar: senderAvatar,
        },
        [recipientId]: {
          id: recipientId,
          name: params.recipient.name || 'ViralFlow Creator',
          username: params.recipient.username || `@user_${recipientId.slice(0, 5)}`,
          avatar: params.recipient.avatar || DEFAULT_AVATAR,
        },
      },
      lastMessage: {
        text: messageText,
        senderId,
        createdAt: now,
        isRead: false,
      },
      unreadCounts: {
        [recipientId]: increment(1),
        [senderId]: 0,
      },
      updatedAt: now,
    },
    { merge: true }
  );

  return { conversationId, messageId };
}

/**
 * Mark a conversation as read when opened by the recipient
 */
export async function markConversationAsRead(
  conversationId: string,
  currentUserId: string
): Promise<void> {
  if (!auth.currentUser || auth.currentUser.uid !== currentUserId || !conversationId) return;

  try {
    // 1. Reset recipient unread counter on the conversation document
    const convRef = doc(db, 'conversations', conversationId);
    await updateDoc(convRef, {
      [`unreadCounts.${currentUserId}`]: 0,
    }).catch(() => {});

    // 2. Mark unread message documents sent to current user as read
    const unreadMessagesQuery = query(
      collection(db, 'conversations', conversationId, 'messages'),
      where('recipientId', '==', currentUserId),
      where('isRead', '==', false)
    );

    const snapshot = await getDocs(unreadMessagesQuery);
    if (!snapshot.empty) {
      const updatePromises = snapshot.docs.map((d) =>
        updateDoc(d.ref, { isRead: true }).catch(() => {})
      );
      await Promise.all(updatePromises);
    }
  } catch (err) {
    console.warn('Error marking conversation as read in Firestore:', err);
  }
}

