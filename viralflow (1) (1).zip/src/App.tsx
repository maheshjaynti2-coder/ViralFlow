import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { TabType, FeedTabType, VideoItem, UserProfile, FirestoreVideoDoc, DEFAULT_AVATAR } from './types';
import { INITIAL_USER, MOCK_VIDEOS } from './data/mockData';
import { DeviceFrame } from './components/DeviceFrame';
import { BottomNav } from './components/BottomNav';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { HomeScreen } from './screens/HomeScreen';
import { ExploreScreen } from './screens/ExploreScreen';
import { CreateScreen } from './screens/CreateScreen';
import { InboxScreen } from './screens/InboxScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { DiscoverCreatorsScreen } from './screens/DiscoverCreatorsScreen';
import { SavedFavoritesScreen } from './screens/SavedFavoritesScreen';
import { CreatorProfileModal } from './components/CreatorProfileModal';
import {
  auth,
  signOutUser,
  fetchUserProfile,
  subscribeUserProfile,
  subscribeVideosCollection,
  publishVideoToFirestore,
  toggleFirestoreLike,
  toggleFirestoreSave,
  toggleFirestoreFollow,
  subscribeUserData,
  createFirestoreNotification,
  subscribeUserNotifications,
  subscribeUserConversations,
  fetchUserLikedVideoIds,
  ensureCatalogVideosInFirestore,
} from './lib/firebase';

export default function App() {
  const [isOnboarded, setIsOnboarded] = useState<boolean>(false);
  const [authInitialized, setAuthInitialized] = useState<boolean>(false);
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [activeFeedTab, setActiveFeedTab] = useState<FeedTabType>('forYou');

  // Video State: raw Firestore items + local items
  const [firestoreVideos, setFirestoreVideos] = useState<FirestoreVideoDoc[]>([]);
  const [localPostedVideos, setLocalPostedVideos] = useState<VideoItem[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile>(INITIAL_USER);

  // User Interaction sets from Firestore
  const [likedVideoIds, setLikedVideoIds] = useState<Set<string>>(new Set());
  const [savedVideoIds, setSavedVideoIds] = useState<Set<string>>(new Set());
  const [followedUserIds, setFollowedUserIds] = useState<Set<string>>(new Set());
  const [unreadNotificationsCount, setUnreadNotificationsCount] = useState<number>(0);
  const [unreadDirectMessagesCount, setUnreadDirectMessagesCount] = useState<number>(0);

  // UI Navigation states
  const [selectedHashtag, setSelectedHashtag] = useState<string>('');
  const [selectedCreatorId, setSelectedCreatorId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2800);
  }, []);

  // 1. Firebase Auth listener with real-time profile synchronization
  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (firebaseUser) {
        // Read authenticated user's actual like state from Firestore on feed load
        fetchUserLikedVideoIds(firebaseUser.uid)
          .then((actualLikes) => {
            setLikedVideoIds(actualLikes);
          })
          .catch((err) => {
            console.warn('Could not read user likes from Firestore on feed load:', err);
          });

        // Initialize catalog videos in Firestore for consistent atomic counters
        ensureCatalogVideosInFirestore().catch(() => {});

        // Hydrate from Firestore & subscribe to real-time changes
        unsubscribeProfile = subscribeUserProfile(firebaseUser.uid, (profile) => {
          if (profile) {
            setCurrentUser(profile);
          }
        });

        // Ensure baseline profile exists if first-time sign in
        const existingProfile = await fetchUserProfile(firebaseUser.uid);
        if (existingProfile) {
          setCurrentUser(existingProfile);
        } else {
          const rawHandle =
            firebaseUser.displayName?.toLowerCase().replace(/[^a-z0-9]/g, '') ||
            firebaseUser.email?.split('@')[0] ||
            'creator';

          setCurrentUser({
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || 'ViralFlow Creator',
            displayName: firebaseUser.displayName || 'ViralFlow Creator',
            username: `@${rawHandle}`,
            email: firebaseUser.email || '',
            avatar: firebaseUser.photoURL || DEFAULT_AVATAR,
            photoURL: firebaseUser.photoURL || '',
            bio: 'Creating authentic stories on ViralFlow ✨',
            followersCount: '0',
            followingCount: 0,
            likesCount: '0',
            badge: 'Verified Creator',
            links: `viralflow.app/${rawHandle}`,
          });
        }
        setIsOnboarded(true);
      } else {
        // Guest user or logged out
        setCurrentUser(INITIAL_USER);
        setLikedVideoIds(new Set());
        setSavedVideoIds(new Set());
        setFollowedUserIds(new Set());
      }
      setAuthInitialized(true);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  // 2. Subscribe to Firestore `videos` collection
  useEffect(() => {
    const unsubscribeVideos = subscribeVideosCollection(
      (docs) => {
        setFirestoreVideos(docs);
      },
      (err) => {
        console.warn('Could not sync Firestore videos collection:', err);
      }
    );

    return () => unsubscribeVideos();
  }, []);

  // 3. Subscribe to current user's Likes, Saves, and Follows in Firestore
  useEffect(() => {
    if (!currentUser.uid) return;

    const unsubscribeUserDocs = subscribeUserData(currentUser.uid, {
      onLikesChange: (likes) => setLikedVideoIds(likes),
      onSavesChange: (saves) => setSavedVideoIds(saves),
      onFollowsChange: (follows) => setFollowedUserIds(follows),
    });

    return () => unsubscribeUserDocs();
  }, [currentUser.uid]);

  // 4. Subscribe to current user's unread notifications count in Firestore
  useEffect(() => {
    if (!currentUser.uid) {
      setUnreadNotificationsCount(0);
      return;
    }

    const unsubscribeNotifs = subscribeUserNotifications(
      currentUser.uid,
      (notifs) => {
        const unread = notifs.filter((n) => !n.isRead).length;
        setUnreadNotificationsCount(unread);
      },
      (err) => {
        console.warn('Notice listening to notifications in App:', err);
      }
    );

    return () => unsubscribeNotifs();
  }, [currentUser.uid]);

  // 5. Subscribe to current user's direct message conversations in Firestore
  useEffect(() => {
    if (!currentUser.uid) {
      setUnreadDirectMessagesCount(0);
      return;
    }

    const unsubscribeConvs = subscribeUserConversations(
      currentUser.uid,
      (threads) => {
        const totalUnread = threads.reduce((acc, t) => acc + (t.unreadCount || 0), 0);
        setUnreadDirectMessagesCount(totalUnread);
      },
      (err) => {
        console.warn('Notice listening to conversations in App:', err);
      }
    );

    return () => unsubscribeConvs();
  }, [currentUser.uid]);

  // Compute aggregated video items: real Firestore videos mapped + local posts + fallback demo data
  const videos: VideoItem[] = useMemo(() => {
    const convertedFirestoreVideos: VideoItem[] = firestoreVideos.map((doc) => {
      const isLiked = likedVideoIds.has(doc.videoId);
      const isSaved = savedVideoIds.has(doc.videoId);
      const isFollowing = followedUserIds.has(doc.ownerId);

      const splitMusic = doc.musicName.split('•');
      const musicTitle = splitMusic[0]?.trim() || doc.musicName;
      const musicArtist = splitMusic[1]?.trim() || 'Original Sound';

      const tagList = doc.hashtags
        ? doc.hashtags.split(/\s+/).filter(Boolean)
        : ['#ViralFlow'];

      return {
        id: doc.videoId,
        videoUrl: doc.videoUrl,
        posterUrl: doc.thumbnailUrl || doc.ownerPhoto,
        creator: {
          id: doc.ownerId,
          name: doc.ownerName,
          username: doc.ownerName.toLowerCase().replace(/[^a-z0-9]/g, ''),
          avatar:
            doc.ownerPhoto && !doc.ownerPhoto.includes('viralflow_logo') && !doc.ownerPhoto.includes('logo_transparent')
              ? doc.ownerPhoto
              : DEFAULT_AVATAR,
          isVerified: true,
          isFollowing,
          bio: 'ViralFlow Creator ✨',
        },
        caption: doc.caption,
        tags: tagList,
        music: {
          id: `m_${doc.videoId}`,
          title: musicTitle,
          artist: musicArtist,
          albumArt: doc.ownerPhoto,
        },
        likesCount: Math.max(0, doc.likesCount || 0),
        commentsCount: doc.commentsCount || 0,
        sharesCount: doc.sharesCount || 0,
        savesCount: isSaved ? 1 : 0,
        isLiked,
        isSaved,
        views: `${Math.max(1, (doc.likesCount || 0) * 12 + 15)}`,
        category: 'Trending',
        createdAt: doc.createdAt ? 'Recently' : 'Just now',
      };
    });

    // Merge demo videos with user interactions (source of truth is Firestore likedVideoIds)
    const mappedDemoVideos: VideoItem[] = MOCK_VIDEOS.map((demo) => {
      const isLiked = likedVideoIds.has(demo.id);
      const isSaved = savedVideoIds.has(demo.id);
      const isFollowing = followedUserIds.has(demo.creator.id) || demo.creator.isFollowing;

      return {
        ...demo,
        likesCount: demo.likesCount + (isLiked ? 1 : 0),
        isLiked,
        isSaved,
        creator: {
          ...demo.creator,
          isFollowing,
        },
      };
    });

    // Combine local newly created videos + Firestore videos + demo videos
    const all = [...localPostedVideos, ...convertedFirestoreVideos, ...mappedDemoVideos];

    // Deduplicate by ID
    const seen = new Set<string>();
    const deduplicated: VideoItem[] = [];
    for (const v of all) {
      if (!seen.has(v.id)) {
        seen.add(v.id);
        deduplicated.push(v);
      }
    }

    return deduplicated;
  }, [firestoreVideos, localPostedVideos, likedVideoIds, savedVideoIds, followedUserIds]);

  // Handle Like Toggle
  const handleLikeToggle = useCallback(
    async (id: string) => {
      const currentVideo = videos.find((v) => v.id === id);
      const currentlyLiked = currentVideo ? currentVideo.isLiked : false;
      const targetState = !currentlyLiked;

      // Optimistic set update
      setLikedVideoIds((prev) => {
        const next = new Set(prev);
        if (targetState) {
          next.add(id);
        } else {
          next.delete(id);
        }
        return next;
      });

      // Sync with Firestore
      if (currentUser.uid) {
        try {
          await toggleFirestoreLike(currentUser.uid, id, targetState);

          // If newly liking and creator is another user, trigger Firestore notification
          if (targetState && currentVideo?.creator?.id && currentVideo.creator.id !== currentUser.uid) {
            createFirestoreNotification({
              recipientId: currentVideo.creator.id,
              senderId: currentUser.uid,
              senderName: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
              senderUsername: currentUser.username,
              senderAvatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
              type: 'like',
              videoId: id,
              videoThumbnail: currentVideo.posterUrl || '',
              message: 'liked your video ❤️',
            });
          }
        } catch (err) {
          console.error('Error toggling like:', err);
          // Rollback optimistic state if Firestore sync fails
          setLikedVideoIds((prev) => {
            const next = new Set(prev);
            if (currentlyLiked) {
              next.add(id);
            } else {
              next.delete(id);
            }
            return next;
          });
        }
      }
    },
    [videos, currentUser]
  );

  // Handle Save Toggle
  const handleSaveToggle = useCallback(
    async (id: string) => {
      const currentVideo = videos.find((v) => v.id === id);
      const currentlySaved = currentVideo ? currentVideo.isSaved : false;

      // Optimistic set update
      setSavedVideoIds((prev) => {
        const next = new Set(prev);
        if (currentlySaved) {
          next.delete(id);
        } else {
          next.add(id);
          showToast('Saved to your collection! 📌');
        }
        return next;
      });

      // Sync with Firestore
      if (currentUser.uid) {
        await toggleFirestoreSave(currentUser.uid, id, currentlySaved);
      }
    },
    [videos, currentUser.uid, showToast]
  );

  // Handle Follow Toggle
  const handleFollowToggle = useCallback(
    async (creatorId: string) => {
      const isCurrentlyFollowing = followedUserIds.has(creatorId);

      setFollowedUserIds((prev) => {
        const next = new Set(prev);
        if (isCurrentlyFollowing) {
          next.delete(creatorId);
        } else {
          next.add(creatorId);
          showToast('Following creator! ✨');
        }
        return next;
      });

      // Sync with Firestore
      if (currentUser.uid) {
        await toggleFirestoreFollow(currentUser.uid, creatorId, isCurrentlyFollowing);

        // If newly following and target is another user, trigger Firestore notification
        if (!isCurrentlyFollowing && creatorId !== currentUser.uid) {
          createFirestoreNotification({
            recipientId: creatorId,
            senderId: currentUser.uid,
            senderName: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
            senderUsername: currentUser.username,
            senderAvatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
            type: 'follow',
            message: 'started following you ✨',
          });
        }
      }
    },
    [followedUserIds, currentUser, showToast]
  );

  // Post New Short Video -> Saves to Firestore `videos` collection
  const handlePostVideo = useCallback(
    async (newVideo: VideoItem, targetTab: TabType = 'home') => {
      // Optimistic UI update
      setLocalPostedVideos((prev) => {
        if (prev.some((v) => v.id === newVideo.id)) return prev;
        return [newVideo, ...prev];
      });
      setCurrentTab(targetTab);
      if (targetTab === 'home') {
        setActiveFeedTab('forYou');
      }
      showToast('Your video is now live on ViralFlow! 🎉');

      // Publish to Firestore if not already saved
      if (!firestoreVideos.some((v) => v.videoId === newVideo.id)) {
        try {
          await publishVideoToFirestore({
            videoId: newVideo.id,
            ownerId: currentUser.uid || 'guest_creator',
            ownerName: currentUser.name,
            ownerPhoto: currentUser.avatar,
            videoUrl: newVideo.videoUrl,
            thumbnailUrl: newVideo.posterUrl,
            caption: newVideo.caption,
            hashtags: newVideo.tags.join(' '),
            musicName: `${newVideo.music.title} • ${newVideo.music.artist}`,
          });
        } catch (err) {
          console.error('Error saving video to Firestore:', err);
        }
      }
    },
    [currentUser, firestoreVideos, showToast]
  );

  // Tag click navigation
  const handleSelectHashtag = useCallback((tag: string) => {
    setSelectedHashtag(tag);
    setCurrentTab('explore');
  }, []);

  // Sign Out Handler
  const handleSignOut = useCallback(async () => {
    try {
      await signOutUser();
      setIsOnboarded(false);
      setCurrentTab('home');
      setCurrentUser(INITIAL_USER);
      setLikedVideoIds(new Set());
      setSavedVideoIds(new Set());
      setFollowedUserIds(new Set());
      showToast('Signed out of ViralFlow. 👋');
    } catch (err) {
      console.error('Sign out error:', err);
    }
  }, [showToast]);

  // User's own posted videos
  const userVideos = useMemo(() => {
    return videos.filter(
      (v) =>
        v.creator.id === currentUser.uid ||
        v.creator.id === 'me' ||
        v.creator.username === currentUser.username.replace('@', '')
    );
  }, [videos, currentUser]);

  // User's bookmarked/saved videos
  const savedVideos = useMemo(() => {
    return videos.filter((v) => v.isSaved);
  }, [videos]);

  // User's liked videos
  const likedVideos = useMemo(() => {
    return videos.filter((v) => v.isLiked);
  }, [videos]);

  // Select video from notification
  const handleSelectNotificationVideo = useCallback(
    (videoId: string) => {
      const targetVideo = videos.find((v) => v.id === videoId);
      if (targetVideo) {
        const reordered = [targetVideo, ...videos.filter((item) => item.id !== videoId)];
        setLocalPostedVideos(reordered);
        setCurrentTab('home');
        setActiveFeedTab('forYou');
      } else {
        setCurrentTab('home');
      }
    },
    [videos]
  );

  if (!authInitialized) {
    return (
      <DeviceFrame>
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-white select-none">
          <div className="relative w-14 h-14 mb-3 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-4 border-white/10" />
            <div
              className="absolute inset-0 rounded-full border-4 border-t-pink-500 border-r-purple-500 border-b-sky-400 border-l-transparent animate-spin"
              style={{ animationDuration: '1s' }}
            />
          </div>
          <span className="text-xs font-black tracking-widest uppercase text-white/80">ViralFlow</span>
        </div>
      </DeviceFrame>
    );
  }

  return (
    <DeviceFrame>
      {/* Toast Notification Alert */}
      {toastMessage && (
        <div className="absolute top-12 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-slate-900/90 text-white text-xs font-bold shadow-2xl backdrop-blur-md border border-white/20 flex items-center gap-2 animate-bounce">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Screen Routing */}
      {!isOnboarded ? (
        /* Screen 1: Welcome / Onboarding connected to Firebase Auth */
        <WelcomeScreen
          onGetStarted={() => {
            setIsOnboarded(true);
            showToast('Welcome to ViralFlow! ✨ Enjoy the vibe.');
          }}
          onSignInSuccess={() => {
            setIsOnboarded(true);
            showToast(`Connected to ViralFlow! 💜`);
          }}
        />
      ) : (
        /* Authenticated Main App with 5 Tabs */
        <div className="relative w-full h-full flex flex-col bg-white overflow-hidden">
          {/* Active Screen View */}
          <div className="relative flex-1 w-full h-full overflow-hidden">
            {currentTab === 'home' && (
              /* Screen 2: Home / For You */
              <HomeScreen
                videos={videos}
                currentUser={currentUser}
                activeFeedTab={activeFeedTab}
                onFeedTabChange={setActiveFeedTab}
                onLikeToggle={handleLikeToggle}
                onSaveToggle={handleSaveToggle}
                onFollowToggle={handleFollowToggle}
                onNavigateTab={setCurrentTab}
                onSelectHashtag={handleSelectHashtag}
                onSelectCreator={setSelectedCreatorId}
                onCreateClick={() => setCurrentTab('create')}
                onMeetRealPeople={() => setCurrentTab('creators')}
                onExploreTheWorld={() => setCurrentTab('explore')}
                onShareFavorites={() => setCurrentTab('saved')}
              />
            )}

            {currentTab === 'explore' && (
              /* Screen 3: Explore */
              <ExploreScreen
                videos={videos}
                selectedHashtag={selectedHashtag}
                onSelectVideo={(v) => {
                  const videoIndex = videos.findIndex((item) => item.id === v.id);
                  if (videoIndex >= 0) {
                    const reordered = [v, ...videos.filter((item) => item.id !== v.id)];
                    setLocalPostedVideos(reordered);
                  }
                }}
                onSelectCreator={setSelectedCreatorId}
                onFollowToggle={handleFollowToggle}
                onCreateClick={() => setCurrentTab('create')}
                onMeetRealPeople={() => setCurrentTab('creators')}
                onExploreTheWorld={() => setCurrentTab('explore')}
                onShareFavorites={() => setCurrentTab('saved')}
                currentUser={currentUser}
                onLikeToggle={handleLikeToggle}
                onSaveToggle={handleSaveToggle}
              />
            )}

            {currentTab === 'creators' && (
              /* Screen 4: Meet Real People (Discover Creators) */
              <DiscoverCreatorsScreen
                currentUser={currentUser}
                followedUserIds={followedUserIds}
                onBack={() => setCurrentTab('explore')}
                onSelectCreator={setSelectedCreatorId}
                onFollowToggle={handleFollowToggle}
              />
            )}

            {currentTab === 'saved' && (
              /* Screen 5: Share Favorites (Saved Videos) */
              <SavedFavoritesScreen
                currentUser={currentUser}
                videos={videos}
                savedVideoIds={savedVideoIds}
                onBack={() => setCurrentTab('explore')}
                onNavigateExplore={() => setCurrentTab('explore')}
                onLikeToggle={handleLikeToggle}
                onSaveToggle={handleSaveToggle}
                onFollowToggle={handleFollowToggle}
                onSelectCreator={setSelectedCreatorId}
              />
            )}

            {currentTab === 'create' && (
              /* Screen 4: Create Studio */
              <CreateScreen
                currentUser={currentUser}
                onPostVideo={handlePostVideo}
                onClose={() => setCurrentTab('home')}
                onRequireAuth={() => setIsOnboarded(false)}
              />
            )}

            {currentTab === 'inbox' && (
              /* Screen 5: Inbox (Notifications & Direct Chats) */
              <InboxScreen
                currentUser={currentUser}
                onOpenCreator={setSelectedCreatorId}
                onSelectVideo={handleSelectNotificationVideo}
                onRequireAuth={() => setIsOnboarded(false)}
                onFollowToggle={handleFollowToggle}
                followedUserIds={followedUserIds}
              />
            )}

            {currentTab === 'profile' && (
              /* Screen 6: Profile (Connected to Firestore Users) */
              <ProfileScreen
                currentUser={currentUser}
                userVideos={userVideos}
                savedVideos={savedVideos}
                likedVideos={likedVideos}
                onUpdateProfile={(updated) => {
                  setCurrentUser(updated);
                  showToast('Profile updated successfully! ✨');
                }}
                onSelectVideo={(v) => {
                  const reordered = [v, ...videos.filter((item) => item.id !== v.id)];
                  setLocalPostedVideos(reordered);
                  setCurrentTab('home');
                }}
                onSignOut={handleSignOut}
              />
            )}
          </div>

          {/* Persistent Floating Liquid-Glass Bottom Navigation */}
          {currentTab !== 'create' && (
            <BottomNav
              currentTab={currentTab}
              onTabChange={setCurrentTab}
              unreadCount={unreadNotificationsCount + unreadDirectMessagesCount}
              userAvatar={currentUser.avatar}
              theme={currentTab === 'home' ? 'dark' : 'light'}
            />
          )}

          {/* Creator Profile Modal */}
          {selectedCreatorId && (
            <CreatorProfileModal
              creatorId={selectedCreatorId}
              onClose={() => setSelectedCreatorId(null)}
              videos={videos}
              onFollowToggle={handleFollowToggle}
              onSelectVideo={(v) => {
                const reordered = [v, ...videos.filter((item) => item.id !== v.id)];
                setLocalPostedVideos(reordered);
                setSelectedCreatorId(null);
                setCurrentTab('home');
              }}
            />
          )}
        </div>
      )}
    </DeviceFrame>
  );
}
