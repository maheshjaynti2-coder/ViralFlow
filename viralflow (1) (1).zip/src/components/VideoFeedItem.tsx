import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, Music, Volume2, VolumeX, Plus, Check, Play } from 'lucide-react';
import { VideoItem, DEFAULT_AVATAR } from '../types';
import { getVideoBlobUrl } from '../lib/mediaStorage';

interface VideoFeedItemProps {
  video: VideoItem;
  isActive: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
  onLikeToggle: (id: string) => void;
  onSaveToggle: (id: string) => void;
  onFollowToggle: (creatorId: string) => void;
  onOpenComments: (video: VideoItem) => void;
  onOpenShare: (video: VideoItem) => void;
  onCreatorClick: (creatorId: string) => void;
  onTagClick?: (tag: string) => void;
}

interface HeartParticle {
  id: number;
  x: number;
  y: number;
  rotate: number;
}

export const VideoFeedItem: React.FC<VideoFeedItemProps> = ({
  video,
  isActive,
  isMuted,
  onToggleMute,
  onLikeToggle,
  onSaveToggle,
  onFollowToggle,
  onOpenComments,
  onOpenShare,
  onCreatorClick,
  onTagClick,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const clickTimeoutRef = useRef<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [progress, setProgress] = useState(0);
  const [isCaptionExpanded, setIsCaptionExpanded] = useState(false);
  const [hearts, setHearts] = useState<HeartParticle[]>([]);

  // Synchronize playback with active state
  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    if (isActive) {
      // Reset or resume smoothly
      videoEl.muted = isMuted;
      const playPromise = videoEl.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => setIsPlaying(true))
          .catch(() => {
            // Autoplay policy fallback: mute and play
            videoEl.muted = true;
            videoEl.play().catch(() => setIsPlaying(false));
          });
      }
    } else {
      videoEl.pause();
      setIsPlaying(false);
    }
  }, [isActive, isMuted]);

  // Handle global mute state update on active video
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  const handleTimeUpdate = () => {
    if (videoRef.current && videoRef.current.duration) {
      const p = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(p || 0);
    }
  };

  // Click & Double Tap distinction
  const handleContainerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Ignore clicks on buttons, links, or controls
    if ((e.target as HTMLElement).closest('button, a, input')) return;

    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (clickTimeoutRef.current) {
      // Double tap detected!
      clearTimeout(clickTimeoutRef.current);
      clickTimeoutRef.current = null;
      triggerHeartAnimation(x, y);
      if (!video.isLiked) {
        onLikeToggle(video.id);
      }
    } else {
      // Wait to see if second click comes in within 280ms
      clickTimeoutRef.current = window.setTimeout(() => {
        clickTimeoutRef.current = null;
        togglePlayPause();
      }, 280);
    }
  };

  const togglePlayPause = () => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    if (isPlaying) {
      videoEl.pause();
      setIsPlaying(false);
    } else {
      videoEl.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const triggerHeartAnimation = (x: number, y: number) => {
    const newHeart: HeartParticle = {
      id: Date.now() + Math.random(),
      x,
      y,
      rotate: (Math.random() - 0.5) * 35,
    };
    setHearts((prev) => [...prev, newHeart]);

    setTimeout(() => {
      setHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 950);
  };

  const formatCount = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div
      className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden select-none cursor-pointer"
      onClick={handleContainerClick}
    >
      {/* 9:16 Full Screen Video */}
      <video
        ref={videoRef}
        src={video.videoUrl}
        poster={
          video.posterUrl && !video.posterUrl.includes('=s96-c') && video.posterUrl !== video.creator.avatar
            ? video.posterUrl
            : undefined
        }
        playsInline
        loop
        muted={isMuted}
        preload="auto"
        onTimeUpdate={handleTimeUpdate}
        onError={async (e) => {
          const v = e.currentTarget;
          if (video.id) {
            try {
              const localBlobUrl = await getVideoBlobUrl(video.id);
              if (localBlobUrl && localBlobUrl !== v.src) {
                v.src = localBlobUrl;
                v.play().catch(() => {});
                return;
              }
            } catch {}
          }
          const fallback = 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/docs/walking_talking.mp4';
          if (v.src !== fallback) {
            v.src = fallback;
            v.play().catch(() => {});
          }
        }}
        className="w-full h-full object-cover pointer-events-none"
      />

      {/* Center Paused Indicator */}
      {!isPlaying && (
        <div className="absolute z-20 pointer-events-none w-18 h-18 rounded-full bg-slate-950/60 backdrop-blur-xl border border-white/25 flex items-center justify-center text-white shadow-[0_8px_32px_rgba(0,0,0,0.5)] transition-transform duration-200 scale-100">
          <Play className="w-8 h-8 fill-white text-white ml-1" />
        </div>
      )}

      {/* Floating Double-Tap Heart Bursts */}
      {hearts.map((h) => (
        <div
          key={h.id}
          className="absolute z-30 pointer-events-none animate-heart-burst"
          style={{
            left: `${h.x}px`,
            top: `${h.y}px`,
            transform: `translate(-50%, -50%) rotate(${h.rotate}deg)`,
          }}
        >
          <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-pink-500 via-purple-500 to-rose-400 p-[3px] shadow-[0_0_35px_rgba(236,72,153,0.85)]">
            <div className="w-full h-full rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Heart className="w-14 h-14 fill-white text-white drop-shadow-md" />
            </div>
          </div>
        </div>
      ))}

      {/* Top Gradient for readability */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-black/80 via-black/35 to-transparent pointer-events-none z-10" />

      {/* Bottom Gradient for caption and action readability */}
      <div className="absolute bottom-0 left-0 right-0 h-72 bg-gradient-to-t from-black/90 via-black/50 to-transparent pointer-events-none z-10" />

      {/* Floating Mute/Unmute Control (Top Right) */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onToggleMute();
        }}
        className="absolute top-18 right-3.5 z-20 px-2.5 py-1.5 rounded-full bg-black/40 backdrop-blur-xl border border-white/20 text-white flex items-center gap-1.5 shadow-lg hover:bg-black/60 active:scale-95 transition-all text-xs font-medium"
        aria-label={isMuted ? 'Unmute video' : 'Mute video'}
      >
        {isMuted ? (
          <>
            <VolumeX className="w-4 h-4 text-pink-400" />
            <span className="text-[10px] tracking-wide text-white/90">Muted</span>
          </>
        ) : (
          <>
            <Volume2 className="w-4 h-4 text-sky-400" />
            <span className="text-[10px] tracking-wide text-white/90">Sound on</span>
          </>
        )}
      </button>

      {/* Right-Side Action Column */}
      <div className="absolute right-2.5 bottom-20 z-20 flex flex-col items-center gap-3.5 text-white pointer-events-auto">
        {/* Creator Avatar with Follow Button */}
        <div className="relative mb-0.5">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onCreatorClick(video.creator.id);
            }}
            className="w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-sky-400 via-purple-500 to-pink-500 shadow-xl block hover:scale-105 transition-transform"
            aria-label={`View ${video.creator.name}'s profile`}
          >
            <img
              src={video.creator.avatar || DEFAULT_AVATAR}
              alt={video.creator.name}
              onError={(e) => {
                (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
              }}
              className="w-full h-full rounded-full object-cover bg-slate-800"
            />
          </button>

          {/* Avatar Follow Badge */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onFollowToggle(video.creator.id);
            }}
            className={`absolute -bottom-1 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full flex items-center justify-center shadow-lg transition-all active:scale-125 ${
              video.creator.isFollowing
                ? 'bg-emerald-500 text-white ring-2 ring-white/90'
                : 'bg-gradient-to-r from-pink-500 to-purple-600 text-white ring-2 ring-white hover:scale-110'
            }`}
            aria-label={video.creator.isFollowing ? 'Following' : 'Follow creator'}
          >
            {video.creator.isFollowing ? (
              <Check className="w-3 h-3" strokeWidth={3.5} />
            ) : (
              <Plus className="w-3.5 h-3.5" strokeWidth={3.5} />
            )}
          </button>
        </div>

        {/* Like Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onLikeToggle(video.id);
          }}
          className="flex flex-col items-center group active:scale-90 transition-transform"
          aria-label="Like video"
        >
          <div
            className={`w-11 h-11 rounded-full backdrop-blur-xl border flex items-center justify-center transition-all shadow-lg ${
              video.isLiked
                ? 'bg-pink-500/25 border-pink-500/60 shadow-[0_0_18px_rgba(236,72,153,0.5)]'
                : 'bg-black/35 border-white/15 hover:bg-black/50'
            }`}
          >
            <Heart
              className={`w-6 h-6 transition-all duration-300 ${
                video.isLiked
                  ? 'fill-pink-500 text-pink-500 scale-110 drop-shadow-[0_0_10px_rgba(236,72,153,0.8)]'
                  : 'text-white group-hover:text-pink-300'
              }`}
            />
          </div>
          <span className="text-[11px] font-bold mt-1 text-white drop-shadow-md">
            {formatCount(video.likesCount)}
          </span>
        </button>

        {/* Comment Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenComments(video);
          }}
          className="flex flex-col items-center group active:scale-90 transition-transform"
          aria-label="Open comments"
        >
          <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-xl border border-white/15 flex items-center justify-center hover:bg-black/50 transition-all shadow-lg">
            <MessageCircle className="w-6 h-6 text-white group-hover:text-sky-300 transition-colors" />
          </div>
          <span className="text-[11px] font-bold mt-1 text-white drop-shadow-md">
            {formatCount(video.commentsCount)}
          </span>
        </button>

        {/* Save / Bookmark Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSaveToggle(video.id);
          }}
          className="flex flex-col items-center group active:scale-90 transition-transform"
          aria-label="Save video"
        >
          <div
            className={`w-11 h-11 rounded-full backdrop-blur-xl border flex items-center justify-center transition-all shadow-lg ${
              video.isSaved
                ? 'bg-amber-500/25 border-amber-400/60 shadow-[0_0_18px_rgba(251,191,36,0.5)]'
                : 'bg-black/35 border-white/15 hover:bg-black/50'
            }`}
          >
            <Bookmark
              className={`w-6 h-6 transition-all duration-300 ${
                video.isSaved
                  ? 'fill-amber-400 text-amber-400 scale-110 drop-shadow-[0_0_10px_rgba(251,191,36,0.8)]'
                  : 'text-white group-hover:text-amber-300'
              }`}
            />
          </div>
          <span className="text-[11px] font-bold mt-1 text-white drop-shadow-md">
            {formatCount(video.savesCount)}
          </span>
        </button>

        {/* Share Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onOpenShare(video);
          }}
          className="flex flex-col items-center group active:scale-90 transition-transform"
          aria-label="Share video"
        >
          <div className="w-11 h-11 rounded-full bg-black/35 backdrop-blur-xl border border-white/15 flex items-center justify-center hover:bg-black/50 transition-all shadow-lg">
            <Share2 className="w-6 h-6 text-white group-hover:text-pink-300 transition-colors" />
          </div>
          <span className="text-[11px] font-bold mt-1 text-white drop-shadow-md">
            {formatCount(video.sharesCount)}
          </span>
        </button>

        {/* Rotating Music Vinyl Disc */}
        <div className="relative mt-1">
          <div
            className={`w-10 h-10 rounded-full bg-slate-900 border-2 border-slate-700/80 p-0.5 shadow-xl ${
              isPlaying ? 'animate-spin-slow' : ''
            }`}
          >
            <img
              src={video.music.albumArt}
              alt="Album Art"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
          {/* Floating musical note when playing */}
          {isPlaying && (
            <span className="absolute -top-2 -left-1.5 text-pink-400 text-xs animate-bounce opacity-90 pointer-events-none select-none">
              ♫
            </span>
          )}
        </div>
      </div>

      {/* Bottom Creator Info & Caption Column */}
      <div className="absolute bottom-18 left-3.5 right-18 z-20 text-white flex flex-col gap-2 pb-1 pointer-events-auto">
        {/* Creator Username, Verified Badge & Follow Button */}
        <div className="flex items-center gap-2 flex-wrap">
          <div
            onClick={(e) => {
              e.stopPropagation();
              onCreatorClick(video.creator.id);
            }}
            className="flex items-center gap-1.5 cursor-pointer group"
          >
            <span className="font-extrabold text-sm tracking-wide text-white group-hover:text-sky-300 drop-shadow-md transition-colors">
              @{video.creator.username}
            </span>
            {video.creator.isVerified && (
              <span className="w-4 h-4 rounded-full bg-gradient-to-r from-sky-400 to-blue-500 text-white text-[10px] flex items-center justify-center font-bold shadow-sm">
                ✓
              </span>
            )}
          </div>

          {/* Inline Follow Pill */}
          {!video.creator.isFollowing ? (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onFollowToggle(video.creator.id);
              }}
              className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/20 hover:bg-white/30 backdrop-blur-md border border-white/40 text-white transition-all active:scale-95 shadow-sm"
            >
              Follow
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onFollowToggle(video.creator.id);
              }}
              className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 transition-all"
            >
              Following
            </button>
          )}
        </div>

        {/* Caption with Hashtags */}
        <div className="text-xs text-white/95 leading-relaxed drop-shadow-md">
          <p className={isCaptionExpanded ? '' : 'line-clamp-2'}>
            {video.caption.split(' ').map((word, i) => {
              if (word.startsWith('#')) {
                return (
                  <button
                    key={i}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (onTagClick) onTagClick(word);
                    }}
                    className="font-bold text-sky-300 hover:text-sky-200 mr-1 inline-block"
                  >
                    {word}
                  </button>
                );
              }
              return word + ' ';
            })}
          </p>
          {video.caption.length > 90 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsCaptionExpanded((prev) => !prev);
              }}
              className="text-white/70 hover:text-white text-[11px] font-semibold ml-1 underline cursor-pointer"
            >
              {isCaptionExpanded ? 'less' : 'more'}
            </button>
          )}
        </div>

        {/* Audio / Music Row */}
        <div className="flex items-center gap-2 mt-0.5 max-w-[90%]">
          <div className="w-4 h-4 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0">
            <Music className="w-2.5 h-2.5 text-white" />
          </div>
          <div className="overflow-hidden whitespace-nowrap text-[11px] text-white/85 font-medium drop-shadow-sm flex items-center gap-2">
            <span>{video.music.title}</span>
            <span className="text-white/50">•</span>
            <span className="text-white/70">{video.music.artist}</span>
          </div>
        </div>
      </div>

      {/* Video Progress Bar */}
      <div className="absolute bottom-16 left-0 right-0 h-[2px] bg-white/20 z-20">
        <div
          className="h-full bg-gradient-to-r from-sky-400 via-purple-500 to-pink-500 transition-all duration-150"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};
