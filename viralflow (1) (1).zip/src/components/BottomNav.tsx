import React from 'react';
import { Home, Compass, MessageSquare, User, Plus } from 'lucide-react';
import { TabType, DEFAULT_AVATAR } from '../types';

interface BottomNavProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  unreadCount?: number;
  userAvatar?: string;
  theme?: 'dark' | 'light';
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  unreadCount = 0,
  userAvatar,
  theme = 'light',
}) => {
  // If we are on Home tab watching full-screen video, we can render with high-contrast glass
  const isVideoHome = currentTab === 'home';

  return (
    <nav
      className={`absolute bottom-0 left-0 right-0 z-40 max-w-md mx-auto transition-all duration-300 pb-safe ${
        isVideoHome
          ? 'bg-slate-950/80 backdrop-blur-2xl border-t border-white/10 text-white shadow-2xl'
          : 'bg-white/85 backdrop-blur-2xl border-t border-white/80 text-slate-700 shadow-[0_-8px_32px_rgba(112,144,176,0.15)]'
      }`}
      style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 8px)' }}
    >
      <div className="flex items-center justify-around px-2 py-2">
        {/* Home */}
        <button
          onClick={() => onTabChange('home')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
            currentTab === 'home'
              ? isVideoHome ? 'text-white font-bold scale-105' : 'text-purple-600 font-bold scale-105'
              : isVideoHome ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
          }`}
          aria-label="Home"
        >
          <div className="relative p-1">
            <Home className="w-5 h-5" strokeWidth={currentTab === 'home' ? 2.5 : 2} />
            {currentTab === 'home' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </div>
          <span className="text-[10px] tracking-wide mt-0.5">Home</span>
        </button>

        {/* Explore */}
        <button
          onClick={() => onTabChange('explore')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
            currentTab === 'explore' || currentTab === 'creators' || currentTab === 'saved'
              ? isVideoHome ? 'text-white font-bold scale-105' : 'text-purple-600 font-bold scale-105'
              : isVideoHome ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
          }`}
          aria-label="Explore"
        >
          <div className="relative p-1">
            <Compass className="w-5 h-5" strokeWidth={currentTab === 'explore' || currentTab === 'creators' || currentTab === 'saved' ? 2.5 : 2} />
            {(currentTab === 'explore' || currentTab === 'creators' || currentTab === 'saved') && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </div>
          <span className="text-[10px] tracking-wide mt-0.5">Explore</span>
        </button>

        {/* + Create (Centerpiece glowing liquid glass button) */}
        <div className="flex-1 flex justify-center py-0.5">
          <button
            onClick={() => onTabChange('create')}
            className="group relative flex items-center justify-center -mt-3.5 w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-400 via-purple-600 to-pink-500 p-[2px] shadow-[0_8px_20px_-3px_rgba(168,85,247,0.5)] active:scale-95 transition-transform duration-200"
            aria-label="Create Video"
          >
            <div className="w-full h-full rounded-[14px] bg-gradient-to-tr from-white/90 via-white/70 to-white/90 backdrop-blur-md flex items-center justify-center border border-white/60 group-hover:bg-white transition-colors">
              <Plus className="w-6 h-6 text-purple-700 font-black drop-shadow-sm transition-transform group-hover:rotate-90 duration-300" strokeWidth={3} />
            </div>
            {/* Iridescent shimmer border highlight */}
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 border-2 border-white shadow-sm animate-pulse" />
          </button>
        </div>

        {/* Inbox */}
        <button
          onClick={() => onTabChange('inbox')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
            currentTab === 'inbox'
              ? isVideoHome ? 'text-white font-bold scale-105' : 'text-purple-600 font-bold scale-105'
              : isVideoHome ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
          }`}
          aria-label="Inbox"
        >
          <div className="relative p-1">
            <MessageSquare className="w-5 h-5" strokeWidth={currentTab === 'inbox' ? 2.5 : 2} />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-1 min-w-[15px] h-[15px] px-1 bg-gradient-to-r from-pink-500 to-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-sm">
                {unreadCount}
              </span>
            )}
            {currentTab === 'inbox' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </div>
          <span className="text-[10px] tracking-wide mt-0.5">Inbox</span>
        </button>

        {/* Profile */}
        <button
          onClick={() => onTabChange('profile')}
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
            currentTab === 'profile'
              ? isVideoHome ? 'text-white font-bold scale-105' : 'text-purple-600 font-bold scale-105'
              : isVideoHome ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
          }`}
          aria-label="Profile"
        >
          <div className="relative p-1">
            {userAvatar ? (
              <div className={`w-5 h-5 rounded-full overflow-hidden p-[1px] ${currentTab === 'profile' ? 'bg-gradient-to-tr from-sky-400 to-pink-500' : 'bg-transparent'}`}>
                <img
                  src={userAvatar || DEFAULT_AVATAR}
                  alt="Profile"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                  }}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
            ) : (
              <User className="w-5 h-5" strokeWidth={currentTab === 'profile' ? 2.5 : 2} />
            )}
            {currentTab === 'profile' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-sky-400 to-pink-500" />
            )}
          </div>
          <span className="text-[10px] tracking-wide mt-0.5">Profile</span>
        </button>
      </div>
    </nav>
  );
};
