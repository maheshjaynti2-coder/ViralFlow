import React, { useState, useEffect, useMemo } from 'react';
import { X, Search, MessageSquare, Loader2, Sparkles } from 'lucide-react';
import { UserProfile, DEFAULT_AVATAR } from '../../types';
import { FirestoreUserDoc } from '../../types';
import { subscribeShareableFriends } from '../../lib/firebase';

interface NewChatModalProps {
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (user: {
    id: string;
    name: string;
    username: string;
    avatar: string;
  }) => void;
}

export const NewChatModal: React.FC<NewChatModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  onSelectUser,
}) => {
  const [users, setUsers] = useState<FirestoreUserDoc[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Subscribe to real users/creators from Firestore
  useEffect(() => {
    if (!isOpen) return;

    setIsLoading(true);
    const unsubscribe = subscribeShareableFriends(
      currentUser.uid || 'guest',
      (fetchedUsers) => {
        // Exclude current user from candidate chat recipients
        const eligible = fetchedUsers.filter((u) => u.uid !== currentUser.uid);
        setUsers(eligible);
        setIsLoading(false);
      },
      (err) => {
        console.warn('Error loading users for new chat:', err);
        setIsLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [isOpen, currentUser.uid]);

  // Filter users according to search query
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return users;
    const query = searchQuery.toLowerCase().trim();
    return users.filter(
      (u) =>
        u.displayName?.toLowerCase().includes(query) ||
        u.username?.toLowerCase().includes(query) ||
        u.bio?.toLowerCase().includes(query)
    );
  }, [users, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-white/95 backdrop-blur-2xl rounded-t-3xl sm:rounded-3xl border border-white/80 shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-slideUp">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-pink-500 text-white flex items-center justify-center shadow-xs">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm text-slate-900 tracking-tight">New Message</h3>
              <p className="text-[11px] text-slate-500">Select a creator or friend to start chatting</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-900 active:scale-95 transition-all"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-3 border-b border-slate-100 bg-slate-50/50">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search creators by name or @username..."
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-white border border-slate-200/80 focus:outline-hidden focus:ring-2 focus:ring-purple-400 text-slate-800 placeholder-slate-400 shadow-2xs"
              autoFocus
            />
          </div>
        </div>

        {/* User Selection List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5 no-scrollbar min-h-[220px]">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
              <span className="text-xs font-medium">Finding creators...</span>
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="py-12 text-center text-slate-400 px-4">
              <Sparkles className="w-8 h-8 mx-auto text-purple-300 mb-2" />
              <p className="text-xs font-bold text-slate-700">No creators found</p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {searchQuery ? `No users match "${searchQuery}"` : 'No registered creators found.'}
              </p>
            </div>
          ) : (
            filteredUsers.map((user) => (
              <button
                key={user.uid}
                onClick={() => {
                  onSelectUser({
                    id: user.uid,
                    name: user.displayName || 'ViralFlow Creator',
                    username: user.username || `@user_${user.uid.slice(0, 5)}`,
                    avatar: user.photoURL || DEFAULT_AVATAR,
                  });
                  onClose();
                }}
                className="w-full p-2.5 rounded-2xl flex items-center gap-3 hover:bg-purple-50/80 active:scale-98 transition-all text-left group border border-transparent hover:border-purple-200/60"
              >
                <img
                  src={user.photoURL || DEFAULT_AVATAR}
                  alt={user.displayName || 'User'}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                  }}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-purple-200/70 bg-slate-100 shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-900 truncate group-hover:text-purple-700 transition-colors">
                      {user.displayName || 'ViralFlow Creator'}
                    </span>
                    {user.isFollowing && (
                      <span className="text-[9px] font-bold text-purple-600 px-2 py-0.5 rounded-full bg-purple-100/80">
                        Following
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 truncate block mt-0.5">
                    {user.username
                      ? user.username.startsWith('@')
                        ? user.username
                        : `@${user.username}`
                      : `@user_${user.uid.slice(0, 5)}`}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
