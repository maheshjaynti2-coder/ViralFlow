import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Send,
  Check,
  CheckCheck,
  Play,
  AlertCircle,
  Loader2,
  ExternalLink,
} from 'lucide-react';
import { ChatMessage, UserProfile, DEFAULT_AVATAR } from '../../types';
import {
  subscribeConversationMessages,
  sendFirestoreDirectMessage,
  markConversationAsRead,
} from '../../lib/firebase';

interface DirectChatViewProps {
  conversationId: string;
  recipientUser: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    isOnline?: boolean;
  };
  currentUser: UserProfile;
  onBack: () => void;
  onOpenCreator: (creatorId: string) => void;
  onSelectVideo?: (videoId: string, commentId?: string) => void;
}

export const DirectChatView: React.FC<DirectChatViewProps> = ({
  conversationId,
  recipientUser,
  currentUser,
  onBack,
  onOpenCreator,
  onSelectVideo,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [input, setInput] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [sendError, setSendError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 1. Subscribe to conversation messages and mark read in Firestore
  useEffect(() => {
    if (!conversationId || !currentUser.uid) {
      setMessages([]);
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    // Mark as read immediately in Firestore
    markConversationAsRead(conversationId, currentUser.uid).catch((err) => {
      console.warn('Notice marking conversation as read:', err);
    });

    const unsubscribe = subscribeConversationMessages(
      conversationId,
      currentUser.uid,
      (realtimeMessages) => {
        setMessages(realtimeMessages);
        setIsLoading(false);
        setError(null);
      },
      (err) => {
        console.warn('Error subscribing to conversation messages:', err);
        setError('Unable to load chat messages. Please check your connection.');
        setIsLoading(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [conversationId, currentUser.uid]);

  // 2. Smooth auto-scroll to the newest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 3. Send message handler (Strictly Firestore, no fake bot reply)
  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const textToSend = input.trim();
    if (!textToSend || isSending) return;

    if (!currentUser.uid) {
      setSendError('Please sign in to send messages.');
      return;
    }

    setIsSending(true);
    setSendError(null);

    try {
      await sendFirestoreDirectMessage({
        sender: currentUser,
        recipient: {
          id: recipientUser.id,
          name: recipientUser.name,
          username: recipientUser.username,
          avatar: recipientUser.avatar,
        },
        text: textToSend,
      });

      setInput('');
      // Keep input focused for quick successive messaging
      inputRef.current?.focus();
    } catch (err) {
      console.error('Failed to send direct message:', err);
      setSendError(
        err instanceof Error ? err.message : 'Failed to send message. Please try again.'
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white/95 backdrop-blur-xl">
      {/* Chat Header */}
      <div className="px-3.5 py-3 border-b border-slate-200/80 flex items-center justify-between bg-white/80 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="w-8 h-8 rounded-full bg-slate-100/90 flex items-center justify-center text-slate-700 hover:text-slate-950 hover:bg-slate-200 active:scale-95 transition-all shrink-0 shadow-2xs"
            aria-label="Back to conversations"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <button
            onClick={() => onOpenCreator(recipientUser.id)}
            className="flex items-center gap-2.5 min-w-0 group text-left"
            title="View creator profile"
          >
            <div className="relative shrink-0">
              <img
                src={recipientUser.avatar || DEFAULT_AVATAR}
                alt={recipientUser.name}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                }}
                className="w-9 h-9 rounded-full object-cover ring-2 ring-purple-300/80 bg-slate-100"
              />
              {recipientUser.isOnline && (
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
              )}
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="font-extrabold text-xs text-slate-900 leading-tight truncate group-hover:text-purple-600 transition-colors">
                  {recipientUser.name}
                </h4>
                <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-purple-500 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <span className="text-[10px] text-slate-400 truncate block">
                {recipientUser.username.startsWith('@')
                  ? recipientUser.username
                  : `@${recipientUser.username}`}
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Error notification banner */}
      {error && (
        <div className="p-3 bg-rose-50 border-b border-rose-200/80 flex items-center gap-2 text-rose-700 text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span className="flex-1">{error}</span>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
        {isLoading ? (
          /* Loading Skeleton */
          <div className="space-y-4 py-4 animate-pulse">
            <div className="flex justify-start">
              <div className="w-48 h-10 bg-slate-200/80 rounded-2xl rounded-bl-xs" />
            </div>
            <div className="flex justify-end">
              <div className="w-56 h-12 bg-purple-100 rounded-2xl rounded-br-xs" />
            </div>
            <div className="flex justify-start">
              <div className="w-40 h-8 bg-slate-200/80 rounded-2xl rounded-bl-xs" />
            </div>
          </div>
        ) : messages.length === 0 ? (
          /* Empty Chat / Conversation Starter */
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
            <div className="relative">
              <img
                src={recipientUser.avatar || DEFAULT_AVATAR}
                alt={recipientUser.name}
                className="w-16 h-16 rounded-full object-cover ring-4 ring-purple-100 bg-slate-100 shadow-sm"
              />
              <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-emerald-500 ring-2 ring-white" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-slate-800">
                Say hello to {recipientUser.name}! 👋
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-[240px]">
                Send a message to start sharing thoughts, videos, and inspiration on ViralFlow.
              </p>
            </div>
          </div>
        ) : (
          /* Render Chronological Messages */
          messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-xs ${
                  msg.isMe
                    ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-br-xs'
                    : 'bg-slate-100/90 text-slate-800 rounded-bl-xs border border-slate-200/70'
                }`}
              >
                {/* Optional Shared Video Attachment */}
                {msg.sharedVideo && (
                  <button
                    type="button"
                    onClick={() => onSelectVideo && onSelectVideo(msg.sharedVideo!.id)}
                    className="mb-2 w-full text-left rounded-xl overflow-hidden border border-white/20 bg-black/10 group active:scale-98 transition-all block"
                  >
                    <div className="relative h-28 w-full bg-slate-900">
                      <img
                        src={msg.sharedVideo.posterUrl}
                        alt="Shared Short"
                        className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <div className="w-8 h-8 rounded-full bg-white/90 text-purple-600 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                          <Play className="w-4 h-4 fill-purple-600 ml-0.5" />
                        </div>
                      </div>
                      <span className="absolute bottom-1.5 left-1.5 px-2 py-0.5 rounded-md bg-black/60 text-white text-[9px] font-bold">
                        Short
                      </span>
                    </div>
                    {msg.sharedVideo.caption && (
                      <p className="p-2 text-[11px] font-medium line-clamp-2 text-white/95">
                        {msg.sharedVideo.caption}
                      </p>
                    )}
                  </button>
                )}

                {/* Message Text */}
                {msg.text && <p className="whitespace-pre-wrap break-words">{msg.text}</p>}

                {/* Timestamp & Read Status */}
                <div
                  className={`flex items-center justify-end gap-1 mt-1 text-[9px] font-medium ${
                    msg.isMe ? 'text-white/80' : 'text-slate-400'
                  }`}
                >
                  <span>{msg.timestamp}</span>
                  {msg.isMe && (
                    <span title={msg.isRead ? 'Read' : 'Delivered'}>
                      {msg.isRead ? (
                        <CheckCheck className="w-3 h-3 text-sky-200" />
                      ) : (
                        <Check className="w-3 h-3 text-white/70" />
                      )}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Send Error Notice */}
      {sendError && (
        <div className="px-4 py-1.5 bg-rose-100 text-rose-700 text-[11px] flex items-center justify-between border-t border-rose-200">
          <span>{sendError}</span>
          <button
            onClick={() => setSendError(null)}
            className="text-[10px] font-bold underline ml-2"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Message Input Footer */}
      <form
        onSubmit={handleSend}
        className="p-3 bg-white/90 border-t border-slate-200/80 flex items-center gap-2"
      >
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Message ${recipientUser.name}...`}
          disabled={isSending}
          className="flex-1 px-4 py-2.5 rounded-full bg-slate-100/90 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-purple-400 border border-slate-200/70 disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={!input.trim() || isSending}
          className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-pink-500 text-white flex items-center justify-center disabled:opacity-40 disabled:scale-100 active:scale-95 transition-all shadow-xs shrink-0"
          aria-label="Send message"
        >
          {isSending ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4 ml-0.5" />
          )}
        </button>
      </form>
    </div>
  );
};
