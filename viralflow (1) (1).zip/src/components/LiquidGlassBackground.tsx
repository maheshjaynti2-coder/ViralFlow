import React from 'react';

interface LiquidGlassBackgroundProps {
  intensity?: 'subtle' | 'vibrant' | 'onboarding';
  children?: React.ReactNode;
  className?: string;
}

export const LiquidGlassBackground: React.FC<LiquidGlassBackgroundProps> = ({
  intensity = 'subtle',
  children,
  className = '',
}) => {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      {/* Base Pearl White/Silk Canvas */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-white to-blue-50/40 pointer-events-none" />

      {/* Iridescent Glowing Liquid Orbs */}
      {intensity === 'onboarding' ? (
        <>
          {/* Top Blue-Cyan Liquid Swirl */}
          <div className="absolute -top-24 -left-20 w-80 h-80 rounded-full bg-gradient-to-tr from-sky-400/35 via-indigo-500/25 to-transparent blur-3xl pointer-events-none animate-iridescent" />
          
          {/* Right Purple-Pink Liquid Wave */}
          <div className="absolute top-1/4 -right-24 w-96 h-96 rounded-full bg-gradient-to-bl from-pink-400/30 via-purple-500/30 to-amber-300/20 blur-3xl pointer-events-none animate-iridescent" style={{ animationDelay: '-3s' }} />

          {/* Bottom Gold & Magenta Ripple */}
          <div className="absolute -bottom-28 -left-16 w-88 h-88 rounded-full bg-gradient-to-tr from-amber-400/25 via-rose-400/30 to-purple-600/25 blur-3xl pointer-events-none animate-iridescent" style={{ animationDelay: '-5s' }} />

          {/* Liquid Glass Wave Svg Overlay */}
          <svg className="absolute inset-0 w-full h-full opacity-35 pointer-events-none" preserveAspectRatio="none" viewBox="0 0 100 100">
            <defs>
              <linearGradient id="waveGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.4" />
                <stop offset="50%" stopColor="#A855F7" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#EC4899" stopOpacity="0.4" />
              </linearGradient>
            </defs>
            <path d="M0 20 C 30 35, 60 5, 100 25 L 100 0 L 0 0 Z" fill="url(#waveGrad)" />
            <path d="M0 80 C 40 65, 70 95, 100 75 L 100 100 L 0 100 Z" fill="url(#waveGrad)" />
          </svg>
        </>
      ) : (
        <>
          {/* Subtle Ambient Liquid Glow for in-app screens */}
          <div className="absolute -top-32 -left-24 w-72 h-72 rounded-full bg-gradient-to-br from-sky-300/20 via-indigo-300/15 to-transparent blur-2xl pointer-events-none" />
          <div className="absolute top-1/3 -right-24 w-80 h-80 rounded-full bg-gradient-to-l from-purple-300/20 via-pink-300/15 to-transparent blur-2xl pointer-events-none" />
          <div className="absolute -bottom-32 left-1/4 w-80 h-80 rounded-full bg-gradient-to-t from-amber-200/15 via-pink-300/15 to-transparent blur-2xl pointer-events-none" />
        </>
      )}

      {/* Content Container */}
      <div className="relative z-10 w-full h-full">
        {children}
      </div>
    </div>
  );
};
