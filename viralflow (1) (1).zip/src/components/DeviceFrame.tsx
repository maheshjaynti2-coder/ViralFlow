import React, { useState } from 'react';
import { Smartphone, Monitor, Wifi, Battery, Sparkles } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children }) => {
  const [isDesktopExpanded, setIsDesktopExpanded] = useState(false);

  return (
    <div className="relative min-h-screen w-full bg-slate-100 flex flex-col items-center justify-center sm:p-4 overflow-x-hidden font-sans">
      {/* Iridescent Ambient Background for Desktop */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Iridescent Top Left Aura */}
        <div className="absolute -top-32 -left-32 w-[550px] h-[550px] rounded-full bg-gradient-to-tr from-sky-300/30 via-purple-300/25 to-pink-300/20 blur-3xl" />
        {/* Iridescent Bottom Right Aura */}
        <div className="absolute -bottom-32 -right-32 w-[600px] h-[600px] rounded-full bg-gradient-to-bl from-pink-300/25 via-purple-400/25 to-amber-200/20 blur-3xl" />

        {/* Ambient brand info on wide screens */}
        <div className="hidden lg:flex fixed left-10 top-1/2 -translate-y-1/2 flex-col items-start gap-3 opacity-90 max-w-xs">
          <span className="text-2xl font-black tracking-tight text-slate-800">
            Viral<span className="bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">Flow</span>
          </span>
          <p className="font-script text-2xl text-purple-700 rotate-[-4deg] mt-1">
            Good Vibes. Better People ♡
          </p>
          <div className="p-4 rounded-3xl liquid-glass-card mt-2 text-xs text-slate-600 leading-relaxed">
            <span className="font-bold text-slate-800 block mb-1">Independent Short-Video Platform</span>
            Crafted with pearl liquid-glass aesthetics, high-definition vertical feeds, and community kindness.
          </div>
        </div>


        {/* Right side slogan on wide screens */}
        <div className="hidden lg:flex fixed right-10 top-1/2 -translate-y-1/2 flex-col items-end gap-3 opacity-90 max-w-xs text-right">
          <span className="font-script text-2xl text-pink-600 rotate-[4deg]">
            Small Moments. Big Stories ♡
          </span>
          <div className="p-4 rounded-3xl liquid-glass-card mt-2 text-xs text-slate-600 leading-relaxed text-left">
            <div className="flex items-center gap-1.5 font-bold text-slate-800 mb-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
              <span>Create • Watch • Share • Be You</span>
            </div>
            Experience real creator connections in an iridescent, uplifting atmosphere.
          </div>
        </div>
      </div>

      {/* Device Viewport Switcher Toolbar (Desktop only) */}
      <div className="hidden sm:flex items-center gap-2 mb-3 z-20 px-3 py-1.5 rounded-full liquid-glass-pill shadow-xs text-xs font-semibold text-slate-700">
        <button
          onClick={() => setIsDesktopExpanded(false)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all ${
            !isDesktopExpanded ? 'bg-white shadow-xs text-purple-700 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Mobile Device (9:19.5)</span>
        </button>

        <button
          onClick={() => setIsDesktopExpanded(true)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full transition-all ${
            isDesktopExpanded ? 'bg-white shadow-xs text-purple-700 font-bold' : 'hover:text-slate-900'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Full Width</span>
        </button>
      </div>

      {/* Main Container */}
      <div
        className={`relative z-10 w-full transition-all duration-300 flex flex-col ${
          isDesktopExpanded
            ? 'max-w-4xl h-[92vh] rounded-[36px] overflow-hidden shadow-2xl border border-white/80 bg-white'
            : 'max-w-[420px] h-[100dvh] sm:h-[850px] sm:rounded-[44px] overflow-hidden sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.3)] sm:border-[8px] sm:border-slate-900/95 bg-white'
        }`}
      >
        {/* Smartphone Dynamic Island / Notch on mobile view in desktop */}
        {!isDesktopExpanded && (
          <div className="hidden sm:flex absolute top-0 left-0 right-0 z-40 h-8 items-center justify-between px-7 pointer-events-none text-[11px] font-bold text-white mix-blend-difference">
            <span>9:41</span>
            {/* Dynamic Island Pill */}
            <div className="w-24 h-5 bg-black rounded-full mx-auto" />
            <div className="flex items-center gap-1.5">
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Content Viewport */}
        <div className="relative w-full h-full flex flex-col overflow-hidden bg-slate-900">
          {children}
        </div>
      </div>
    </div>
  );
};
