import React from 'react';
import { Search, Bell } from 'lucide-react';
import { ViralFlowLogo } from './ViralFlowLogo';
import { FeedTabType } from '../types';

interface TopBarProps {
  activeFeedTab: FeedTabType;
  onFeedTabChange: (tab: FeedTabType) => void;
  onSearchClick: () => void;
  onNotificationsClick: () => void;
  unreadCount?: number;
  mode?: 'video' | 'light';
}

/**
 * Modern Facebook-style top header for the ViralFlow main app.
 * - Sits cleanly at the top of the app (NOT over video content).
 * - Displays the full ViralFlow logo with transparent background on the left.
 * - Action buttons on the right (Search, Notifications with unread badge).
 * - Integrated social feed tabs (For You | Trending | Following) with clean active indicators.
 */
export const TopBar: React.FC<TopBarProps> = ({
  activeFeedTab,
  onFeedTabChange,
  onSearchClick,
  onNotificationsClick,
  unreadCount = 2,
}) => {
  return (
    <header
      id="viralflow-main-header"
      className="w-full bg-white dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800 shrink-0 z-30 shadow-xs select-none"
    >
      {/* Top Branding Row: Wordmark on Left, Action Buttons on Right (Facebook-style) */}
      <div className="flex items-center justify-between px-3.5 py-1.5 max-w-md mx-auto">
        {/* Left: ViralFlow Wordmark with transparent background (No colored pill or background box) */}
        <div className="flex items-center justify-start bg-transparent">
          <ViralFlowLogo
            id="main-app-header-logo"
            className="bg-transparent"
          />
        </div>

        {/* Right: Modern circular action buttons (Search, Notifications) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            id="header-search-button"
            onClick={onSearchClick}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-all cursor-pointer"
            aria-label="Search ViralFlow"
            title="Search"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            id="header-notifications-button"
            onClick={onNotificationsClick}
            className="relative w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 active:scale-95 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center transition-all cursor-pointer"
            aria-label="Notifications"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-pink-500 ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* Feed Navigation Tabs (For You | Trending | Following) */}
      <div className="flex items-center justify-around border-t border-slate-100 dark:border-slate-800/80 px-2 max-w-md mx-auto">
        <button
          id="feed-tab-foryou"
          onClick={() => onFeedTabChange('forYou')}
          className={`flex-1 py-2 text-center text-xs font-semibold relative transition-colors cursor-pointer ${
            activeFeedTab === 'forYou'
              ? 'text-purple-600 dark:text-purple-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <span>For You</span>
          {activeFeedTab === 'forYou' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2.5px] rounded-full bg-gradient-to-r from-purple-600 to-pink-500" />
          )}
        </button>

        <button
          id="feed-tab-trending"
          onClick={() => onFeedTabChange('trending')}
          className={`flex-1 py-2 text-center text-xs font-semibold relative transition-colors cursor-pointer ${
            activeFeedTab === 'trending'
              ? 'text-purple-600 dark:text-purple-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <span>Trending</span>
          {activeFeedTab === 'trending' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2.5px] rounded-full bg-gradient-to-r from-purple-600 to-pink-500" />
          )}
        </button>

        <button
          id="feed-tab-following"
          onClick={() => onFeedTabChange('following')}
          className={`flex-1 py-2 text-center text-xs font-semibold relative transition-colors cursor-pointer ${
            activeFeedTab === 'following'
              ? 'text-purple-600 dark:text-purple-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <span>Following</span>
          {activeFeedTab === 'following' && (
            <span className="absolute bottom-0 left-1/4 right-1/4 h-[2.5px] rounded-full bg-gradient-to-r from-purple-600 to-pink-500" />
          )}
        </button>
      </div>
    </header>
  );
};

