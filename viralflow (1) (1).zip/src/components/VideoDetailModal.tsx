import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Music,
  Play,
  Volume2,
  VolumeX,
  UserPlus,
  Check,
} from 'lucide-react';
import { VideoItem, UserProfile } from '../types';
import { CommentsDrawer } from './CommentsDrawer';
import { ShareModal } from './ShareModal';

interface VideoDetailModalProps {
  video: VideoItem | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onLikeToggle: (videoId: string) => void;
  onSaveToggle: (videoId: string) => void;
  onFollowToggle: (creatorId: string) => void;
  onSelectCreator?: (creatorId: string) => void;
}

export const VideoDetailModal: React.FC<VideoDetailModalProps> = ({
  video,
  isOpen,
  onClose,
  currentUser,
  onLikeToggle,
  onSaveToggle,
  onFollowToggle,
  onSelectCreator,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [showHeartBurst, setShowHeartBurst] = useState(false);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);

  useEffect(() => {
    if (isOpen && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          // Autoplay policy fallback: mute and play
          if (videoRef.current) {
            videoRef.current.muted = true;
            setIsMuted(true);
            videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
          }
        });
    } else if (!isOpen && videoRef.current) {
      videoRef.current.pause();
    }
  }, [isOpen, video]);

  if (!isOpen || !video) return null;

  const handleTogglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleToggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    onLikeToggle(video.id);
    if (!video.isLiked) {
      setShowHeartBurst(true);
      setTimeout(() => setShowHeartBurst(false), 900);
    }
  };

  const handleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSaveToggle(video.id);
  };

  const handleFollow = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFollowToggle(video.creator.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md animate-fadeIn">
      {/* Backdrop tap to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-sm h-[92vh] max-h-[800px] bg-black rounded-[32px] overflow-hidden shadow-2xl border border-white/20 flex flex-col">
        {/* Video Element */}
        <div
          className="relative w-full h-full cursor-pointer flex items-center justify-center bg-black"
          onClick={handleTogglePlay}
        >
          <video
            ref={videoRef}
            src={video.videoUrl}
            poster={
              video.posterUrl && !video.posterUrl.includes('=s96-c') && video.posterUrl !== video.creator.avatar
                ? video.posterUrl
                : undefined
            }
            loop
            playsInline
            muted={isMuted}
            onError={(e) => {
              const v = e.currentTarget;
              const fallback = 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/docs/walking_talking.mp4';
              if (v.src !== fallback) {
                v.src = fallback;
                v.play().catch(() => {});
              }
            }}
            className="w-full h-full object-cover"
          />

          {/* Pause overlay icon */}
          {!isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/30 pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30">
                <Play className="w-8 h-8 fill-white ml-1" />
              </div>
            </div>
          )}

          {/* Heart burst animation on like */}
          {showHeartBurst && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-ping">
              <Heart className="w-24 h-24 text-pink-500 fill-pink-500 drop-shadow-lg" />
            </div>
          )}

          {/* Top Bar Overlay */}
          <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/60 to-transparent">
            <button
              onClick={handleToggleMute}
              className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center border border-white/20 hover:bg-black/60 transition-colors"
              aria-label="Toggle audio"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-md text-white flex items-center justify-center border border-white/20 hover:bg-black/60 transition-colors"
              aria-label="Close video player"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Right Action Rail (Like, Comment, Save, Share) */}
          <div
            className="absolute right-3 bottom-20 z-20 flex flex-col items-center gap-4.5"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Creator Avatar with follow button */}
            <div className="relative mb-1">
              <div
                onClick={() => onSelectCreator?.(video.creator.id)}
                className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-purple-500 to-pink-500 cursor-pointer hover:scale-105 transition-transform"
              >
                <img
                  src={video.creator.avatar}
                  alt={video.creator.name}
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <button
                onClick={handleFollow}
                className={`absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full flex items-center justify-center text-white border-2 border-black transition-all ${
                  video.creator.isFollowing
                    ? 'bg-slate-700 text-slate-300'
                    : 'bg-gradient-to-r from-pink-500 to-rose-500'
                }`}
                title={video.creator.isFollowing ? 'Following' : 'Follow'}
              >
                {video.creator.isFollowing ? (
                  <Check className="w-2.5 h-2.5 stroke-[3]" />
                ) : (
                  <UserPlus className="w-2.5 h-2.5 stroke-[2.5]" />
                )}
              </button>
            </div>

            {/* Like Button */}
            <button
              onClick={handleLike}
              className="group flex flex-col items-center gap-1 text-white"
              aria-label="Like video"
            >
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md border transition-all active:scale-90 ${
                  video.isLiked
                    ? 'bg-pink-500/90 text-white border-pink-400 shadow-md shadow-pink-500/30'
                    : 'bg-black/30 border-white/20 text-white hover:bg-black/40'
                }`}
              >
                <Heart
                  className={`w-5 h-5 transition-transform ${
                    video.isLiked ? 'fill-white scale-110' : 'group-hover:scale-110'
                  }`}
                />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">
                {video.likesCount}
              </span>
            </button>

            {/* Comment Button */}
            <button
              onClick={() => setIsCommentsOpen(true)}
              className="group flex flex-col items-center gap-1 text-white"
              aria-label="Open comments"
            >
              <div className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-black/40 transition-all active:scale-90">
                <MessageCircle className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">
                {video.commentsCount}
              </span>
            </button>

            {/* Save / Favorite Button */}
            <button
              onClick={handleSave}
              className="group flex flex-col items-center gap-1 text-white"
              aria-label="Save video"
            >
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md border transition-all active:scale-90 ${
                  video.isSaved
                    ? 'bg-amber-400 text-slate-900 border-amber-300 shadow-md shadow-amber-400/30'
                    : 'bg-black/30 border-white/20 text-white hover:bg-black/40'
                }`}
              >
                <Bookmark
                  className={`w-5 h-5 transition-transform ${
                    video.isSaved ? 'fill-current scale-110' : 'group-hover:scale-110'
                  }`}
                />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">
                {video.isSaved ? 'Saved' : 'Save'}
              </span>
            </button>

            {/* Share Button */}
            <button
              onClick={() => setIsShareOpen(true)}
              className="group flex flex-col items-center gap-1 text-white"
              aria-label="Share video"
            >
              <div className="w-11 h-11 rounded-full bg-black/30 backdrop-blur-md border border-white/20 flex items-center justify-center hover:bg-black/40 transition-all active:scale-90">
                <Share2 className="w-5 h-5 text-white group-hover:scale-110 transition-transform" />
              </div>
              <span className="text-[11px] font-bold text-white drop-shadow-md">Share</span>
            </button>
          </div>

          {/* Bottom Info Overlay */}
          <div
            className="absolute bottom-0 left-0 right-16 p-4 z-20 bg-gradient-to-t from-black/80 via-black/40 to-transparent pointer-events-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Creator Username and Name */}
            <div
              onClick={() => onSelectCreator?.(video.creator.id)}
              className="flex items-center gap-2 cursor-pointer mb-1.5"
            >
              <span className="font-extrabold text-sm text-white drop-shadow-md">
                {video.creator.name}
              </span>
              <span className="text-xs text-white/70">@{video.creator.username}</span>
            </div>

            {/* Caption */}
            <p className="text-xs text-white/95 line-clamp-3 leading-relaxed drop-shadow-md mb-2">
              {video.caption}
            </p>

            {/* Tags */}
            {video.tags && video.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {video.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] font-bold text-sky-300 drop-shadow-sm"
                  >
                    {tag.startsWith('#') ? tag : `#${tag}`}
                  </span>
                ))}
              </div>
            )}

            {/* Music track */}
            <div className="flex items-center gap-2 text-white/80 text-[11px]">
              <Music className="w-3.5 h-3.5 text-pink-400 shrink-0" />
              <span className="truncate">{video.music.title} • {video.music.artist}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Embedded Comments Drawer */}
      <CommentsDrawer
        isOpen={isCommentsOpen}
        onClose={() => setIsCommentsOpen(false)}
        videoId={video.id}
        commentsCount={video.commentsCount}
        currentUser={currentUser}
        videoOwnerId={video.creator.id}
        videoThumbnail={video.posterUrl}
      />

      {/* Embedded Share Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        video={video}
        videoTitle={video.caption}
        videoId={video.id}
        currentUser={currentUser}
        isSaved={video.isSaved}
        onToggleSave={() => onSaveToggle(video.id)}
      />
    </div>
  );
};
