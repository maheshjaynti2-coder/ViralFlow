import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Heart,
  Send,
  Sparkles,
  Loader2,
  MessageCircle,
  CornerDownRight,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { CommentItem, UserProfile, DEFAULT_AVATAR } from '../types';
import {
  subscribeVideoComments,
  addFirestoreComment,
  toggleFirestoreCommentLike,
  createFirestoreNotification,
  auth,
} from '../lib/firebase';

interface CommentsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  videoId: string;
  commentsCount: number;
  currentUser: UserProfile;
  videoOwnerId?: string;
  videoThumbnail?: string;
  onAddComment?: (text: string) => void;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({
  isOpen,
  onClose,
  videoId,
  commentsCount,
  currentUser,
  videoOwnerId,
  videoThumbnail,
  onAddComment,
}) => {
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Active reply target state
  const [replyingTo, setReplyingTo] = useState<{
    id: string;
    parentId: string;
    userName: string;
    userId?: string;
  } | null>(null);

  // Expanded reply threads: default all visible
  const [collapsedThreads, setCollapsedThreads] = useState<Record<string, boolean>>({});

  const inputRef = useRef<HTMLInputElement>(null);
  const commentsEndRef = useRef<HTMLDivElement>(null);

  // Load real-time comments from Firestore
  const loadComments = () => {
    if (!videoId) return () => {};

    setIsLoading(true);
    setErrorMessage(null);

    const userUid = currentUser.uid || auth.currentUser?.uid;
    const unsubscribe = subscribeVideoComments(
      videoId,
      userUid,
      (firestoreComments) => {
        setComments(firestoreComments);
        setIsLoading(false);
        setErrorMessage(null);
      },
      (err) => {
        console.warn('Comments subscription warning:', err);
        setErrorMessage('Unable to sync comments in real-time. Please check your connection.');
        setIsLoading(false);
      }
    );

    return unsubscribe;
  };

  useEffect(() => {
    if (!isOpen || !videoId) return;
    const unsubscribe = loadComments();
    return () => {
      unsubscribe();
    };
  }, [isOpen, videoId, currentUser.uid]);

  if (!isOpen) return null;

  // Toggle reply expansion
  const toggleThreadCollapse = (commentId: string) => {
    setCollapsedThreads((prev) => ({
      ...prev,
      [commentId]: !prev[commentId],
    }));
  };

  // Start replying to a comment or a nested reply
  const handleStartReply = (
    commentId: string,
    rootParentId: string,
    targetName: string,
    targetUserId?: string
  ) => {
    setReplyingTo({
      id: commentId,
      parentId: rootParentId,
      userName: targetName,
      userId: targetUserId,
    });
    setSubmitError(null);
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  const handleCancelReply = () => {
    setReplyingTo(null);
    setSubmitError(null);
  };

  // Submit comment or threaded reply
  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanText = inputText.trim();
    if (!cleanText || isSubmitting) return;

    // Check authenticated user
    const authenticatedUid = currentUser.uid || auth.currentUser?.uid;
    if (!authenticatedUid) {
      setSubmitError('Please sign in to post comments and join the conversation.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    const isReply = !!replyingTo;
    const parentId = replyingTo ? replyingTo.parentId : null;
    const replyToUser = replyingTo ? replyingTo.userName : null;
    const replyTargetUserId = replyingTo?.userId;

    const optimisticComment: CommentItem = {
      id: `c_${Date.now()}`,
      videoId,
      userId: authenticatedUid,
      user: {
        name: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
        username: currentUser.username || 'creator',
        avatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
        isVerified: true,
      },
      text: cleanText,
      likesCount: 0,
      isLiked: false,
      createdAt: 'Just now',
      parentId,
      replyToUser,
      replies: [],
    };

    // Optimistic UI update
    if (isReply && parentId) {
      setComments((prev) =>
        prev.map((c) => {
          if (c.id === parentId) {
            return {
              ...c,
              replies: [...(c.replies || []), optimisticComment],
            };
          }
          return c;
        })
      );
      // Ensure thread is not collapsed
      setCollapsedThreads((prev) => ({ ...prev, [parentId]: false }));
    } else {
      setComments((prev) => [optimisticComment, ...prev]);
    }

    setInputText('');
    setReplyingTo(null);

    try {
      const createdComment = await addFirestoreComment(
        videoId,
        authenticatedUid,
        cleanText,
        {
          name: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
          username: currentUser.username || 'creator',
          avatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
        },
        parentId,
        replyToUser
      );

      // Trigger Firestore notifications
      const truncatedText = cleanText.length > 50 ? `${cleanText.slice(0, 50)}...` : cleanText;
      if (isReply && replyTargetUserId && replyTargetUserId !== authenticatedUid) {
        createFirestoreNotification({
          recipientId: replyTargetUserId,
          senderId: authenticatedUid,
          senderName: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
          senderUsername: currentUser.username,
          senderAvatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
          type: 'reply',
          videoId,
          videoThumbnail,
          commentId: createdComment.commentId,
          message: `replied: "${truncatedText}"`,
        });
      } else if (!isReply && videoOwnerId && videoOwnerId !== authenticatedUid) {
        createFirestoreNotification({
          recipientId: videoOwnerId,
          senderId: authenticatedUid,
          senderName: currentUser.name || currentUser.displayName || 'ViralFlow Creator',
          senderUsername: currentUser.username,
          senderAvatar: currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR,
          type: 'comment',
          videoId,
          videoThumbnail,
          commentId: createdComment.commentId,
          message: `commented: "${truncatedText}"`,
        });
      }

      if (onAddComment) {
        onAddComment(cleanText);
      }
    } catch (err) {
      console.error('Error posting comment to Firestore:', err);
      setSubmitError('Could not post comment. Please check your internet connection.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleLikeComment = async (id: string) => {
    const authenticatedUid = currentUser.uid || auth.currentUser?.uid;
    if (!authenticatedUid) {
      setSubmitError('Please sign in to like comments.');
      return;
    }

    // Find current comment state
    let targetComment: CommentItem | undefined;
    for (const c of comments) {
      if (c.id === id) {
        targetComment = c;
        break;
      }
      if (c.replies) {
        const found = c.replies.find((r) => r.id === id);
        if (found) {
          targetComment = found;
          break;
        }
      }
    }

    if (!targetComment) return;
    const currentlyLiked = !!targetComment.isLiked;

    // Optimistic UI update
    setComments((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          return {
            ...c,
            isLiked: !currentlyLiked,
            likesCount: currentlyLiked ? Math.max(0, c.likesCount - 1) : c.likesCount + 1,
          };
        }
        if (c.replies && c.replies.length > 0) {
          return {
            ...c,
            replies: c.replies.map((rep) =>
              rep.id === id
                ? {
                    ...rep,
                    isLiked: !currentlyLiked,
                    likesCount: currentlyLiked
                      ? Math.max(0, rep.likesCount - 1)
                      : rep.likesCount + 1,
                  }
                : rep
            ),
          };
        }
        return c;
      })
    );

    try {
      await toggleFirestoreCommentLike(authenticatedUid, id, videoId, !currentlyLiked);
    } catch (err) {
      console.error('Error toggling comment like:', err);
      // Rollback on failure
      setComments((prev) =>
        prev.map((c) => {
          if (c.id === id) {
            return {
              ...c,
              isLiked: currentlyLiked,
              likesCount: targetComment?.likesCount ?? 0,
            };
          }
          if (c.replies && c.replies.length > 0) {
            return {
              ...c,
              replies: c.replies.map((rep) =>
                rep.id === id
                  ? {
                      ...rep,
                      isLiked: currentlyLiked,
                      likesCount: targetComment?.likesCount ?? 0,
                    }
                  : rep
              ),
            };
          }
          return c;
        })
      );
    }
  };

  const quickEmojis = ['💜', '✨', '🔥', '👏', '😍', '🙌'];

  // Calculate total count including all nested replies
  const totalCommentsCount = comments.reduce(
    (acc, c) => acc + 1 + (c.replies?.length || 0),
    0
  );
  const displayCount = Math.max(totalCommentsCount, commentsCount);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-sm animate-fadeIn">
      {/* Backdrop tap to close */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Glass Bottom Sheet */}
      <div className="relative z-10 w-full max-w-md h-[72vh] max-h-[640px] bg-white/95 backdrop-blur-2xl rounded-t-[32px] border-t border-white/80 shadow-2xl flex flex-col overflow-hidden pb-safe animate-slideUp">
        {/* Grab bar */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto mt-3 mb-1 shrink-0" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-2.5 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-1.5">
            <h3 className="font-bold text-slate-800 text-sm">
              {displayCount} {displayCount === 1 ? 'Comment' : 'Comments'}
            </h3>
            <Sparkles className="w-3.5 h-3.5 text-purple-500" />
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-slate-200 transition-colors cursor-pointer"
            aria-label="Close comments"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sync error banner */}
        {errorMessage && (
          <div className="mx-4 mt-2 p-2 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[11px] flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={loadComments}
              className="px-2 py-0.5 rounded-md bg-amber-100 font-bold hover:bg-amber-200 text-amber-900 transition-colors cursor-pointer flex items-center gap-1 shrink-0"
            >
              <RefreshCw className="w-2.5 h-2.5" />
              Retry
            </button>
          </div>
        )}

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {isLoading ? (
            <div className="py-16 flex flex-col items-center justify-center text-slate-400 gap-2">
              <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
              <span className="text-xs font-medium text-slate-500">
                Loading live conversation...
              </span>
            </div>
          ) : comments.length > 0 ? (
            <div className="space-y-4">
              {comments.map((comment) => {
                const isCollapsed = !!collapsedThreads[comment.id];
                const repliesCount = comment.replies?.length || 0;

                return (
                  <div key={comment.id} className="group">
                    {/* Top-Level Comment */}
                    <div className="flex items-start gap-3">
                      <img
                        src={comment.user.avatar || DEFAULT_AVATAR}
                        alt={comment.user.name}
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                        }}
                        className="w-8 h-8 rounded-full object-cover border border-purple-200 shrink-0 bg-slate-100"
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-slate-900 truncate">
                            {comment.user.name}
                          </span>
                          {comment.user.isVerified && (
                            <span className="w-3 h-3 rounded-full bg-sky-500 text-white text-[8px] flex items-center justify-center font-bold">
                              ✓
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400 font-medium">
                            {comment.createdAt}
                          </span>
                        </div>

                        <p className="text-xs text-slate-700 mt-0.5 leading-relaxed break-words font-medium">
                          {comment.text}
                        </p>

                        {/* Comment Actions */}
                        <div className="flex items-center gap-3 mt-1.5">
                          <button
                            onClick={() =>
                              handleStartReply(
                                comment.id,
                                comment.id,
                                comment.user.name,
                                comment.userId
                              )
                            }
                            className="text-[11px] font-bold text-slate-500 hover:text-purple-600 transition-colors cursor-pointer"
                          >
                            Reply
                          </button>
                        </div>
                      </div>

                      <button
                        onClick={() => toggleLikeComment(comment.id)}
                        className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-pink-500 transition-colors pt-1 cursor-pointer"
                        aria-label="Like comment"
                      >
                        <Heart
                          className={`w-3.5 h-3.5 transition-transform active:scale-125 ${
                            comment.isLiked ? 'text-pink-500 fill-pink-500' : ''
                          }`}
                        />
                        {comment.likesCount > 0 && (
                          <span className="text-[9px] font-bold text-slate-500">
                            {comment.likesCount}
                          </span>
                        )}
                      </button>
                    </div>

                    {/* Threaded Replies Section */}
                    {repliesCount > 0 && (
                      <div className="ml-7 mt-2 pl-3 border-l-2 border-purple-100">
                        {/* Collapse/Expand Toggle */}
                        {repliesCount > 2 && (
                          <button
                            onClick={() => toggleThreadCollapse(comment.id)}
                            className="flex items-center gap-1.5 text-[11px] font-bold text-purple-600 hover:text-purple-700 transition-colors py-1 cursor-pointer mb-2"
                          >
                            <CornerDownRight className="w-3 h-3 text-purple-500" />
                            {isCollapsed
                              ? `View ${repliesCount} replies`
                              : `Hide replies`}
                          </button>
                        )}

                        {/* List of Replies */}
                        {!isCollapsed && (
                          <div className="space-y-3">
                            {comment.replies?.map((reply) => (
                              <div
                                key={reply.id}
                                className="flex items-start gap-2.5 pt-1"
                              >
                                <img
                                  src={reply.user.avatar || DEFAULT_AVATAR}
                                  alt={reply.user.name}
                                  onError={(e) => {
                                    (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                                  }}
                                  className="w-6 h-6 rounded-full object-cover border border-purple-200 shrink-0 bg-slate-100"
                                />

                                <div className="flex-1 min-w-0">
                                  <div className="flex items-center gap-1.5">
                                    <span className="font-bold text-[11px] text-slate-900 truncate">
                                      {reply.user.name}
                                    </span>
                                    <span className="text-[9px] text-slate-400 font-medium">
                                      {reply.createdAt}
                                    </span>
                                  </div>

                                  <p className="text-[11px] text-slate-700 mt-0.5 leading-relaxed break-words font-medium">
                                    {reply.replyToUser && (
                                      <span className="text-purple-600 font-semibold mr-1">
                                        @{reply.replyToUser}
                                      </span>
                                    )}
                                    {reply.text}
                                  </p>

                                  <div className="flex items-center gap-3 mt-1">
                                    <button
                                      onClick={() =>
                                        handleStartReply(
                                          reply.id,
                                          comment.id,
                                          reply.user.name,
                                          reply.userId
                                        )
                                      }
                                      className="text-[10px] font-bold text-slate-500 hover:text-purple-600 transition-colors cursor-pointer"
                                    >
                                      Reply
                                    </button>
                                  </div>
                                </div>

                                <button
                                  onClick={() => toggleLikeComment(reply.id)}
                                  className="flex flex-col items-center gap-0.5 text-slate-400 hover:text-pink-500 transition-colors pt-0.5 cursor-pointer"
                                  aria-label="Like reply"
                                >
                                  <Heart
                                    className={`w-3 h-3 transition-transform active:scale-125 ${
                                      reply.isLiked ? 'text-pink-500 fill-pink-500' : ''
                                    }`}
                                  />
                                  {reply.likesCount > 0 && (
                                    <span className="text-[8px] font-bold text-slate-500">
                                      {reply.likesCount}
                                    </span>
                                  )}
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
              <div ref={commentsEndRef} />
            </div>
          ) : (
            <div className="py-16 text-center text-slate-400 flex flex-col items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center mb-2.5">
                <MessageCircle className="w-6 h-6 text-purple-400" />
              </div>
              <p className="text-xs font-bold text-slate-700">No comments yet</p>
              <p className="text-[11px] text-slate-400 mt-1 max-w-[220px]">
                Be the first to share your vibes and start the conversation! ✨
              </p>
            </div>
          )}
        </div>

        {/* Quick Emoji Shelf */}
        <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-50/90 border-t border-slate-100 overflow-x-auto no-scrollbar shrink-0">
          {quickEmojis.map((emoji) => (
            <button
              key={emoji}
              onClick={() => setInputText((prev) => prev + emoji)}
              className="text-base p-1 hover:scale-125 active:scale-95 transition-transform cursor-pointer"
              type="button"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Active Reply Banner */}
        {replyingTo && (
          <div className="flex items-center justify-between px-4 py-1.5 bg-purple-50/90 border-t border-purple-100 text-xs text-purple-800 shrink-0">
            <div className="flex items-center gap-1.5 truncate">
              <CornerDownRight className="w-3.5 h-3.5 text-purple-600 shrink-0" />
              <span className="font-medium truncate">
                Replying to <strong className="font-bold">@{replyingTo.userName}</strong>
              </span>
            </div>
            <button
              onClick={handleCancelReply}
              className="p-1 text-purple-500 hover:text-purple-800 rounded-full hover:bg-purple-100 transition-colors cursor-pointer"
              aria-label="Cancel reply"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Submit Error Notice */}
        {submitError && (
          <div className="px-4 py-1.5 bg-red-50 text-red-600 text-[11px] font-medium border-t border-red-100 flex items-center gap-1.5 shrink-0">
            <AlertCircle className="w-3.5 h-3.5 text-red-500 shrink-0" />
            <span className="flex-1">{submitError}</span>
            <button
              onClick={() => setSubmitError(null)}
              className="text-red-400 hover:text-red-700"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Input Bar */}
        <form
          onSubmit={handleSend}
          className="p-3 bg-white border-t border-slate-100 flex items-center gap-2.5 shrink-0"
        >
          <img
            src={currentUser.avatar || currentUser.photoURL || DEFAULT_AVATAR}
            alt={currentUser.name || 'User'}
            onError={(e) => {
              (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
            }}
            className="w-8 h-8 rounded-full object-cover border border-purple-200 shrink-0 bg-slate-100"
          />

          <div className="relative flex-1">
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                replyingTo
                  ? `Reply to @${replyingTo.userName}...`
                  : 'Add a comment...'
              }
              className="w-full py-2.5 pl-3.5 pr-10 rounded-full bg-slate-100 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400 border border-slate-200"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isSubmitting}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-gradient-to-r from-purple-600 to-pink-500 text-white flex items-center justify-center disabled:opacity-40 transition-opacity cursor-pointer shadow-xs"
              aria-label="Send comment"
            >
              {isSubmitting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
