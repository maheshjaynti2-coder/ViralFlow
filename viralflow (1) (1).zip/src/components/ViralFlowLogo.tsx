import React, { useState } from 'react';
import wordmarkAsset from '../assets/images/viralflow_wordmark_transparent.png';

export interface ViralFlowLogoProps {
  className?: string;
  alt?: string;
  id?: string;
}

/**
 * ViralFlowLogo displays ONLY the wordmark "ViralFlow" from the official logo asset
 * with its transparent background. Proportions (3.80:1 aspect ratio) and crisp
 * fidelity are strictly maintained without the play/icon symbol.
 */
export const ViralFlowLogo: React.FC<ViralFlowLogoProps> = ({
  className = '',
  alt = 'ViralFlow',
  id = 'viralflow-header-logo',
}) => {
  const [imgSrc, setImgSrc] = useState<string>(wordmarkAsset);

  return (
    <div className={`relative inline-flex items-center justify-start bg-transparent select-none ${className}`}>
      <img
        id={id}
        src={imgSrc}
        alt={alt}
        className="h-8 sm:h-9 w-auto max-w-[170px] sm:max-w-[200px] object-contain bg-transparent transition-opacity duration-200"
        onError={() => {
          if (imgSrc !== '/viralflow_wordmark.png') {
            setImgSrc('/viralflow_wordmark.png');
          }
        }}
        referrerPolicy="no-referrer"
        draggable={false}
      />
    </div>
  );
};

