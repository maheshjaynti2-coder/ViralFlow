import React, { useState, useEffect } from 'react';
import { X, Copy, Download, Bookmark, Check, Sparkles, Flag } from 'lucide-react';
import { VideoItem, UserProfile, FirestoreUserDoc, DEFAULT_AVATAR } from '../types';
import { subscribeShareableFriends, auth } from '../lib/firebase';
import { sendDirectMessageToFriend } from '../lib/directMessages';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  video?: VideoItem;
  videoTitle?: string;
  videoId?: string;
  currentUser?: UserProfile;
  isSaved?: boolean;
  onToggleSave?: (videoId: string) => void;
  onShareDirectMessage?: (recipient: FirestoreUserDoc, video: VideoItem) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  video,
  videoTitle,
  videoId,
  currentUser,
  isSaved = false,
  onToggleSave,
  onShareDirectMessage,
}) => {
  const [copied, setCopied] = useState(false);
  const [reported, setReported] = useState(false);
  const [savedLocally, setSavedLocally] = useState(isSaved);
  const [sentFriendId, setSentFriendId] = useState<string | null>(null);

  // Real users from Firestore
  const [realFriends, setRealFriends] = useState<FirestoreUserDoc[]>([]);
  const [isLoadingFriends, setIsLoadingFriends] = useState<boolean>(true);

  // Sync saved state
  useEffect(() => {
    setSavedLocally(isSaved);
  }, [isSaved]);

  // Construct effective video object if partial props provided
  const effectiveVideo: VideoItem = video || {
    id: videoId || 'vf-share',
    videoUrl: 'https://res.cloudinary.com/demo/video/upload/c_fill,ar_9:16,w_720/docs/walking_talking.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80',
    caption: videoTitle || 'Check out this ViralFlow short!',
    creator: {
      id: 'creator-1',
      name: 'ViralFlow Creator',
      username: 'viralflow',
      avatar: DEFAULT_AVATAR,
      isFollowing: false,
    },
    likesCount: '1.2K',
    commentsCount: 24,
    sharesCount: 12,
    musicName: 'Original Sound',
    isLiked: false,
    isSaved: false,
    category: 'Lifestyle',
  };

  // Subscribe to real users from Firestore, prioritizing connected users
  useEffect(() => {
    if (!isOpen) return;

    setIsLoadingFriends(true);
    const userId = currentUser?.uid || auth.currentUser?.uid || 'guest';

    const unsubscribe = subscribeShareableFriends(
      userId,
      (users) => {
        setRealFriends(users);
        setIsLoadingFriends(false);
      },
      (err) => {
        console.warn('Error loading shareable friends:', err);
        setIsLoadingFriends(false);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [isOpen, currentUser?.uid]);

  if (!isOpen) return null;

  const handleCopy = () => {
    const shareUrl = `https://viralflow.app/v/${effectiveVideo.id}`;
    navigator.clipboard?.writeText?.(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleReport = () => {
    setReported(true);
    setTimeout(() => setReported(false), 2500);
  };

  const handleToggleSaveClick = () => {
    setSavedLocally((prev) => !prev);
    if (onToggleSave) {
      onToggleSave(effectiveVideo.id);
    }
  };

  const handleSendToFriend = (friend: FirestoreUserDoc) => {
    setSentFriendId(friend.uid);

    // 1. Send via existing Direct Messaging system
    const activeUser = currentUser || {
      name: 'ViralFlow Creator',
      username: '@creator',
      avatar: DEFAULT_AVATAR,
      bio: '',
      followingCount: 0,
      followersCount: '0',
      likesCount: '0',
    };

    sendDirectMessageToFriend({
      sender: activeUser,
      recipient: {
        id: friend.uid,
        name: friend.displayName || 'Friend',
        username: friend.username || `@user_${friend.uid.slice(0, 5)}`,
        avatar: friend.photoURL || DEFAULT_AVATAR,
      },
      sharedVideo: {
        id: effectiveVideo.id,
        caption: effectiveVideo.caption,
        posterUrl: effectiveVideo.posterUrl,
        videoUrl: effectiveVideo.videoUrl,
      },
    });

    // 2. Trigger parent callback if provided
    if (onShareDirectMessage) {
      onShareDirectMessage(friend, effectiveVideo);
    }

    // Reset feedback after delay
    setTimeout(() => {
      setSentFriendId(null);
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur-2xl rounded-t-[32px] sm:rounded-[32px] border border-white/80 shadow-2xl p-5 flex flex-col gap-4 animate-slideUp">
        {/* Grab bar */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto sm:hidden -mt-1" />

        {/* Title */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <h3 className="font-bold text-slate-800 text-sm">Share ViralFlow Short</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Send to Real Friends row */}
        <div>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Send to Friends
          </span>
          <div className="flex items-center gap-4 mt-2.5 overflow-x-auto pb-1 no-scrollbar min-h-[72px]">
            {isLoadingFriends ? (
              <div className="flex items-center justify-center w-full py-4 gap-2 text-slate-400 text-xs">
                <div className="w-3.5 h-3.5 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                <span>Loading friends...</span>
              </div>
            ) : realFriends.length === 0 ? (
              <div className="w-full py-4 text-center">
                <p className="text-xs font-medium text-slate-500">No friends to share with yet</p>
              </div>
            ) : (
              realFriends.map((friend) => (
                <button
                  key={friend.uid}
                  onClick={() => handleSendToFriend(friend)}
                  className="flex flex-col items-center gap-1 shrink-0 group focus:outline-none cursor-pointer"
                >
                  <div className="relative w-12 h-12 rounded-full p-[2px] bg-gradient-to-tr from-sky-400 via-purple-500 to-pink-500">
                    <img
                      src={friend.photoURL || DEFAULT_AVATAR}
                      alt={friend.displayName || 'Friend'}
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                      }}
                      className="w-full h-full object-cover rounded-full group-hover:scale-105 transition-transform bg-slate-100"
                    />
                    {sentFriendId === friend.uid && (
                      <div className="absolute inset-0 rounded-full bg-purple-600/95 flex items-center justify-center text-white text-xs">
                        <Check className="w-4 h-4 stroke-[3]" />
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-700 font-medium max-w-[54px] truncate">
                    {sentFriendId === friend.uid
                      ? 'Sent!'
                      : friend.displayName
                      ? friend.displayName.split(' ')[0]
                      : friend.username}
                  </span>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Action Grid */}
        <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-100">
          {/* Copy Link */}
          <button
            onClick={handleCopy}
            className="flex flex-col items-center gap-1.5 p-1.5 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-100 shadow-xs">
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
            </div>
            <span className="text-[10px] font-semibold text-slate-700 truncate w-full text-center">
              {copied ? 'Copied!' : 'Copy Link'}
            </span>
          </button>

          {/* Save / Bookmark */}
          <button
            onClick={handleToggleSaveClick}
            className="flex flex-col items-center gap-1.5 p-1.5 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center border shadow-xs transition-colors ${
                savedLocally
                  ? 'bg-pink-50 text-pink-600 border-pink-200'
                  : 'bg-slate-50 text-slate-700 border-slate-200'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${savedLocally ? 'fill-pink-500 text-pink-500' : ''}`} />
            </div>
            <span className="text-[10px] font-semibold text-slate-700 truncate w-full text-center">
              {savedLocally ? 'Saved' : 'Save'}
            </span>
          </button>

          {/* Save Video (Download) */}
          <button
            onClick={() => {
              const link = document.createElement('a');
              link.href = effectiveVideo.videoUrl;
              link.download = `ViralFlow-${effectiveVideo.id}.mp4`;
              link.target = '_blank';
              link.click();
            }}
            className="flex flex-col items-center gap-1.5 p-1.5 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100 shadow-xs">
              <Download className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-semibold text-slate-700 truncate w-full text-center">
              Save Video
            </span>
          </button>

          {/* Report */}
          <button
            onClick={handleReport}
            className="flex flex-col items-center gap-1.5 p-1.5 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center border shadow-xs transition-colors ${
                reported
                  ? 'bg-rose-50 text-rose-600 border-rose-200'
                  : 'bg-rose-50/50 text-rose-500 border-rose-100'
              }`}
            >
              {reported ? <Check className="w-4 h-4 text-rose-600" /> : <Flag className="w-4 h-4" />}
            </div>
            <span className="text-[10px] font-semibold text-slate-700 truncate w-full text-center">
              {reported ? 'Reported' : 'Report'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
