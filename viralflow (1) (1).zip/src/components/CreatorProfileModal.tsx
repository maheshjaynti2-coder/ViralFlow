import React, { useState, useEffect } from 'react';
import { X, Check, Plus, Play, Sparkles, Loader2 } from 'lucide-react';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { VideoItem, Creator, DEFAULT_AVATAR } from '../types';
import { POPULAR_CREATORS } from '../data/mockData';
import { db } from '../lib/firebase';

interface CreatorProfileModalProps {
  creatorId: string | null;
  onClose: () => void;
  videos: VideoItem[];
  onSelectVideo: (video: VideoItem) => void;
  onFollowToggle: (creatorId: string) => void;
}

export const CreatorProfileModal: React.FC<CreatorProfileModalProps> = ({
  creatorId,
  onClose,
  videos,
  onSelectVideo,
  onFollowToggle,
}) => {
  const [firestoreCreator, setFirestoreCreator] = useState<Creator | null>(null);
  const [firestoreVideos, setFirestoreVideos] = useState<VideoItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Find creator from video creators or popular list
  let inMemoryCreator: Creator | undefined = creatorId
    ? POPULAR_CREATORS.find((c) => c.id === creatorId)
    : undefined;

  if (!inMemoryCreator && creatorId) {
    const videoWithCreator = videos.find((v) => v.creator.id === creatorId);
    if (videoWithCreator) {
      inMemoryCreator = videoWithCreator.creator;
    }
  }

  // If not found in memory, load from Firestore `users` collection
  useEffect(() => {
    if (!creatorId) {
      setFirestoreCreator(null);
      setFirestoreVideos([]);
      return;
    }

    if (inMemoryCreator) {
      setFirestoreCreator(null);
      return;
    }

    let isMounted = true;
    setIsLoading(true);

    async function loadCreatorData() {
      try {
        const userRef = doc(db, 'users', creatorId!);
        const userSnap = await getDoc(userRef);

        if (userSnap.exists() && isMounted) {
          const uData = userSnap.data();
          const cleanUsername = uData.username
            ? uData.username.replace('@', '')
            : (uData.displayName || 'creator').toLowerCase().replace(/[^a-z0-9]/g, '');

          setFirestoreCreator({
            id: creatorId!,
            name: uData.displayName || uData.name || 'ViralFlow Creator',
            username: cleanUsername,
            avatar: uData.photoURL || uData.avatar || DEFAULT_AVATAR,
            isVerified: true,
            isFollowing: false,
            followers:
              typeof uData.followersCount === 'number'
                ? `${uData.followersCount}`
                : uData.followersCount || '0',
            bio: uData.bio || 'Creating authentic stories on ViralFlow ✨',
          });
        }

        // Fetch videos posted by this creator in Firestore
        const vQuery = query(collection(db, 'videos'), where('ownerId', '==', creatorId));
        const vSnap = await getDocs(vQuery);
        if (isMounted) {
          const loaded: VideoItem[] = vSnap.docs.map((docSnap) => {
            const data = docSnap.data();
            return {
              id: data.videoId || docSnap.id,
              videoUrl: data.videoUrl,
              posterUrl: data.thumbnailUrl || data.ownerPhoto || DEFAULT_AVATAR,
              creator: {
                id: creatorId!,
                name: data.ownerName || 'Creator',
                username: (data.ownerName || 'creator').toLowerCase().replace(/[^a-z0-9]/g, ''),
                avatar: data.ownerPhoto || DEFAULT_AVATAR,
                isVerified: true,
                isFollowing: false,
              },
              caption: data.caption || '',
              tags: data.hashtags ? data.hashtags.split(/\s+/).filter(Boolean) : ['#ViralFlow'],
              music: {
                id: `m_${docSnap.id}`,
                title: data.musicName || 'Original Sound',
                artist: data.ownerName || 'ViralFlow',
                albumArt: data.ownerPhoto || DEFAULT_AVATAR,
              },
              likesCount: data.likesCount || 0,
              commentsCount: data.commentsCount || 0,
              sharesCount: data.sharesCount || 0,
              savesCount: 0,
              isLiked: false,
              isSaved: false,
              views: `${Math.max(1, (data.likesCount || 0) * 12 + 10)}`,
              category: 'Trending',
              createdAt: data.createdAt ? 'Recently' : 'Just now',
            };
          });
          setFirestoreVideos(loaded);
        }
      } catch (err) {
        console.warn('Could not load creator profile from Firestore:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadCreatorData();

    return () => {
      isMounted = false;
    };
  }, [creatorId, inMemoryCreator]);

  if (!creatorId) return null;

  const creator = inMemoryCreator || firestoreCreator;

  if (!creator && !isLoading) return null;

  const inMemoryCreatorVideos = creator
    ? videos.filter(
        (v) => v.creator.id === creator?.id || v.creator.username === creator?.username
      )
    : [];

  const creatorVideos =
    inMemoryCreatorVideos.length > 0 ? inMemoryCreatorVideos : firestoreVideos;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative z-10 w-full max-w-md h-[80vh] max-h-[640px] bg-white/95 backdrop-blur-2xl rounded-t-[32px] sm:rounded-[32px] border border-white/90 shadow-2xl flex flex-col overflow-hidden pb-safe animate-slideUp">
        {/* Grab bar */}
        <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto mt-2.5 sm:hidden" />

        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-600" />
            <span className="font-extrabold text-xs text-slate-700">Creator Profile</span>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Profile Details */}
        <div className="flex-1 overflow-y-auto p-5 no-scrollbar">
          {isLoading && !creator ? (
            <div className="flex flex-col items-center justify-center py-20 gap-2 text-slate-400">
              <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
              <span className="text-xs font-semibold">Loading profile...</span>
            </div>
          ) : creator ? (
            <>
              <div className="flex flex-col items-center text-center">
                {/* Avatar */}
                <div className="w-20 h-20 rounded-full p-[2.5px] bg-gradient-to-tr from-sky-400 via-purple-600 to-pink-500 shadow-md mb-2.5">
                  <img
                    src={creator.avatar || DEFAULT_AVATAR}
                    alt={creator.name}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = DEFAULT_AVATAR;
                    }}
                    className="w-full h-full rounded-full object-cover border-2 border-white bg-slate-100"
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <h3 className="font-black text-slate-900 text-base">{creator.name}</h3>
                  {creator.isVerified && (
                    <span className="w-4 h-4 rounded-full bg-sky-500 text-white text-[9px] flex items-center justify-center font-bold">
                      ✓
                    </span>
                  )}
                </div>
                <span className="text-xs text-slate-400 font-bold">@{creator.username}</span>

                {/* Followers / Following Stats */}
                <div className="flex items-center gap-6 mt-3 py-2 px-6 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-black text-slate-900">
                      {creator.followers || '1.8M'}
                    </span>
                    <span className="text-[10px] text-slate-400">Followers</span>
                  </div>
                  <div className="h-4 w-[1px] bg-slate-200" />
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-black text-slate-900">312</span>
                    <span className="text-[10px] text-slate-400">Following</span>
                  </div>
                  <div className="h-4 w-[1px] bg-slate-200" />
                  <div className="flex flex-col items-center">
                    <span className="text-xs font-black text-slate-900">5.4M</span>
                    <span className="text-[10px] text-slate-400">Likes</span>
                  </div>
                </div>

                {/* Bio */}
                <p className="text-xs text-slate-600 mt-3 max-w-xs leading-relaxed font-medium">
                  {creator.bio || 'Creating positive energy daily ✨ Be you, always ♡'}
                </p>

                {/* Follow Button */}
                <button
                  onClick={() => onFollowToggle(creator.id)}
                  className={`mt-4 py-2.5 px-8 rounded-full text-xs font-black flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer ${
                    creator.isFollowing
                      ? 'bg-slate-200 text-slate-800'
                      : 'liquid-gradient-btn text-white'
                  }`}
                >
                  {creator.isFollowing ? (
                    <>
                      <Check className="w-4 h-4 text-slate-800" />
                      <span>Following</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>Follow</span>
                    </>
                  )}
                </button>
              </div>

              {/* Creator's videos grid */}
              <div className="mt-6">
                <h4 className="font-extrabold text-xs text-slate-800 uppercase tracking-wider mb-2">
                  Videos ({creatorVideos.length})
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {creatorVideos.map((v) => (
                    <div
                      key={v.id}
                      onClick={() => {
                        onClose();
                        onSelectVideo(v);
                      }}
                      className="group relative aspect-[9/16] rounded-xl overflow-hidden bg-slate-900 cursor-pointer shadow-xs"
                    >
                      <img
                        src={v.posterUrl}
                        alt={v.caption}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-80" />
                      <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 text-white text-[10px] font-bold">
                        <Play className="w-2.5 h-2.5 fill-white" />
                        <span>{v.views}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
};
