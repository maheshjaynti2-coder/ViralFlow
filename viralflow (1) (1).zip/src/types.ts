export type TabType = 'home' | 'explore' | 'create' | 'inbox' | 'profile' | 'creators' | 'saved';
export type FeedTabType = 'forYou' | 'trending' | 'following';

export interface Creator {
  id: string;
  name: string;
  username: string;
  avatar: string;
  isVerified: boolean;
  isFollowing: boolean;
  bio?: string;
  followers?: string;
}

export interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  albumArt: string;
  duration?: string;
}

export interface VideoItem {
  id: string;
  videoUrl: string;
  posterUrl: string;
  creator: Creator;
  caption: string;
  tags: string[];
  music: MusicTrack;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  savesCount: number;
  isLiked: boolean;
  isSaved: boolean;
  views: string;
  category: 'Trending' | 'Dance' | 'Music' | 'Travel' | 'Comedy' | 'Vibe' | 'Art' | 'Tech' | 'Nature' | 'Pets' | 'Adventure';
  createdAt: string;
}

export interface CommentItem {
  id: string;
  videoId: string;
  userId?: string;
  user: {
    name: string;
    username: string;
    avatar: string;
    isVerified?: boolean;
  };
  text: string;
  likesCount: number;
  isLiked: boolean;
  createdAt: string;
  createdAtTimestamp?: string;
  parentId?: string | null;
  replyToUser?: string | null;
  replies?: CommentItem[];
}

export interface NotificationItem {
  id: string;
  type: 'like' | 'comment' | 'reply' | 'follow' | 'mention' | 'system';
  actor: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    isFollowing?: boolean;
  };
  text: string;
  timestamp: string;
  createdAtTimestamp?: string;
  videoThumbnail?: string;
  videoId?: string;
  commentId?: string;
  isRead: boolean;
  recipientId?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  recipientId?: string;
  conversationId?: string;
  text: string;
  timestamp: string;
  createdAtTimestamp?: string;
  isMe: boolean;
  isRead?: boolean;
  sharedVideo?: {
    id: string;
    caption: string;
    posterUrl: string;
    videoUrl?: string;
  };
}

export const DEFAULT_AVATAR =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' stop-color='%2338bdf8'/%3E%3Cstop offset='50%25' stop-color='%239333ea'/%3E%3Cstop offset='100%25' stop-color='%23ec4899'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='100' height='100' rx='50' fill='%23f1f5f9'/%3E%3Ccircle cx='50' cy='38' r='18' fill='url(%23g)' opacity='0.9'/%3E%3Cpath d='M20 86c0-16.569 13.431-30 30-30s30 13.431 30 30' fill='url(%23g)' opacity='0.9'/%3E%3C/svg%3E";

export interface ChatThread {
  id: string;
  participantIds?: string[];
  user: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    isOnline?: boolean;
  };
  lastMessage: string;
  lastMessageSenderId?: string;
  timestamp: string;
  updatedAtTimestamp?: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface UserProfile {
  uid?: string;
  name: string;
  displayName?: string;
  username: string;
  email?: string;
  avatar: string;
  photoURL?: string;
  bio: string;
  followingCount: number;
  followersCount: string;
  likesCount: string;
  badge?: string;
  links?: string;
  createdAt?: string;
}

export interface FirestoreUserDoc {
  uid: string;
  displayName: string;
  username: string;
  email: string;
  photoURL: string;
  bio: string;
  followersCount: number;
  followingCount: number;
  createdAt: string;
}

export interface FirestoreVideoDoc {
  videoId: string;
  ownerId: string;
  ownerName: string;
  ownerPhoto: string;
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  hashtags: string;
  musicName: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  createdAt: string;
}

export interface FirestoreLikeDoc {
  userId: string;
  videoId: string;
  createdAt: string;
}

export interface FirestoreCommentDoc {
  commentId: string;
  videoId: string;
  userId: string;
  text: string;
  userName?: string;
  userAvatar?: string;
  likesCount?: number;
  createdAt: string;
  parentId?: string | null;
  replyToUser?: string | null;
}

export interface FirestoreCommentLikeDoc {
  userId: string;
  commentId: string;
  videoId: string;
  createdAt: string;
}

export interface FirestoreFollowDoc {
  followerId: string;
  followingId: string;
  createdAt: string;
}

export interface FirestoreSavedVideoDoc {
  userId: string;
  videoId: string;
  createdAt: string;
}

export interface FirestoreNotificationDoc {
  notificationId: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  senderUsername?: string;
  senderAvatar: string;
  type: 'like' | 'comment' | 'reply' | 'follow' | 'mention' | 'system';
  message: string;
  videoId?: string;
  videoThumbnail?: string;
  commentId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface FirestoreConversationDoc {
  id: string;
  participantIds: string[];
  participants: {
    [uid: string]: {
      id: string;
      name: string;
      username: string;
      avatar: string;
    };
  };
  lastMessage: {
    text: string;
    senderId: string;
    createdAt: string;
    isRead: boolean;
  } | null;
  unreadCounts: {
    [uid: string]: number;
  };
  updatedAt: string;
}

export interface FirestoreMessageDoc {
  messageId: string;
  conversationId: string;
  senderId: string;
  recipientId: string;
  text: string;
  sharedVideo?: {
    id: string;
    caption: string;
    posterUrl: string;
    videoUrl?: string;
  };
  isRead: boolean;
  createdAt: string;
}

